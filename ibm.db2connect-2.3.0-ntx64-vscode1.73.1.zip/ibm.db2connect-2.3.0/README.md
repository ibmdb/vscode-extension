# Db2 Connect
Welcome to **Db2 Connect** for Visual Studio Code! An extension for working with IBM Database servers and performing database operations such as:

* Connect to IBM Database Servers.
* Explore all the database objects through the tree view for each connection.
* Create and manage connection profiles.
* Write sql statements to do DDL and DML operations and save as .sql,.spsql,.udfsql,.db2,.spdb2 and .udfdb2.
* Execute sql statements and view results in a simple to use grid.
* Execute stored procedures.
* Execute sql files.
* Export result set as JSON, CSV or XML format.
* Keyboard shortcuts, Editor options for Single or multiple sql execution and file execution.
* Templates for creating tables, views, alias, stored procedures, functions, triggers and indexes.
* Syntax highlighting.
* Code snippet support.
* Intellisense support with connection aware code completion (keywords, functions, tables...).
* Install Db2 for i and Db2 for z/OS license from Db2 Connect Explorer.
* See Feature Contributions tab for supported languages and file types.
* Please see the [usage documentation](https://community.ibm.com/community/user/hybriddatamanagement/blogs/sai-ram-akhil-ravuri1/2020/11/11/vs-code-extension-for-db2-connect) for more details.



## Features

Db2: Connect (Click on + icon in the Db2 Connect View)

    Option 1 Select this option if you have a connection string handy.
    
    Option 2 Select this option to provide individual parameters
        In this option, the individual connection parameters like Database, Hostname, Port, Userid, Password can be specified.
        
    Option 3 Connect using one of your saved Connection Profiles
        In this option, selecting an existing profile to connect is provided.

    Once the connection is established users can see connection node in the Db2 Connect view where users can create, modify or delete the database objects.

    Multiple connections are allowed, so just my clicking on any node(in the tree view) user can change the active connection.


Db2: Disconnect (Click on the Cross(X) icon next to the Connection node)

    Disconnects the opened connection.

Db2: Manage Connection Profile (Click on the manage Connection profile icon in the Db2 Connect view)

    Through this option, its possible to Create, Edit or Delete profile information. A profile contains database connection information. 
    Manage Connection Profile has three options:    
    Create
        Creates a new profile containing details such as Database Name, Hostname, Port, Userid and Password.
    Edit
        This option allows editing of existing profiles. This option opens a GUI where user has to select the profile and edit the profile details.
	Delete 
        This option allows the user to delete the profile.

Db2: ExecuteNonQuery 

    This option can be used to execute DDL and DML statements except select on the connected database objects. Before using this option, it is required to connect to the database using the Connect option. The results of doing database operations is displayed through the message dialog in the right bottom corner of VS Code editor.

Db2: ExecuteQuery

    This features provides support for querying the database objects. The results of this execution will be displayed on the right hand side of VS Code window.

Db2: ExecuteFile (Click on the Execute icon in the Db2 Connect view)

    This features provides support for executing a file which contains multiple sql's. The results of this execution will be displayed on the right hand side of VS Code window.

Db2: View Command History (Click on the View Command History icon in the Db2 Connect view)

    This option opens a file where a list of user executed sqls for a session are stored.

Db2: Rebuild Native Modules

    This option is used when a new version of an electron is introduced into the VS Code Editor. One can use this command to install the latest ibmdb driver which is compatible with the latest electron version.

Db2: Report an Issue

    This option will redirect you to the github page where user can raise issues.

## For z/OS and iSeries Connectivity
For connectivity against Db2 for LUW using Db2 Connect VS Code extension, Db2 Connect license is not required. However, if you want to use Db2 Connect VS Code extension against Db2 for z/OS or Db2 for i(AS400) Servers, you must have Db2 Connect 11.5 license if the Db2 Server is not already activated with unlimited Db2 Connect license. Db2 Connect license can be enabled either on server using Db2 Connect activate utility or on client using client side license file. If you have client side license file, Just click on the Add license in the Db2 Connect view and install it.

In absense of a valid Db2 Connect license file, `Db2 Connect` will throw SQL1598N error. Client side license file name should be `db2con*.lic`.

To know more about license and purchasing cost, please contact [IBM Customer Support](http://www.ibm.com/software/lotus/passportadvantage/).


## Known Issues

* Electron version management is not done by extension. So, If a major electron version is introduced into VS Code editor please run Db2: Rebuild Native Modules command to download the latest ibmdb package which is compatible with the latest electron version.

* While using .sql file you may see recommendations coming from other extensions who are having .sql extension. If you do not want to see recommendations from other extensions, change the file type to .db2. Editor options like execute multiple or single sql and execute file options are available in .db2 file type also.

## Release Notes

### 2.3.0
* Intellisense support (Connection aware code completion like tables, functions, tables...).
* Insert Row option added to table tree item.
