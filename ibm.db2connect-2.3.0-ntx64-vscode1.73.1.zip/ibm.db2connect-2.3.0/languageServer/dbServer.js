const vscode = require('vscode');

let Db2Disposables = [];

let connString = "";

function db2MetaData(info, context){
    if (connString != info.connString) {
        connString = info.connString
        for (let i=0; i<Db2Disposables.length; i++){
            Db2Disposables[i].dispose()
            const index = Db2Disposables.indexOf(i);
            if (index > -1) {
              Db2Disposables.splice(index, 1);
            }
        }
        addDb2SchemaKeywords(info, context)
        addDb2TableKeywords(info, context)
        addDb2ViewKeywords(info, context)
        addDb2AliasKeywords(info, context)
        addDb2TriggerKeywords(info, context)
        addDb2IndexKeywords(info, context)
        addDb2FunctionKeywords(info, context)
        addDb2StoredProcedureKeywords(info, context)
    }
}

function addDb2SchemaKeywords(info, context){
    let schemas = [];
    let res = null;
    if (info.serverName == "luw") {
        res = info.connObj.querySync("select SCHEMANAME from SYSCAT.SCHEMATA ORDER BY SCHEMANAME");
    } else if (info.serverName == "zos"){
        res = info.connObj.querySync("select distinct SCHEMANAME from (select creator from sysibm.systables union all select schema from sysibm.sysdatatypes union all select schema from sysibm.sysroutines union all select schema from sysibm.systriggers) schemata(schemaname)");
    } else {
        res = info.connObj.querySync("select SCHEMA_NAME as SCHEMANAME from QSYS2.SYSSCHEMAS");
    }
    for (let i=0;i<res.length;i++) {
        schemas.push(res[i].SCHEMANAME)
    }
    const provider = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
		provideCompletionItems(document, position, token, context) {
			return returnAllKeyWords(schemas, vscode.CompletionItemKind.Value)
		}
	});
    Db2Disposables.push(provider);
	context.subscriptions.push(provider);
}

function addDb2TableKeywords(info, context) {
    let tables = [];
    let res = null;
    if (info.serverName == "luw") {
        res = info.connObj.querySync("select TABNAME as NAME from SYSCAT.TABLES where TYPE = 'T' ORDER BY TABNAME");
    } else if (info.serverName == "zos"){
        res = info.connObj.querySync("select NAME from SYSIBM.SYSTABLES where TYPE = 'T' ORDER BY NAME");
    } else {
        res = info.connObj.querySync("select TABLE_NAME as NAME from QSYS2.SYSTABLES where TABLE_TYPE = 'T' ORDER BY TABLE_NAME");
    }
    for (let i=0;i<res.length;i++) {
        tables.push(res[i].NAME)
    }
    addDb2CommonKeyWords(tables, context)
    const provider = vscode.languages.registerCompletionItemProvider (['db2_luw', 'db2_z', 'db2_i'], {
		  // eslint-disable-next-line no-unused-vars
		  provideCompletionItems(document, position, token, context) {
			const linePrefix = document.lineAt(position).text.substr(0, position.character);
			if (!linePrefix.endsWith('TABLE ') && !linePrefix.endsWith('FROM ') && !linePrefix.endsWith('INTO ')) {
				return undefined;
			}
			return returnAllKeyWords(tables, vscode.CompletionItemKind.Value)
		  }
		},
		' ' // trigger
	)
    Db2Disposables.push(provider);
	context.subscriptions.push(provider);
}

function addDb2ViewKeywords(info, context) {
    let views = []
    if (info.serverName == "luw") {
        res = info.connObj.querySync("select VIEWNAME as NAME from SYSCAT.VIEWS ORDER BY VIEWNAME");
    } else if (info.serverName == "zos"){
        res = info.connObj.querySync("select NAME from SYSIBM.SYSVIEWS ORDER BY NAME");
    } else {
        res = info.connObj.querySync("select TABLE_NAME as NAME from QSYS2.SYSTABLES where TABLE_TYPE = 'V' ORDER BY TABLE_NAME");
    }
    for (let i=0;i<res.length;i++) {
        views.push(res[i].NAME)
    }
    addDb2CommonKeyWords(views, context)
    const provider = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
		  provideCompletionItems(document, position, token, context) {
			const linePrefix = document.lineAt(position).text.substr(0, position.character);
			if (!linePrefix.endsWith('VIEW ') && !linePrefix.endsWith('FROM ')) {
				return undefined;
			}
			return returnAllKeyWords(views, vscode.CompletionItemKind.Value)
		  }
		},
		' ' // trigger
	);
    Db2Disposables.push(provider);
	context.subscriptions.push(provider);
}

function addDb2AliasKeywords(info, context) {
    let alias = []
    if (info.serverName == "luw") {
        res = info.connObj.querySync("select TABNAME as NAME from SYSCAT.TABLES where TYPE = 'A' ORDER BY TABNAME");
    } else if (info.serverName == "zos"){
        res = info.connObj.querySync("select NAME from SYSIBM.SYSTABLES where TYPE = 'A' ORDER BY NAME");
    } else {
        res = info.connObj.querySync("select TABLE_NAME as NAME from QSYS2.SYSTABLES where TABLE_TYPE = 'A' ORDER BY TABLE_NAME");
    }
    for (let i=0;i<res.length;i++) {
        alias.push(res[i].NAME)
    }
    addDb2CommonKeyWords(alias, context)
    const provider = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
        provideCompletionItems(document, position, token, context) {
			const linePrefix = document.lineAt(position).text.substr(0, position.character);
			if (!linePrefix.endsWith('ALIAS ') && !linePrefix.endsWith('FROM ')) {
				return undefined;
			}
			return returnAllKeyWords(alias, vscode.CompletionItemKind.Value)
		  }
		},
		' ' // trigger
	);
    Db2Disposables.push(provider);
	context.subscriptions.push(provider);
}

function addDb2TriggerKeywords(info, context) {
    let trigger = []
    if (info.serverName == "luw") {
        res = info.connObj.querySync("select TRIGNAME as NAME from SYSCAT.TRIGGERS order by TRIGNAME");
    } else if (info.serverName == "zos"){
        res = info.connObj.querySync("select NAME from SYSIBM.SYSTRIGGERS order by NAME");
    } else {
        res = info.connObj.querySync("select TRIGGER_NAME as NAME from QSYS2.SYSTRIGGERS ORDER BY TRIGGER_NAME");
    }
    for (let i=0;i<res.length;i++) {
        trigger.push(res[i].NAME)
    }
    addDb2CommonKeyWords(trigger, context)
    const provider = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
        provideCompletionItems(document, position, token, context) {
			const linePrefix = document.lineAt(position).text.substr(0, position.character);
			if (!linePrefix.endsWith('TRIGGER ')) {
				return undefined;
			}
			return returnAllKeyWords(trigger, vscode.CompletionItemKind.Value)
		  }
		},
		' ' // trigger
    );
    Db2Disposables.push(provider);
	context.subscriptions.push(provider);
}

function addDb2IndexKeywords(info, context) {
    let indexes = [];
    if (info.serverName == "luw") {
        res = info.connObj.querySync("SELECT INDNAME AS NAME FROM SYSCAT.INDEXES ORDER BY INDNAME");
    } else if (info.serverName == "zos"){
        res = info.connObj.querySync("SELECT NAME FROM SYSIBM.SYSINDEXES ORDER BY NAME");
    } else {
        res = info.connObj.querySync("SELECT INDEX_NAME AS NAME FROM QSYS2.SYSINDEXES ORDER BY INDEX_NAME");
    }
    for (let i=0;i<res.length;i++) {
        indexes.push(res[i].NAME)
    }
    addDb2CommonKeyWords(indexes, context)
    const provider = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
        provideCompletionItems(document, position, token, context) {
			const linePrefix = document.lineAt(position).text.substr(0, position.character);
			if (!linePrefix.endsWith('INDEX ') && !linePrefix.endsWith('FROM ')) {
				return undefined;
			}
			return returnAllKeyWords(indexes, vscode.CompletionItemKind.Value)
		  }
		},
		' ' // trigger
	);
	Db2Disposables.push(provider);
	context.subscriptions.push(provider);
}

function addDb2FunctionKeywords(info, context) {
    let functions_temp = [];
    let functions = [];
    if (info.serverName == "luw") {
        res = info.connObj.querySync("select ROUTINENAME as NAME from SYSCAT.ROUTINES where ROUTINETYPE = 'F' ORDER BY NAME");
    } else if (info.serverName == "zos"){
        res = info.connObj.querySync("select NAME from SYSIBM.SYSROUTINES where ROUTINETYPE = 'F' ORDER BY NAME");
    } else {
        res = info.connObj.querySync("select ROUTINE_NAME as NAME from QSYS2.SYSROUTINES where ROUTINE_TYPE= 'FUNCTION' ORDER BY ROUTINE_NAME");
    }
    for (let i=0;i<res.length;i++) {
        functions_temp.push(res[i].NAME)
    }
    functions = functions_temp.filter(function(elem, pos) {
        return functions_temp.indexOf(elem) == pos;
    })
    addDb2CommonKeyWords(functions, context)
    const provider = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
        provideCompletionItems(document, position, token, context) {
            const linePrefix = document.lineAt(position).text.substr(0, position.character);
            if (!linePrefix.endsWith('SELECT ')) {
                return undefined;
            }
            return returnAllKeyWords(functions, vscode.CompletionItemKind.Method)
        }
    },
    ' ' // trigger
    );
    Db2Disposables.push(provider);
	context.subscriptions.push(provider);
}

function addDb2StoredProcedureKeywords(info, context) {
    let storedProcedures_temp = [];
    let storedProcedures = [];
    if (info.serverName == "luw") {
        res = info.connObj.querySync("select ROUTINENAME as NAME from SYSCAT.ROUTINES where ROUTINETYPE = 'P' ORDER BY ROUTINENAME");
    } else if (info.serverName == "zos"){
        res = info.connObj.querySync("select NAME from SYSIBM.SYSROUTINES where ROUTINETYPE = 'P' ORDER BY NAME");
    } else {
        res = info.connObj.querySync("select ROUTINE_NAME as NAME from QSYS2.SYSROUTINES where ROUTINE_TYPE= 'PROCEDURE' ORDER BY ROUTINE_NAME");
    }
    for (let i=0;i<res.length;i++) {
        storedProcedures_temp.push(res[i].NAME)
    }
    storedProcedures = storedProcedures_temp.filter(function(elem, pos) {
        return storedProcedures_temp.indexOf(elem) == pos;
    })
    addDb2CommonKeyWords(storedProcedures, context)
    const provider = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
        provideCompletionItems(document, position, token, context) {
			const linePrefix = document.lineAt(position).text.substr(0, position.character);
			if (!linePrefix.endsWith('CALL ') && !linePrefix.endsWith('PROCEDURE ')) {
				return undefined;
			}
			return returnAllKeyWords(storedProcedures, vscode.CompletionItemKind.Value)
		  }
		},
		' ' // trigger
	);
    Db2Disposables.push(provider);
	context.subscriptions.push(provider);
}

function returnAllKeyWords(keywords, type) {
	const db2keywords = []
	for (let i = 0;i<keywords.length;i++) {
		db2keywords.push(new vscode.CompletionItem(keywords[i], type))
	}
	return db2keywords
}

function addDb2CommonKeyWords(keywords, context) {
	const provider = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
		provideCompletionItems(document, position, token, context) { 
			return returnAllKeyWords(keywords, vscode.CompletionItemKind.Keyword)
		}
	});
    Db2Disposables.push(provider);
	context.subscriptions.push(provider);
}

function disposedb2MetaData(){
    for (let i=0; i<Db2Disposables.length; i++){
        Db2Disposables[i].dispose()
        const index = Db2Disposables.indexOf(i);
        if (index > -1) {
          Db2Disposables.splice(index, 1);
        }
    }
}

module.exports = {
    disposedb2MetaData,
	db2MetaData,
    Db2Disposables
}