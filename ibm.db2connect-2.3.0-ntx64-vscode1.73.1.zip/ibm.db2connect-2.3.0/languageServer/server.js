const vscode = require('vscode');

function defaultKeywords(context, db2ConnectOutputChannel) {
	addDmlKeyWords(context);
	addDdlKeyWords(context);
	addDclKeyWords(context);
	addTclKeyWords(context);
	addDataTypeKeyWords(context);
	addFunctionKeyWords(context);
	addOtherKeyWords(context);
	restrictKeywordsForCreate(context);
	restrictKeywordsForAlter(context);
	restrictKeywordsForSelect(context);
	restrictKeywordsForDrop(context);
	restrictKeywordsForDelete(context);
	restrictKeywordsForInsert(context);
	restrictKeywordsForRename(context);
	db2ConnectOutputChannel.append("Intellisense Activated\n");
}

function addDmlKeyWords(context){
	const provider1 = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
		provideCompletionItems(document, position, token, context) {
			keywords = ["INSERT", "UPDATE", "DELETE", "INTO", "VALUES", "SET", "SETS", "WHERE", "FROM", "UNPACK", "SELECT", "MERGE", "FOR", "HAVING", "DISTINCT", "ALL", "TRUNCATE", "GROUP BY", "CURRENT", "ORDER BY", "SKIP LOCKED DATA", "UNION", "DISTINCT", "EXCEPT","INTERSECT",  "FETCH FIRST", "FETCH NEXT", "ROWS ONLY", "ROW ONLY", "FOR ROW", "ROWSET", "OFFSET", "OPTIMIZE", "EXISTS", "XMLEXISTS", "REUSE", "STORAGE", "NOT", "NULL", "IS", "BETWEEN", "UNNEST", "CROSS JOIN", "ROLLUP", "CUBE", "GROUPING SETS", "INNER JOIN", "LEFT JOIN", "RIGHT JOIN","IGNORE", "IMMEDIATE", "RESTRICT", "MATCHED", "SYSTEM_TIME", "BUSINESS_TIME", "CARDINALITY", "MULTIPLIER", "PASSING", "OVERRIDING", "SQLEXCEPTION", "SENSITIVE", "BEGIN", "START", "END", "TRANSACTION", "WORKFILE", "ASUTIME", "LIMIT", "AUDIT", "AUTONOMOUS", "CHANGES", "USING", "AUTHID", "OVERLAPS"]
			return returnAllKeyWords(keywords,vscode.CompletionItemKind.Keyword)
		}
	});
	context.subscriptions.push(provider1);
}

function addDdlKeyWords(context){
	const provider1 = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
		provideCompletionItems(document, position, token, context) {
			keywords = ["CREATE", "DROP", "ALTER", "COMMENT", "RENAME", "DATABASE", "TABLE", "COLUMN", "MODIFY", "ACCELERATION", "WAITFORDATA", "ACCELERATOR", "SPECIFIC", "FUNCTION", "PROCEDURE", "MASK", "PERMISSION", "SEQUENCE", "STOGROUP", "TRIGGER", "TRUSTED", "CONTEXT", "VIEW", "EXCHANGE", "DATA", "COMMENT ON", "PUBLIC", "SYNONYM", "LARGE", "LOB", "AUXILIARY", "AUX", "DECLARE", "GLOBAL", "TEMPORARY", "LABEL", "CACHE", "COLLID", "CYCLE", "DBINFO", "ROLE", "DEFAULT", "SECURITY", "EXTERNAL", "ACTION", "FINAL","CALL", "NAMESPACE", "KEY", "VALUE", "SCRATCHPAD", "CLUSTER", "DETERMINISTIC", "LOGGED", "PADDED", "SECURED", "VARIANT", "VOLATILE", "AUTHENTICATION", "EXPLAIN", "ROW", "ATTRIBUTES", "KEEP", "DYNAMIC", "ACCESS", "ADDRESS", "ALGORITHM", "APPLCOMPAT", "ENCODING", "ASCII", "EBCDIC", "UNICODE", "CCSID",
			"EDITPROC", "VALIDPROC", "LANGUAGE","ASSEMBLE", "C", "COBOL", "JAVA", "PLI", "REXX", "VERSIONING", "ENCRYPTION","ELEMENT", "MODIFIERS", "ENFORCED", "FIELDPROC", "FENCED", "FREEPAGE", "EUR", "ISO", "JIS", "LOCAL", "USA", "GBPCACHE", "GET_ACCEL_ARCHIVE", "JOBNAME", "PRIMARY KEY", "FOREGIN KEY", "INDEXBP", "CASCADE", "ACTIVATE","DEACTIVATE", "ADD", "APPEND", "COMPRESS", "DEFER", "DEFINE", "DYNAMICRULES", "INVOKE", "ERASE", "EGENERATE", "REMOVE", "REPLACE", "ROTATE", "DB2SQL", "DISABLE", "DISALLOW", "ALLOW", "ASC", "DSC", "BEGIN DECLARE SECTION"]
			return returnAllKeyWords(keywords, vscode.CompletionItemKind.Keyword)
		}
	});
	context.subscriptions.push(provider1);
}

function addDclKeyWords(context){
	const provider1 = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
		provideCompletionItems(document, position, token, context) {
			keywords = ["GRANT", "REVOKE",  "PACKADM", "WITH GRANT OPTION", "ON", "IN", "COLLECTION","DBADM", "DBCTRL", "DBMAINT", "CREATETAB", "CREATETS", "DISPLAYDB", "IMAGCOPY", "LOAD", "RECOVERDB", "REORG", "REPAIR", "STARTDB", "STATS", "STOPDB", "EXECUTE", "SPECIFIC", "BIND", "COPY", "EXECUTE", "RUN", "PACKAGE", "PLAN", "ALTERIN", "CREATEIN", "DROPIN", "USAGE", "ALL PRIVILEGES", "PRIVILEGES", "READ", "WRITE", "VARIABLE", "TYPE", "TYPE MAPPING","JAR", "BUFFERPOOL", "ALL", "BUFFERPOOLS", "TABLESPACE", "DEPENDENT", "NOT", "INCLUDING", "EXCLUDING", "BY", "DATABASE PARTITION GROUP", "TRANSFER", "OWNERSHIP", "INDEX", "PUBLIC", "ALIAS", "ACCESSCTRL", "ARCHIVE", "BSDS", "TMTAB", "DBC", "DBA", "SG", "CREATE_SECURE_OBJECT", "DATAACCESS", "DEBUGSESSION", "DISPLAY", "SQLADM", "RECOVER", "STOSPACE", "STOPALL", "CONCENTRATE", "CONSTRAINT"]
			return returnAllKeyWords(keywords,vscode.CompletionItemKind.Keyword)
		}
	});
	context.subscriptions.push(provider1);
}

function addTclKeyWords(context){
	const provider1 = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
		provideCompletionItems(document, position, token, context) {
			keywords = ["COMMIT", "ROLLBACK", "SAVEPOINT", "WORK", "RETAIN", "CURSOR", "LOCK"]
			return returnAllKeyWords(keywords, vscode.CompletionItemKind.Keyword)
		}
	});
	context.subscriptions.push(provider1);
}

function addDataTypeKeyWords(context) {
	const provider1 = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
		provideCompletionItems(document, position, token, context) { 
			keywords = ["INT", "SMALL INT", "BIG INT", "INTEGER", "DECIMAL", "FLOAT", "DECFLOAT", "NUMERIC", "REAL", "DOUBLE", "DOUBLE PRECISION", "CHAR", "CHARACTER", "VARCHAR", "GRAPHIC", "VARGRAPHIC", "BINARY", "VARBINARY", "CLOB", "BLOB", "DBCLOB","ROWID", "XML", "TIME", "TIMESTAMP", "DATE", "WITH TIMEZONE", "WITHOUT TIMEZONE", "WITH TIME", "WITHOUT TIME"]
			return returnAllKeyWords(keywords, vscode.CompletionItemKind.Keyword)
		}
	});
	context.subscriptions.push(provider1);
}

function addFunctionKeyWords(context) {
	const provider1 = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
		provideCompletionItems(document, position, token, context) {
			keywords = ["ARRAY_AGG","AVG","CORRELATION","COUNT","COUNT_BIG","COVARIANCE","COVARIANCE_SAMP","CUME_DIST","GROUPING","LISTAGG","MAX","MEDIAN","MIN","PERCENTILE_CONT","PERCENTILE_DISC","PERCENT_RANK","REGR_SLOPE","REGR_INTERCEPT","REGR_R2","REGR_AVGX","REGR_AVGY","REGR_SXX","REGR_COUNT","REGR_SYY","REGR_SXY","STDDEV","STDDEV_SAMP","SUM","VARIANCE","VARIANCE_SAMP","XMLAGG","XMLGROUP","ACOS","ABS","ABSVAL","ADD_DAYS","ADD_HOURS","ADD_MINUTES","ADD_MONTHS","ADD_SECONDS","ADD_YEARS","AGE","ARRAY_DELETE","ARRAY_FIRST","ARRAY_LAST","ARRAY_NEXT","ARRAY_PRIOR","ASCII","ASCII_STR","ASIN","ATAN","ATAN2","ATANH","BIGINT","BINARY","BLOB","BOOLEAN","BPCHAR","BSON_TO_JSON","BTRIM","CARDINALITY","CEILING","CEIL",
			"CHAR","CHARACTER_LENGTH","CHR","CLOB","COALESCE","COLLATION_KEY","COLLATION_KEY_BIT","COMPARE_DECFLOAT","CONCAT","COS","COSH","COT","CURSOR_ROWCOUNT","DATAPARTITIONNUM","DATE","DATETIME","DATE_PART","DATE_TRUNC","DAY","DAYNAME","DAYOFMONTH","DAYOFWEEK","DAYOFWEEK_ISO","DAYOFYEAR","DAYS","DAYS_BETWEEN","DAYS_TO_END_OF_MONTH","DBCLOB","DBPARTITIONNUM","DECFLOAT","DECFLOAT_FORMAT","DECIMAL","DECODE","DECRYPT_BIN","DECRYPT_CHAR","DEGREES","DEREF","DIFFERENCE","DIGITS","DOUBLE_PRECISION","DOUBLE","EMPTY_BLOB","EMPTY_CLOB","EMPTY_DBCLOB","EMPTY_NCLOB","ENCRYPT","EVENT_MON_STATE","EXP","EXTRACT","FIRST_DAY","FLOAT","FLOAT4","FLOAT8","FLOOR","FROM_UTC_TIMESTAMP","GENERATE_UNIQUE","GETHINT","GRAPHIC","GREATEST",
			"HASH","HASH4","HASH8","HASHEDVALUE","HEX","HEXTORAW","HOUR","HOURS_BETWEEN","IDENTITY_VAL_LOCAL","IFNULL","INITCAP","INSERT","INSTR","INSTR2","INSTR4","INSTRB","INT","INTERVAL","ISNULL","YMD_BETWEEN","YEARS_BETWEEN","YEAR","XSLTRANSFORM","XMLXSROBJECTID","XMLVALIDATE","XMLTEXT","XMLSERIALIZE","XMLROW","XMLQUERY","XMLPI","XMLPARSE","XMLNAMESPACES","XMLFOREST","XMLELEMENT","XMLDOCUMENT","XMLCONCAT","XMLCOMMENT","XMLATTRIBUTES","WIDTH_BUCKET","WEEKS_BETWEEN","WEEK_ISO","WEEK","VERIFY_TRUSTED_CONTEXT_ROLE_FOR_USER","VERIFY_ROLE_FOR_USER","VERIFY_GROUP_FOR_USER","VARGRAPHIC","VARCHAR_FORMAT_BIT","VARCHAR_FORMAT","VARCHAR_BIT_FORMAT","VARCHAR","VARBINARY","VALUE","UPPER","UNICODE_STR","UCASE","TYPE_SCHEMA","TYPE_NAME",
			"TYPE_ID","TRUNCATE","TRUNC_TIMESTAMP","TRIM_ARRAY","TRIM","TRANSLATE","TOTALORDER","TIMEZONE","TIMESTAMPDIFF","TIMESTAMP_ISO","TIMESTAMP_FORMAT","TIMESTAMP","TIME","SUBSTRING",]
			return returnAllKeyWords(keywords, vscode.CompletionItemKind.Method)
		}
	});
	context.subscriptions.push(provider1);
}

function addOtherKeyWords(context) {
	const provider1 = vscode.languages.registerCompletionItemProvider(['db2_luw', 'db2_z', 'db2_i'], {
		provideCompletionItems(document, position, token, context) {
			keywords = ["DO", "CASE", "LOOP", "REPEAT", "WHILE", "GOTO", "UNTIL", "SIGNAL", "ITERATE", "RETURN", "LEAVE", "RESIGNAL", "INOUT", "OUT", "SQL", "CONDITION", "SQLSTATE", "HANDLER", "CONTINUE", "END IF", "IF", "MODULE", "METHOD", "NICKNAME", "THRESHOLD", "AUDIT POLICY", "DBPARTITIONNUM", "DBPARTITIONNUMS", "EVENT MONITOR", "ADD LOGICAL GROUP", "HISTOGRAM TEMPLATE", "HIGH BIN VALUE", "SERVER", "SERVER OPTION", "SERVICE CLASS", "USAGE LIST", "USER MAPPING", "FUNCTION MAPPING", "WORKLOAD", "WORK ACTION SET", "WRAPPER", "WORK CLASS SET", "XSROBJECT", "ASSOCIATE", "RESULT SET", "LOCATOR", "LOCATORS", "WITH PROCEDURE", "EXEC", "WHEN", "THEN UPDATE", "ELSE UPDATE", "END CASE", "CLOSE", "OPEN"]
			return returnAllKeyWords(keywords, vscode.CompletionItemKind.Keyword)
		}
	});
	context.subscriptions.push(provider1);
}

function restrictKeywordsForCreate(context) {
	const provider = vscode.languages.registerCompletionItemProvider (
		['db2_luw', 'db2_z', 'db2_i'], {
		  // eslint-disable-next-line no-unused-vars
		  provideCompletionItems(document, position, token, context) {
			const linePrefix = document.lineAt(position).text.substr(0, position.character);
			if (!linePrefix.endsWith('CREATE ')) {
				return undefined;
			}
			keywords = ['ALIAS', 'AUDIT POLICY', 'BUFFERPOOL', 'DATABASE PARTITION GROUP', 'EVENT MONITOR', 'EXTERNAL TABLE', 'FUNCTION', 'FUNCTION MAPPING', 'GLOBAL TEMPORARY TABLE', 'HISTOGRAM TEMPLATE', 'INDEX', 'INDEX EXTENSION', 'MASK', 'METHOD', 'MODULE', 'NICKNAME','PERMISSION', 'PROCEDURE', 'ROLE', 'SCHEMA', 'SECURITY LABEL COMPONENT', 'SECURITY LABEL', 'SECURITY POLICY', 'SEQUENCE', 'SERVICE CLASS', 'SERVER', 'STOGROUP', 'SYNONYM', 'TABLE', 'TABLESPACE', 'THRESHOLD', 'TRANSFORM', 'TRIGGER', 'TRUSTED CONTEXT', 'TYPE', 'TYPE MAPPING', 'USAGE LIST', 'USER MAPPING', 'VARIABLE', 'VIEW', 'WORK ACTION SET', 'WORK CLASS SET', 'WORKLOAD', 'WRAPPER']
			return returnRestrictKeywords(keywords, vscode.CompletionItemKind.Keyword)
		  }
		},
		' ' // trigger
	)
	context.subscriptions.push(provider);
}

function restrictKeywordsForAlter(context) {
	const provider = vscode.languages.registerCompletionItemProvider (
		['db2_luw', 'db2_z', 'db2_i'], {
		  // eslint-disable-next-line no-unused-vars
		  provideCompletionItems(document, position, token, context) {
			const linePrefix = document.lineAt(position).text.substr(0, position.character);
			if (!linePrefix.endsWith('ALTER ')) {
				return undefined;
			}
			keywords = ['AUDIT POLICY', 'BUFFERPOOL', 'DATABASE PARTITION GROUP', 'DATABASE', 'EVENT MONITOR', 'FUNCTION', 'HISTOGRAM TEMPLATE', 'INDEX', 'MASK', 'METHOD', 'MODULE', 'NICKNAME', 'PACKAGE', 'PERMISSION', 'PROCEDURE', 'SCHEMA', 'SECURITY LABEL COMPONENT', 'SECURITY POLICY', 'SEQUENCE', 'SERVICE CLASS', 'SERVER', 'STOGROUP', 'TABLE', 'TABLESPACE', 'THRESHOLD', 'TRIGGER', 'TRUSTED CONTEXT', 'TYPE', 'USAGE LIST', 'USER MAPPING', 'VIEW', 'WORK ACTION SET', 'WORK CLASS SET', 'WORKLOAD', 'WRAPPER', 'XSROBJECT']
			return returnRestrictKeywords(keywords, vscode.CompletionItemKind.Keyword)
		  }
		},
		' ' // trigger
	)
	context.subscriptions.push(provider);
}

function restrictKeywordsForDrop(context) {
	const provider = vscode.languages.registerCompletionItemProvider (
		['db2_luw', 'db2_z', 'db2_i'], {
		  // eslint-disable-next-line no-unused-vars
		  provideCompletionItems(document, position, token, context) {
			const linePrefix = document.lineAt(position).text.substr(0, position.character);
			if (!linePrefix.endsWith('DROP ')) {
				return undefined;
			}
			keywords = ['ALIAS', 'PUBLIC ALIAS', 'AUDIT POLICY', 'BUFFERPOOL', 'DATABASE PARTITION GROUP', 'EVENT MONITOR', 'FUNCTION', 'SPECIFIC FUNCTION', 'FUNCTION MAPPING', 'HISTOGRAM TEMPLATE', 'INDEX', 'INDEX EXTENSION', 'MASK', 'MODULE', 'METHOD', 'SPECIFIC METHOD', 'NICKNAME', 'PACKAGE', 'PERMISSION', 'PROCEDURE', 'SPECIFIC PROCEDURE', 'ROLE', 'SCHEMA', 'SECURITY LABEL COMPONENT', 'SERVICE CLASS', 'SECURITY LABEL', 'SECURITY POLICY', 'SEQUENCE', 'SERVER', 'STOGROUP', 'TABLE', 'TABLE HIERARCHY', 'TABLESPACE', 'THRESHOLD', 'TRANSFORM', 'TRIGGER', 'TRUSTED CONTEXT', 'TYPE', 'TYPE MAPPING', 'USAGE LIST', 'USER MAPPING FOR', 'VARIABLE', 'VIEW', 'VIEW HIERARCHY', 'WORK ACTION SET', 'WORK CLASS SET', 'WORKLOAD', 'WRAPPER', 'XSROBJECT']
			return returnRestrictKeywords(keywords, vscode.CompletionItemKind.Keyword)
		  }
		},
		' ' // trigger
	)
	context.subscriptions.push(provider);
}

function restrictKeywordsForDelete(context) {
	const provider = vscode.languages.registerCompletionItemProvider (
		['db2_luw', 'db2_z', 'db2_i'], {
		  // eslint-disable-next-line no-unused-vars
		  provideCompletionItems(document, position, token, context) {
			const linePrefix = document.lineAt(position).text.substr(0, position.character);
			if (!linePrefix.endsWith('DELETE ')) {
				return undefined;
			}
			keywords = ["FROM"]
			return returnRestrictKeywords(keywords, vscode.CompletionItemKind.Keyword)
		  }
		},
		' ' // trigger
	)
	context.subscriptions.push(provider);
}

function restrictKeywordsForInsert(context) {
	const provider = vscode.languages.registerCompletionItemProvider (
		['db2_luw', 'db2_z', 'db2_i'], {
		  // eslint-disable-next-line no-unused-vars
		  provideCompletionItems(document, position, token, context) {
			const linePrefix = document.lineAt(position).text.substr(0, position.character);
			if (!linePrefix.endsWith('INSERT ')) {
				return undefined;
			}
			keywords = ["INTO"]
			return returnRestrictKeywords(keywords, vscode.CompletionItemKind.Keyword)
		  }
		},
		' ' // trigger
	)
	context.subscriptions.push(provider);
}

function restrictKeywordsForRename(context) {
	const provider = vscode.languages.registerCompletionItemProvider (
		['db2_luw', 'db2_z', 'db2_i'], {
		  // eslint-disable-next-line no-unused-vars
		  provideCompletionItems(document, position, token, context) {
			const linePrefix = document.lineAt(position).text.substr(0, position.character);
			if (!linePrefix.endsWith('RENAME ')) {
				return undefined;
			}
			keywords = ["TABLE", "INDEX", "STOGROUP", "TABLESPACE"]
			return returnRestrictKeywords(keywords, vscode.CompletionItemKind.Keyword)
		  }
		},
		' ' // trigger
	)
	context.subscriptions.push(provider);
}

function restrictKeywordsForSelect(context) {
	const provider = vscode.languages.registerCompletionItemProvider (
		['db2_luw', 'db2_z', 'db2_i'], {
		  // eslint-disable-next-line no-unused-vars
		  provideCompletionItems(document, position, token, context) {
			const linePrefix = document.lineAt(position).text.substr(0, position.character);
			if (!linePrefix.endsWith('SELECT ')) {
				return undefined;
			}
			keywords = ["ARRAY_AGG","AVG","CORRELATION","COUNT","COUNT_BIG","COVARIANCE","COVARIANCE_SAMP","CUME_DIST","GROUPING","LISTAGG","MAX","MEDIAN","MIN","PERCENTILE_CONT","PERCENTILE_DISC","PERCENT_RANK","REGR_SLOPE","REGR_INTERCEPT","REGR_R2","REGR_AVGX","REGR_AVGY","REGR_SXX","REGR_COUNT","REGR_SYY","REGR_SXY","STDDEV","STDDEV_SAMP","SUM","VARIANCE","VARIANCE_SAMP","XMLAGG","XMLGROUP","ACOS"]
			return returnRestrictKeywords(keywords, vscode.CompletionItemKind.Method)
		  }
		},
		' ' // trigger
	)
	context.subscriptions.push(provider);
}

function returnAllKeyWords(keywords, type){
	const db2keywords = []
	for (let i = 0;i<keywords.length;i++) {
		db2keywords.push(new vscode.CompletionItem(keywords[i],type))
	}
	return db2keywords
}

function returnRestrictKeywords(keywords, type) {
	const db2keywords = []
	let myitem = (text) => {
		let item = new vscode.CompletionItem(text, type);
		db2keywords.push(item)
	}
	for (let i = 0;i<keywords.length;i++) {
		myitem(keywords[i])
	}
	return db2keywords
}

module.exports = {
	defaultKeywords
}