const vscode = require("vscode");
const Utils = require("./src/utils");
const fs = require("fs");
const path = require("path");
const Constants = require("./src/constants");
const url = require('url');
const os = require('os');
const request = require('request');
const exec = require('child_process').exec;
const LanguageServer = require("./languageServer/server");

// this method is called when your extension is activated.
// The extension is activated the very first time the command is executed
function activate(context) {
  // Use the console to output diagnostic information (console.log) and errors (console.error)
  // This line of code will only be executed once when the extension is activated

  //let vscodeWrapper = new VscodeWrapper();
  let db2ConnectOutputChannel = vscode.window.createOutputChannel(
    Constants.outputChannelName
  );

  context.subscriptions.push(
    vscode.commands.registerCommand(Constants.cmdRebuild, () => {
      rebuildNativeModules();
    })
  );

  context.subscriptions.push(
    vscode.commands.registerCommand(Constants.cmdReportIssue, () =>{
      reportIssue();
    })
  );

  LanguageServer.defaultKeywords(context, db2ConnectOutputChannel)

  //This rebuild workaround can be removed once Microsoft fixes the issue: https://github.com/Microsoft/vscode/issues/23251
  if (Utils.isRebuildDone(context.extensionPath, db2ConnectOutputChannel)) {
    try {
      const MainController = require("./src/controllers/mainController");
      const treeProvider = require("./src/tree/treeProvider");
      let treeProvider1 = treeProvider.IBM_DBTreeDataprovider.getInstance(context);
      controller = new MainController(
        context,
        db2ConnectOutputChannel,
        undefined /*vscodeWrapper*/
      );
      context.subscriptions.push(controller);
      controller.activate();
    }
    catch (err) {
      db2ConnectOutputChannel.appendLine(err);
      vscode.window.showErrorMessage(Constants.errRebuildFail);
    }
  } else {
    //Utils.registerTemporaryCommands(context);
    Utils.cleanNativeModules(context.extensionPath, db2ConnectOutputChannel);

    vscode.window.withProgress(
      {
        location: vscode.ProgressLocation.Notification,
        title: Constants.extensionName,
        cancellable: false
      },
      progress => {
        progress.report({ message: Constants.infRebuildWait });
        return new Promise(function(resolve, reject) {
          //Function to download and install node-ibm_db
          var install_node_ibm_db = function(file_url) {
            var installerURL = 'https://github.com/ibmdb/node-ibm_db/archive/';
            var CURRENT_DIR = context.extensionPath
            var DOWNLOAD_DIR = path.resolve(CURRENT_DIR, 'node_modules');
            var INSTALLER_FILE; 
            var deleteInstallerFile = false;
            var platform = os.platform();
            var arch = os.arch();
            var electronVersion = (process.versions.electron).split('.');
            var fileName;
            var readStream;
            var IBM_DB_HOME;
            var installerfileURL;
            if (platform == 'darwin') {
              fileName = "_mac_" + electronVersion[0];
            } else if (platform == 'win32') {
              fileName = "_win_" + electronVersion[0];
            } else {
              fileName = "_linux_" + electronVersion[0];
            }
            var unzipper = require('unzipper');
            installerfileURL = installerURL + 'master.zip';
            var file_name = url.parse(installerfileURL).pathname.split('/').pop();
            INSTALLER_FILE = path.resolve(DOWNLOAD_DIR, file_name);
            db2ConnectOutputChannel.appendLine('Downloading node ibm_db Driver from ' +
                  installerfileURL+'...\n');

            fs.stat(installerfileURL, function (err, stats) {
                if (!err && stats.isFile()) {
                    INSTALLER_FILE = installerfileURL;
                    return copyAndExtractNodeDriver();
                }
                return downloadNodeDriver(installerfileURL);
            });

            function copyAndExtractNodeDriver() {
              readStream = fs.createReadStream(INSTALLER_FILE);

              // Using the "unzipper" module to extract the zipped "clidriver",
              // and on successful close, printing the license_agreement
              var extractCLIDriver = readStream.pipe(unzipper.Extract({path: DOWNLOAD_DIR}));

              extractCLIDriver.on('close', function() {
                db2ConnectOutputChannel.appendLine('Downloading and extraction of node ibm_db ' +
                      'Driver completed successfully... \n');
                  renameFolder(true);
                  if(deleteInstallerFile) removeInstallerFile();
              });

              extractCLIDriver.on('err', function() {
                db2ConnectOutputChannel.appendLine(err);
                vscode.window.showErrorMessage(Constants.errRebuildFail);
                reject();
              });
            }

            function renameFolder(isDownloaded) {
              if(isDownloaded){
                  const currPath = path.resolve(DOWNLOAD_DIR, "node-ibm_db-master")
                  const newPath = path.resolve(DOWNLOAD_DIR, "ibm_db")
                  fs.exists(newPath, function(exists) 
                  {
                      if (exists) 
                      {
                        fs.rmdir(newPath, { recursive: true }, (err) => {
                          if (err) {
                            console.error(err);
                          } else {
                            renameFolder1(currPath, newPath)
                          }
                        });
                      } else {
                            renameFolder1(currPath, newPath)
                      }
                  });
              } else {
                db2ConnectOutputChannel.appendLine("failed during extraction");
                vscode.window.showErrorMessage(Constants.errRebuildFail);
                reject();
              }
            }

            var SetClidriver = function () {
                var installerURL = 'https://public.dhe.ibm.com/ibmdl/export/pub/software/data/db2/drivers/odbc_cli/';
                var CURRENT_DIR = context.extensionPath;
                var DOWNLOAD_DIR = path.resolve(CURRENT_DIR, 'node_modules/ibm_db/installer');
                var INSTALLER_FILE; 
                var deleteInstallerFile = false;
                var platform = os.platform();
                var arch = os.arch();
                var readStream_cli;
                var writeStream;
                var endian = os.endianness();
                var installerfileURL;
                var fstream = require('fstream');
                var unzipper = require('unzipper');
                db2ConnectOutputChannel.appendLine("platform = " + platform + ", arch = " + arch + ", node.js version = " + process.version);
                if(platform == 'win32') {
                    if(arch == 'x64') {
                        installerfileURL = installerURL + 'ntx64_odbc_cli.zip';
                    }
                }
                else if(platform == 'linux') 
                {
                    if(arch == 'x64') {
                        installerfileURL = installerURL + 'linuxx64_odbc_cli.tar.gz';
                    } else if(arch == 's390x') {
                        installerfileURL = installerURL + 's390x64_odbc_cli.tar.gz';
                    } else if(arch == 's390') {
                        installerfileURL = installerURL + 's390_odbc_cli.tar.gz';
                    } else if(arch == 'ppc64') {
                        if(endian == 'LE')
                            installerfileURL = installerURL + 'ppc64le_odbc_cli.tar.gz';
                        else
                            installerfileURL = installerURL + 'ppc64_odbc_cli.tar.gz';
                    } else if(arch == 'ppc32') {
                        installerfileURL = installerURL + 'ppc32_odbc_cli.tar.gz';
                    } else {
                        installerfileURL = installerURL + 'linuxia32_odbc_cli.tar.gz';
                    }
                } 
                else if(platform == 'darwin') 
                {
                    if(arch == 'x64') {
                        installerfileURL = installerURL + 'macos64_odbc_cli.tar.gz';
                    } else {
                      db2ConnectOutputChannel.appendLine('Mac OS 32 bit not supported. Please use an ' +
                                    'x64 architecture.\n');
                        return;
                    }
                } 
                else if(platform == 'aix')
                {
                    if(arch == 'ppc')
                    {
                        installerfileURL = installerURL + 'aix32_odbc_cli.tar.gz';
                    }
                    else
                    {
                        installerfileURL = installerURL + 'aix64_odbc_cli.tar.gz';
                    }
                }
                else if(platform == 'os390')
                {
                    // zOS ODBC driver is part of Db2 installation.  Users need to
                    // specify IBM_DB_HOME environment variable to the Db2 datasets
                    // to allow the installer to access the necessary header files and
                    // sidedeck definitions to build the node binding.
                    db2ConnectOutputChannel.appendLine('Please set the environment variable IBM_DB_HOME to the ' + 
                                'High Level Qualifier (HLQ) of your Db2 libraries.\n');
                    process.exit(1);
                }
                else {
                    installerfileURL = installerURL + platform + arch + 
                                        '_odbc_cli.tar.gz';
                }

                if(!installerfileURL) {
                  db2ConnectOutputChannel.appendLine('Unable to fetch driver download file. Exiting the ' +
                              'install process.\n');
                  process.exit(1);
                }

                var file_name = url.parse(installerfileURL).pathname.split('/').pop();
                INSTALLER_FILE = path.resolve(DOWNLOAD_DIR, file_name);
        
                db2ConnectOutputChannel.appendLine('Downloading DB2 ODBC CLI Driver from ' +
                            installerfileURL+'...\n');
        
                fs.stat(installerfileURL, function (err, stats) {
                    if (!err && stats.isFile()) {
                        INSTALLER_FILE = installerfileURL;
                        return copyAndExtractCliDriver();
                    }
                    return downloadCliDriver(installerfileURL);
                });

                // Function to download clidriver file using request module.
                function downloadCliDriver(installerfileURL) {
                  // Variable to save downloading progress
                  var received_bytes = 0;
                  var total_bytes = 0;
          
                  var outStream = fs.createWriteStream(INSTALLER_FILE);
          
                  request
                      .get(installerfileURL)
                          .on('error', function(err) {
                            db2ConnectOutputChannel.appendLine(err);
                          })
                          .on('response', function(data) {
                              total_bytes = parseInt(data.headers['content-length']);
                          })
                          .on('data', function(chunk) {
                              received_bytes += chunk.length;
                              showDownloadingProgress(received_bytes, total_bytes);
                          })
                          .pipe(outStream);
          
                  deleteInstallerFile = true;
                  outStream.once('close', copyAndExtractCliDriver)
                  .once('error', function (err) {
                    db2ConnectOutputChannel.appendLine(err);
                  });
                }

                function copyAndExtractCliDriver() {
                  if(platform == 'win32') {
                      readStream_cli = fs.createReadStream(INSTALLER_FILE);
                      // Using the "unzipper" module to extract the zipped "clidriver",
                      // and on successful close, printing the license_agreement
                      var extractCLIDriver1 = readStream_cli.pipe(unzipper.Extract({path: DOWNLOAD_DIR}));
                      extractCLIDriver1.on('close', function() {
                        db2ConnectOutputChannel.appendLine('Downloading and extraction of DB2 ODBC ' +
                              'CLI Driver completed successfully... \n');
          
                          IBM_DB_HOME = path.resolve(DOWNLOAD_DIR, 'clidriver');
                          process.env.IBM_DB_HOME = IBM_DB_HOME.replace(/\s/g,'\\ ');
                          ExtractBinaries();
                          if(deleteInstallerFile) removeInstallerFile();
                      });
          
                      extractCLIDriver1.on('err', function() {
                        db2ConnectOutputChannel.appendLine(err);
                      });
                  } 
                  else 
                  {
                      var targz = require('targz');
                      var compress = targz.decompress({src: INSTALLER_FILE, dest: DOWNLOAD_DIR}, function(err){
                        if(err) {
                          db2ConnectOutputChannel.appendLine(err);
                          process.exit(1);
                        }
                        else {
                          db2ConnectOutputChannel.appendLine('Downloading and extraction of DB2 ODBC ' +
                                      'CLI Driver completed successfully ...\n');
                          IBM_DB_HOME = path.resolve(DOWNLOAD_DIR, 'clidriver');
                          process.env.IBM_DB_HOME = IBM_DB_HOME.replace(/\s/g,'\\ ');
                          ExtractBinaries();
                          if(deleteInstallerFile) removeInstallerFile();
                        }
                      });
                  }
                }

                function removeInstallerFile()
                {
                    // Delete downloaded odbc_cli.tar.gz file.
                    fs.exists(INSTALLER_FILE, function(exists) 
                    {
                        if (exists) 
                        {
                            fs.unlinkSync(INSTALLER_FILE);
                        }
                    });
                }
            } //SetClidriver

            function renameFolder1(currPath, newPath){
              fs.rename(currPath, newPath, function(err) {
                if (err) {
                  db2ConnectOutputChannel.appendLine(err);
                  vscode.window.showErrorMessage(Constants.errRebuildFail);
                  reject();
                } else {
                  db2ConnectOutputChannel.appendLine("Successfully renamed the directory.");
                  if (process.env.IBM_DB_HOME){
                    db2ConnectOutputChannel.appendLine("Using the existing CLI Driver");
                    ExtractBinaries();
                  } else {
                    SetClidriver();
                  }
                }
              })
            }

            function ExtractBinaries(){
              var platform = os.platform();
              var clidriver = process.env.IBM_DB_HOME;
              db2ConnectOutputChannel.appendLine(clidriver);
              if(platform == 'win32')
              {
                process.env.PATH = path.resolve(clidriver, 'bin') + ';' +
                                    path.resolve(clidriver, 'bin/amd64.VC12.CRT') + ';' +
                                    path.resolve(clidriver, 'bin/icc64') + ';' +
                                    path.resolve(clidriver, 'lib') + ';' + process.env.PATH;
                process.env.LIB =  path.resolve(clidriver, 'bin') + ';' +
                                    path.resolve(clidriver, 'bin/icc64') + ';' +
                                    path.resolve(clidriver, 'lib') + ';' + process.env.LIB;
              }
              else if(platform == 'linux') {
                process.env.PATH = path.resolve(clidriver, 'bin') + ':' +
                                    path.resolve(clidriver, 'lib') + ':' + process.env.PATH;
                process.env.LD_LIBRARY_PATH = path.resolve(clidriver, 'lib') + ':' +
                                              path.resolve(clidriver, 'lib/icc') + ':' + process.env.LD_LIBRARY_PATH;
              }
              else if(platform == 'darwin') {
                process.env.PATH = path.resolve(clidriver, 'bin') + ':' +
                                    path.resolve(clidriver, 'lib') + ':' + process.env.PATH;
                process.env.DYLD_LIBRARY_PATH = path.resolve(clidriver, 'lib') + ':' +
                                                path.resolve(clidriver, 'lib/icc') + ':' + process.env.DYLD_LIBRARY_PATH;
              }
              var BINARY_FILE = path.resolve(DOWNLOAD_DIR, "ibm_db/build.zip")
              var readStream1 = fs.createReadStream(BINARY_FILE);
              var BINARY_DOWNLOAD_DIR = path.resolve(DOWNLOAD_DIR,"ibm_db");
              // Using the "unzipper" module to extract the zipped "clidriver",
              // and on successful close, printing the license_agreement
              var extractCLIDriver = readStream1.pipe(unzipper.Extract({path: BINARY_DOWNLOAD_DIR}));

              extractCLIDriver.on('close', function() {
                db2ConnectOutputChannel.appendLine('Extraction of build.zip ' +
                      'completed successfully... \n');

                  renameBinary();
              });

              extractCLIDriver.on('err', function() {
                db2ConnectOutputChannel.appendLine(err);
                vscode.window.showErrorMessage(Constants.errRebuildFail);
                reject();
              });
            }

            function renameBinary(){
                const path1 = path.resolve(DOWNLOAD_DIR,"ibm_db/build/Release/odbc_bindings.node");
                fs.unlink(path1, (err) => {
                    if (err) {
                        console.error(err);
                        vscode.window.showErrorMessage(Constants.errRebuildFail);
                        reject();
                    }
                    renameElectronBinary();
                });
            }

            function renameElectronBinary(){
              const currPath = path.resolve(DOWNLOAD_DIR,"ibm_db/build/Release/odbc_bindings"+fileName+".node");
              const newPath = path.resolve(DOWNLOAD_DIR,"ibm_db/build/Release/odbc_bindings.node");
              fs.rename(currPath, newPath, function(err) {
                if (err) {
                  db2ConnectOutputChannel.appendLine(err);
                  vscode.window.showErrorMessage(Constants.errRebuildFail);
                  reject();
                } else {
                  if(platform == 'darwin' && arch == 'x64') {
                    // Run the install_name_tool
                    //var addonBinary = "./build/Release/odbc_bindings.node";
                    var addonBinary = path.resolve(CURRENT_DIR, 'node_modules/ibm_db/build/Release/odbc_bindings.node');
                    var addonlib = path.resolve(CURRENT_DIR, 'node_modules/ibm_db/installer/clidriver/lib/libdb2.dylib');
                    var nameToolCommand = "install_name_tool -change libdb2.dylib " + addonlib + " " + addonBinary;
                    var nameToolCmdProcess = exec(nameToolCommand , 
                    function (error1, stdout1, stderr1) {
                      if (error1 !== null) {
                        db2ConnectOutputChannel.appendLine('Error setting up the lib path to ' +
                        'odbc_bindings.node file.Error trace:\n'+error1);
                        process.exit(1);
                      } else {
                        db2ConnectOutputChannel.appendLine("Successfully renamed the Electron binary");
                        try{
                          const MainController = require("./src/controllers/mainController");
                          const treeProvider = require("./src/tree/treeProvider");
                          let treeProvider1 = treeProvider.IBM_DBTreeDataprovider.getInstance(context);
                          controller = new MainController(
                            context,
                            db2ConnectOutputChannel,
                            undefined /*vscodeWrapper*/
                          );
                          context.subscriptions.push(controller);
                          controller.activate();
                          fs.closeSync(
                            fs.openSync(
                              path.join(context.extensionPath, Constants.rebuildMarkerFile),
                              "w"
                            )
                          );
                          vscode.window.showInformationMessage(
                            "Finished successfully installing the native modules"
                          );
                          resolve();
                        }
                        catch (err){
                          db2ConnectOutputChannel.appendLine(err);
                          vscode.window.showErrorMessage(Constants.errRebuildFail);
                          reject();
                        }
                      }
                    });
                  } else {
                    db2ConnectOutputChannel.appendLine("Successfully renamed the Electron binary");
                    try {
                      const MainController = require("./src/controllers/mainController");
                      const treeProvider = require("./src/tree/treeProvider");
                      let treeProvider1 = treeProvider.IBM_DBTreeDataprovider.getInstance(context);
                      controller = new MainController(
                        context,
                        db2ConnectOutputChannel,
                        undefined /*vscodeWrapper*/
                      );
                      context.subscriptions.push(controller);
                      controller.activate();
                      fs.closeSync(
                        fs.openSync(
                          path.join(context.extensionPath, Constants.rebuildMarkerFile),
                          "w"
                        )
                      );
                      vscode.window.showInformationMessage(
                        "Finished successfully installing the native modules"
                      );
                      resolve();
                    } 
                    catch (err){
                      db2ConnectOutputChannel.appendLine(err);
                      vscode.window.showErrorMessage(Constants.errRebuildFail);
                      reject();
                    }
                  }
                }
              })
            }

            function removeInstallerFile() {
              // Delete downloaded odbc_cli.tar.gz file.
              fs.exists(INSTALLER_FILE, function(exists) 
              {
                if (exists) 
                {
                  fs.unlinkSync(INSTALLER_FILE);
                }
              });
            }

            // Function to download clidriver file using request module.
            function downloadNodeDriver(installerfileURL) {
              // Variable to save downloading progress
              var received_bytes = 0;
              var total_bytes = 0;
              var outStream = fs.createWriteStream(INSTALLER_FILE);
              request
                  .get(installerfileURL)
                      .on('error', function(err) {
                        db2ConnectOutputChannel.appendLine(err);
                        vscode.window.showErrorMessage(Constants.errRebuildFail);
                        reject();
                      })
                      .on('response', function(data) {
                          total_bytes = parseInt(data.headers['content-length']);
                      })
                      .on('data', function(chunk) {
                          received_bytes += chunk.length;
                          showDownloadingProgress(received_bytes, total_bytes);
                      })
                      .pipe(outStream);
              deleteInstallerFile = true;
              outStream.once('close', copyAndExtractNodeDriver)
              .once('error', function (err) {
                db2ConnectOutputChannel.appendLine(err);
                vscode.window.showErrorMessage(Constants.errRebuildFail);
                reject();
              });
            }

            function showDownloadingProgress(received, total) {
                var percentage = ((received * 100) / total).toFixed(2);
                db2ConnectOutputChannel.appendLine((platform == 'win32') ? "\033[0G": "\r");
                db2ConnectOutputChannel.appendLine(percentage + "% | " + received + " bytes downloaded out of " + total + " bytes.");
            }
          }; //install_node_ibm_db

          install_node_ibm_db();
        });
      }
    );
  }

  function rebuildNativeModules(){
    vscode.window.withProgress(
      {
        location: vscode.ProgressLocation.Notification,
        title: "Db2Connect Extension",
        cancellable: false
      },
      progress => {
        progress.report({ message: "Rebuilding the native node modules..." });
        //return controller.activate();
        try {
          Utils.cleanNativeModules(context.extensionPath, db2ConnectOutputChannel);
        } catch (e){
          db2ConnectOutputChannel.appendLine(e);
          vscode.window.showInformationMessage("This command can we used only when major electron version is used in the vscode release");
          return new Promise(function(resolve, reject) {
            reject()
          })
        }
        return new Promise(function(resolve, reject) {
          //Function to download and install node-ibm_db
          var install_node_ibm_db = function(file_url) {
              var installerURL = 'https://github.com/ibmdb/node-ibm_db/archive/';
              var CURRENT_DIR = context.extensionPath
              var DOWNLOAD_DIR = path.resolve(CURRENT_DIR, 'node_modules');
              var INSTALLER_FILE; 
              var deleteInstallerFile = false;
              var platform = os.platform();
              var arch = os.arch();
              var electronVersion = (process.versions.electron).split('.');
              var fileName;
              var readStream;
              var IBM_DB_HOME;
              var installerfileURL;
              if (platform == 'darwin') {
                fileName = "_mac_" + electronVersion[0];
              } else if (platform == 'win32') {
                fileName = "_win_" + electronVersion[0];
              } else {
                fileName = "_linux_" + electronVersion[0];
              }
              var unzipper = require('unzipper');
              installerfileURL = installerURL + 'master.zip';
              var file_name = url.parse(installerfileURL).pathname.split('/').pop();
              INSTALLER_FILE = path.resolve(DOWNLOAD_DIR, file_name);
              db2ConnectOutputChannel.appendLine('Downloading node ibm_db Driver from ' +
                    installerfileURL+'...\n');

              fs.stat(installerfileURL, function (err, stats) {
                  if (!err && stats.isFile()) {
                      INSTALLER_FILE = installerfileURL;
                      return copyAndExtractNodeDriver();
                  }
                  return downloadNodeDriver(installerfileURL);
              });

              function copyAndExtractNodeDriver() {
                readStream = fs.createReadStream(INSTALLER_FILE);

                // Using the "unzipper" module to extract the zipped "clidriver",
                // and on successful close, printing the license_agreement
                var extractCLIDriver = readStream.pipe(unzipper.Extract({path: DOWNLOAD_DIR}));

                extractCLIDriver.on('close', function() {
                  db2ConnectOutputChannel.appendLine('Downloading and extraction of node ibm_db' +
                        'Driver completed successfully... \n');
                    renameFolder(true);
                    if(deleteInstallerFile) removeInstallerFile();
                });

                extractCLIDriver.on('err', function() {
                  db2ConnectOutputChannel.appendLine(err);
                  vscode.window.showErrorMessage(Constants.errRebuildFail);
                  reject();
                });
              }

              function renameFolder(isDownloaded) {
                if(isDownloaded){
                    const currPath = path.resolve(DOWNLOAD_DIR, "node-ibm_db-master")
                    const newPath = path.resolve(DOWNLOAD_DIR, "ibm_db")
                    fs.exists(newPath, function(exists) 
                    {
                      if (exists) 
                      {
                        fs.rmdir(newPath, { recursive: true }, (err) => {
                          if (err) {
                            db2ConnectOutputChannel.appendLine(err);
                            vscode.window.showErrorMessage(Constants.errRebuildFail);
                            reject();
                          } else {
                            renameFolder1(currPath, newPath)
                          }
                        });
                      } else {
                            renameFolder1(currPath, newPath)
                      }
                    });
                } else {
                  db2ConnectOutputChannel.appendLine("failed during extraction");
                  vscode.window.showErrorMessage(Constants.errRebuildFail);
                  reject();
                }
              }

              var SetClidriver = function () {
                  var installerURL = 'https://public.dhe.ibm.com/ibmdl/export/pub/software/data/db2/drivers/odbc_cli/';
                  var CURRENT_DIR = context.extensionPath;
                  var DOWNLOAD_DIR = path.resolve(CURRENT_DIR, 'node_modules/ibm_db/installer');
                  var INSTALLER_FILE; 
                  var deleteInstallerFile = false;
                  var platform = os.platform();
                  var arch = os.arch();
                  var readStream_cli;
                  var writeStream;
                  var endian = os.endianness();
                  var installerfileURL;
                  var fstream = require('fstream');
                  var unzipper = require('unzipper');
                  db2ConnectOutputChannel.appendLine("platform = " + platform + ", arch = " + arch + ", node.js version = " + process.version);
                  if(platform == 'win32') {
                      if(arch == 'x64') {
                          installerfileURL = installerURL + 'ntx64_odbc_cli.zip';
                      }
                  }
                  else if(platform == 'linux') 
                  {
                      if(arch == 'x64') {
                          installerfileURL = installerURL + 'linuxx64_odbc_cli.tar.gz';
                      } else if(arch == 's390x') {
                          installerfileURL = installerURL + 's390x64_odbc_cli.tar.gz';
                      } else if(arch == 's390') {
                          installerfileURL = installerURL + 's390_odbc_cli.tar.gz';
                      } else if(arch == 'ppc64') {
                          if(endian == 'LE')
                              installerfileURL = installerURL + 'ppc64le_odbc_cli.tar.gz';
                          else
                              installerfileURL = installerURL + 'ppc64_odbc_cli.tar.gz';
                      } else if(arch == 'ppc32') {
                          installerfileURL = installerURL + 'ppc32_odbc_cli.tar.gz';
                      } else {
                          installerfileURL = installerURL + 'linuxia32_odbc_cli.tar.gz';
                      }
                  } 
                  else if(platform == 'darwin') 
                  {
                      if(arch == 'x64') {
                          installerfileURL = installerURL + 'macos64_odbc_cli.tar.gz';
                      } else {
                        db2ConnectOutputChannel.appendLine('Mac OS 32 bit not supported. Please use an ' +
                                      'x64 architecture.\n');
                          return;
                      }
                  } 
                  else if(platform == 'aix')
                  {
                      if(arch == 'ppc')
                      {
                          installerfileURL = installerURL + 'aix32_odbc_cli.tar.gz';
                      }
                      else
                      {
                          installerfileURL = installerURL + 'aix64_odbc_cli.tar.gz';
                      }
                  }
                  else if(platform == 'os390')
                  {
                      // zOS ODBC driver is part of Db2 installation.  Users need to
                      // specify IBM_DB_HOME environment variable to the Db2 datasets
                      // to allow the installer to access the necessary header files and
                      // sidedeck definitions to build the node binding.
                      db2ConnectOutputChannel.appendLine('Please set the environment variable IBM_DB_HOME to the ' + 
                                  'High Level Qualifier (HLQ) of your Db2 libraries.\n');
                      process.exit(1);
                  }
                  else {
                      installerfileURL = installerURL + platform + arch + 
                                         '_odbc_cli.tar.gz';
                  }
  
                  if(!installerfileURL) {
                    db2ConnectOutputChannel.appendLine('Unable to fetch driver download file. Exiting the ' +
                                'install process.\n');
                    process.exit(1);
                  }
  
                  var file_name = url.parse(installerfileURL).pathname.split('/').pop();
                  INSTALLER_FILE = path.resolve(DOWNLOAD_DIR, file_name);
          
                  db2ConnectOutputChannel.appendLine('Downloading DB2 ODBC CLI Driver from ' +
                              installerfileURL+'...\n');
          
                  fs.stat(installerfileURL, function (err, stats) {
                      if (!err && stats.isFile()) {
                          INSTALLER_FILE = installerfileURL;
                          return copyAndExtractCliDriver();
                      }
                      return downloadCliDriver(installerfileURL);
                  });

                  // Function to download clidriver file using request module.
                  function downloadCliDriver(installerfileURL) {
                    // Variable to save downloading progress
                    var received_bytes = 0;
                    var total_bytes = 0;
            
                    var outStream = fs.createWriteStream(INSTALLER_FILE);
            
                    request
                        .get(installerfileURL)
                            .on('error', function(err) {
                              db2ConnectOutputChannel.appendLine(err);
                              vscode.window.showErrorMessage(Constants.errRebuildFail);
                              reject();
                            })
                            .on('response', function(data) {
                                total_bytes = parseInt(data.headers['content-length']);
                            })
                            .on('data', function(chunk) {
                                received_bytes += chunk.length;
                                showDownloadingProgress(received_bytes, total_bytes);
                            })
                            .pipe(outStream);
            
                    deleteInstallerFile = true;
                    outStream.once('close', copyAndExtractCliDriver)
                    .once('error', function (err) {
                      db2ConnectOutputChannel.appendLine(err);
                      vscode.window.showErrorMessage(Constants.errRebuildFail);
                      reject();
                    });
                  }

                  function copyAndExtractCliDriver() {
                    if(platform == 'win32') {
                        readStream_cli = fs.createReadStream(INSTALLER_FILE);
                        // Using the "unzipper" module to extract the zipped "clidriver",
                        // and on successful close, printing the license_agreement
                        var extractCLIDriver1 = readStream_cli.pipe(unzipper.Extract({path: DOWNLOAD_DIR}));
                        extractCLIDriver1.on('close', function() {
                          db2ConnectOutputChannel.appendLine('Downloading and extraction of DB2 ODBC ' +
                                'CLI Driver completed successfully... \n');
            
                            IBM_DB_HOME = path.resolve(DOWNLOAD_DIR, 'clidriver');
                            process.env.IBM_DB_HOME = IBM_DB_HOME.replace(/\s/g,'\\ ');
                            ExtractBinaries();
                            if(deleteInstallerFile) removeInstallerFile();
                        });
            
                        extractCLIDriver1.on('err', function() {
                          db2ConnectOutputChannel.appendLine(err);
                          vscode.window.showErrorMessage(Constants.errRebuildFail);
                          reject();
                        });
                    } 
                    else 
                    {
                        var targz = require('targz');
                        var compress = targz.decompress({src: INSTALLER_FILE, dest: DOWNLOAD_DIR}, function(err){
                          if(err) {
                            db2ConnectOutputChannel.appendLine(err);
                            process.exit(1);
                          }
                          else {
                            db2ConnectOutputChannel.appendLine('Downloading and extraction of DB2 ODBC ' +
                                        'CLI Driver completed successfully ...\n');
                            IBM_DB_HOME = path.resolve(DOWNLOAD_DIR, 'clidriver');
                            process.env.IBM_DB_HOME = IBM_DB_HOME.replace(/\s/g,'\\ ');
                            ExtractBinaries();
                            if(deleteInstallerFile) removeInstallerFile();
                          }
                        });
                    }
                  }

                  function removeInstallerFile()
                  {
                      // Delete downloaded odbc_cli.tar.gz file.
                      fs.exists(INSTALLER_FILE, function(exists) 
                      {
                          if (exists) 
                          {
                              fs.unlinkSync(INSTALLER_FILE);
                          }
                      });
                  }
              } //SetClidriver

              function renameFolder1(currPath, newPath){
                fs.rename(currPath, newPath, function(err) {
                  if (err) {
                    db2ConnectOutputChannel.appendLine(err);
                    vscode.window.showErrorMessage(Constants.errRebuildFail);
                    reject();
                  } else {
                    db2ConnectOutputChannel.appendLine("Successfully renamed the directory.");
                    var platform = os.platform();
                    if (platform == 'darwin') {
                      SetClidriver();
                    } else {
                      if (process.env.IBM_DB_HOME){
                        db2ConnectOutputChannel.appendLine("Using the existing CLI Driver");
                        ExtractBinaries();
                      } else {
                        SetClidriver();
                      }
                    }
                  }
                })
              }

              function ExtractBinaries(){
                var platform = os.platform();
                var clidriver = process.env.IBM_DB_HOME;
                if(platform == 'win32')
                {
                  process.env.PATH = path.resolve(clidriver, 'bin') + ';' +
                                      path.resolve(clidriver, 'bin/amd64.VC12.CRT') + ';' +
                                      path.resolve(clidriver, 'bin/icc64') + ';' +
                                      path.resolve(clidriver, 'lib') + ';' + process.env.PATH;
                  process.env.LIB =  path.resolve(clidriver, 'bin') + ';' +
                                      path.resolve(clidriver, 'bin/icc64') + ';' +
                                      path.resolve(clidriver, 'lib') + ';' + process.env.LIB;
                }
                else if(platform == 'linux') {
                  process.env.PATH = path.resolve(clidriver, 'bin') + ':' +
                                      path.resolve(clidriver, 'lib') + ':' + process.env.PATH;
                  process.env.LD_LIBRARY_PATH = path.resolve(clidriver, 'lib') + ':' +
                                                path.resolve(clidriver, 'lib/icc') + ':' + process.env.LD_LIBRARY_PATH;
                }
                else if(platform == 'darwin') {
                  process.env.PATH = path.resolve(clidriver, 'bin') + ':' +
                                      path.resolve(clidriver, 'lib') + ':' + process.env.PATH;
                  process.env.DYLD_LIBRARY_PATH = path.resolve(clidriver, 'lib') + ':' +
                                                  path.resolve(clidriver, 'lib/icc') + ':' + process.env.DYLD_LIBRARY_PATH;
                }
                  var BINARY_FILE = path.resolve(DOWNLOAD_DIR, "ibm_db/build.zip")
                  var readStream1 = fs.createReadStream(BINARY_FILE);
                  var BINARY_DOWNLOAD_DIR = path.resolve(DOWNLOAD_DIR,"ibm_db");
                  // Using the "unzipper" module to extract the zipped "clidriver",
                  // and on successful close, printing the license_agreement
                  var extractCLIDriver = readStream1.pipe(unzipper.Extract({path: BINARY_DOWNLOAD_DIR}));

                  extractCLIDriver.on('close', function() {
                    db2ConnectOutputChannel.appendLine('Extraction of build.zip completed successfully... \n');
                    renameBinary();
                  });

                  extractCLIDriver.on('err', function() {
                    db2ConnectOutputChannel.appendLine(err);
                    vscode.window.showErrorMessage(Constants.errRebuildFail);
                    reject();
                  });
              }

              function renameBinary(){
                  const path1 = path.resolve(DOWNLOAD_DIR,"ibm_db/build/Release/odbc_bindings.node");
                  fs.unlink(path1, (err) => {
                      if (err) {
                          db2ConnectOutputChannel.appendLine(err);
                          vscode.window.showErrorMessage(Constants.errRebuildFail);
                          reject();
                      }
                      renameElectronBinary();
                  });
              }

              function renameElectronBinary(){
                const currPath = path.resolve(DOWNLOAD_DIR,"ibm_db/build/Release/odbc_bindings"+fileName+".node");
                const newPath = path.resolve(DOWNLOAD_DIR,"ibm_db/build/Release/odbc_bindings.node");
                fs.rename(currPath, newPath, function(err) {
                    if (err) {
                      db2ConnectOutputChannel.appendLine(err);
                      vscode.window.showErrorMessage(Constants.errRebuildFail);
                      reject();
                    } else {
                        if(platform == 'darwin' && arch == 'x64') {
                          // Run the install_name_tool
                          //var addonBinary = "./build/Release/odbc_bindings.node";
                          var addonBinary = path.resolve(CURRENT_DIR, 'node_modules/ibm_db/build/Release/odbc_bindings.node');
                          var addonlib = path.resolve(CURRENT_DIR, 'node_modules/ibm_db/installer/clidriver/lib/libdb2.dylib');
                          var nameToolCommand = "install_name_tool -change libdb2.dylib " + addonlib + " " + addonBinary;
                          var nameToolCmdProcess = exec(nameToolCommand , 
                          function (error1, stdout1, stderr1) {
                            if (error1 !== null) {
                              db2ConnectOutputChannel.appendLine('Error setting up the lib path to ' +
                              'odbc_bindings.node file.Error trace:\n'+error1);
                              process.exit(1);
                            } else {
                                db2ConnectOutputChannel.appendLine("Successfully renamed the Electron binary");
                                try{
                                  const MainController = require("./src/controllers/mainController");
                                  const treeProvider = require("./src/tree/treeProvider");
                                  let treeProvider1 = treeProvider.IBM_DBTreeDataprovider.getInstance(context);
                                  controller = new MainController(
                                    context,
                                    db2ConnectOutputChannel,
                                    undefined /*vscodeWrapper*/
                                  );
                                  context.subscriptions.push(controller);
                                  controller.activate();
                                  fs.closeSync(
                                    fs.openSync(
                                      path.join(context.extensionPath, Constants.rebuildMarkerFile),
                                      "w"
                                    )
                                  );
                                  vscode.window.showInformationMessage(
                                    "Finished successfully installing the native modules"
                                  );
                                  resolve();
                                }
                                catch (err){
                                  db2ConnectOutputChannel.appendLine(err);
                                  vscode.window.showErrorMessage(Constants.errRebuildFail);
                                  reject();
                                }
                            }
                          });
                        } else {
                          db2ConnectOutputChannel.appendLine("Successfully renamed the Electron binary");
                          try {
                            const MainController = require("./src/controllers/mainController");
                            const treeProvider = require("./src/tree/treeProvider");
                            let treeProvider1 = treeProvider.IBM_DBTreeDataprovider.getInstance(context);
                            controller = new MainController(
                              context,
                              db2ConnectOutputChannel,
                              undefined /*vscodeWrapper*/
                            );
                            context.subscriptions.push(controller);
                            controller.activate();
                            fs.closeSync(
                              fs.openSync(
                                path.join(context.extensionPath, Constants.rebuildMarkerFile),
                                "w"
                              )
                            );
                            vscode.window.showInformationMessage(
                              "Finished successfully installing the native modules"
                            );
                            resolve();
                          }
                          catch (err){
                            db2ConnectOutputChannel.appendLine(err);
                            vscode.window.showErrorMessage(Constants.errRebuildFail);
                            reject();
                          }
                        }
                    }
                })
              }

              function removeInstallerFile()
              {
                  // Delete downloaded odbc_cli.tar.gz file.
                  fs.exists(INSTALLER_FILE, function(exists) 
                  {
                      if (exists) 
                      {
                          fs.unlinkSync(INSTALLER_FILE);
                      }
                  });
              }

              // Function to download clidriver file using request module.
              function downloadNodeDriver(installerfileURL) {
                  // Variable to save downloading progress
                  var received_bytes = 0;
                  var total_bytes = 0;

                  var outStream = fs.createWriteStream(INSTALLER_FILE);

                  request
                      .get(installerfileURL)
                          .on('error', function(err) {
                            db2ConnectOutputChannel.appendLine(err);
                            vscode.window.showErrorMessage(Constants.errRebuildFail);
                            reject();
                          })
                          .on('response', function(data) {
                              total_bytes = parseInt(data.headers['content-length']);
                          })
                          .on('data', function(chunk) {
                              received_bytes += chunk.length;
                              showDownloadingProgress(received_bytes, total_bytes);
                          })
                          .pipe(outStream);

                  deleteInstallerFile = true;
                  outStream.once('close', copyAndExtractNodeDriver)
                  .once('error', function (err) {
                    db2ConnectOutputChannel.appendLine(err);
                    vscode.window.showErrorMessage(Constants.errRebuildFail);
                    reject();
                  });
              }

              function showDownloadingProgress(received, total) {
                  var percentage = ((received * 100) / total).toFixed(2);
                  db2ConnectOutputChannel.appendLine((platform == 'win32') ? "\033[0G": "\r");
                  db2ConnectOutputChannel.appendLine(percentage + "% | " + received + " bytes downloaded out of " + total + " bytes.");
              }
          }; //install_node_ibm_db

          install_node_ibm_db();
        });
      }
    );
  }

  function reportIssue(){
    vscode.commands.executeCommand('vscode.open', vscode.Uri.parse(`https://github.com/ibmdb/vscode-extension`));
  }
}
exports.activate = activate;

// this method is called when the extension is deactivated
function deactivate() {
  if (controller) {
    controller.deactivate();
  }
}
exports.deactivate = deactivate;
