const fs = require("fs");
const Utils = require('../utils')
const path = require("path");
const Constants = require("../constants");
const os = require("os");
//const jsContent = require("../views/jsonContent");

class ProfileManager {
  constructor() {
    this.profileFile = undefined;
    this.extPath = undefined;
    this.initDone = false;
  }

  getProfileFileUri(cb) {
    let ret = Constants.strSuccess;

    try {
      if (!this.initDone) {
        ret = this.init();
        if (ret == Constants.strSuccess) {
          cb(this.profileFile, true);
        } else {
          throw Error(ret);
        }
      } else {
        cb(this.profileFile, true);
      }
    } catch (e) {
      console.log(e);
      cb(e.message, false);
    }
  }

  init() {
    let extPath;
    let ret = Constants.strSuccess;

    try {
      if (os.type() == Constants.strWinOS) {
        if (!process.env.USERPROFILE) {
          throw new Error(Constants.errUserProfDir);
        } else {
          extPath = path.resolve(
            process.env.USERPROFILE,
            ".vscode",
            "extensions"
          );
        }
      } else {
        if (!process.env.HOME) {
          throw new Error(Constants.errHomeDir);
        } else {
          extPath = path.resolve(process.env.HOME, ".vscode", "extensions");
        }
      }

      this.extPath = path.resolve(extPath, Constants.extFolderName);
      this.profileFile = path.resolve(this.extPath, Constants.extProfileFile);

      //Create db2connect folder if it does not exist
      if (!fs.existsSync(this.extPath)) {
        fs.mkdirSync(this.extPath);
        //console.log("Db2 Connect folder not present, creating now.");
      }

      //Confirming if directory is present, if yes, check for profile file
      if (fs.existsSync(this.extPath)) {
        if (!fs.existsSync(this.profileFile)) {
          //console.log("Creating profile file now." + this.profileFile);
          fs.writeFileSync(this.profileFile, /*jsContent.sampleProf()*/ "");
        }
      } else {
        //Failed to create the directory
        //console.log("Failed to create Db2 Connect folder.");
      }
      this.initDone = true;
    } catch (e) {
      ret = e.message;
    }

    return ret;
  }

  readProfilesFromDisk(cb) {
    let allProfiles = [];
    let ret = Constants.strSuccess;

    try {
      if (!this.initDone) {
        ret = this.init();
      }

      if (ret == Constants.strSuccess) {
        if (fs.existsSync(this.profileFile)) {
          let content;
          content = fs.readFileSync(this.profileFile);

          if (content.length) {
            allProfiles = JSON.parse(content);
          }
        } else {
          //Failed to create the profile file
          ret = `${Constants.errCdFileReadWrite}: ${this.profileFile}`;
        }
      } else {
        throw Error(ret);
      }
    } catch (e) {
      console.log(e);
      if (e.message && e.message.indexOf("JSON") != -1) {
        ret = `${Constants.errJsonParsing}:${this.profileFile}`;
      } else {
        ret = e.message;
      }
    }

    cb(allProfiles, ret);
  }

  saveProfileToDisk(profile, cb) {
    let ret = Constants.strSuccess;
    profile.Password = Utils.encrypt(profile.Password);
    if (!this.initDone) {
      ret = this.init();
    }

    if (fs.existsSync(this.profileFile)) {
      let allProfiles = {};
      let content = null;

      try {
        content = fs.readFileSync(this.profileFile);

        if (content.length) {
          allProfiles = JSON.parse(content);
        }

        allProfiles[profile.Name] = profile;

        fs.writeFileSync(
          this.profileFile,
          JSON.stringify(allProfiles, null, 4)
        );
        //console.log(`Finished writing ${allProfiles} to ${this.profileFile}`);
      } catch (e) {
        ret = `${Constants.errCdFileReadWrite}: ${this.profileFile} : ${e}`;
      }
    } else {
      //Failed to create the profile file
      ret = `${Constants.errCdFileCreation}: ${this.profileFile}`;
    }

    cb(ret);
  }

  updateProfileInDisk(profile, cb){
    let ret = Constants.strSuccess;
    if (!this.initDone) {
      ret = this.init();
    }
    if (fs.existsSync(this.profileFile)) {
      let allProfiles = {};
      let content = null;

      try {
        content = fs.readFileSync(this.profileFile);

        if (content.length) {
          allProfiles = JSON.parse(content.toString());
        }
        profile.Password = Utils.encrypt(profile.Password);
        allProfiles[profile.Name] = profile
        fs.writeFileSync(
          this.profileFile,
          JSON.stringify(allProfiles, null, 4)
        );
        //console.log(`Finished writing ${allProfiles} to ${this.profileFile}`);
      } catch (e) {
        ret = `${Constants.errCdFileReadWrite}: ${this.profileFile} : ${e}`;
      }
    }else {
      //Failed to create the profile file
      ret = `${Constants.errCdFileCreation}: ${this.profileFile}`;
    }
    if(ret == Constants.strSuccess){
      cb(Constants.updateSuccess);
    } else {
      cb(ret)
    }
  }

  deleteProfileInDisk(profile, cb){
    let ret = Constants.strSuccess;
    if (!this.initDone) {
      ret = this.init();
    }
    if (fs.existsSync(this.profileFile)) {
      let allProfiles = {};
      let content = null;

      try {
        content = fs.readFileSync(this.profileFile);

        if (content.length) {
          allProfiles = JSON.parse(content.toString());
        }

        delete allProfiles[profile]

        fs.writeFileSync(
          this.profileFile,
          JSON.stringify(allProfiles, null, 4)
        );
        //console.log(`Finished writing ${allProfiles} to ${this.profileFile}`);
      } catch (e) {
        ret = `${Constants.errCdFileReadWrite}: ${this.profileFile} : ${e}`;
      }
    }else {
      //Failed to create the profile file
      ret = `${Constants.errCdFileCreation}: ${this.profileFile}`;
    }
    if(ret == Constants.strSuccess){
      cb(Constants.deleteSuccess);
    } else {
      cb(ret)
    }
  }
}

module.exports = ProfileManager;
