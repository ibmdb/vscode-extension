const ibmdb = require("ibm_db");
const Constants = require("../constants");
const treeProvider = require("../tree/treeProvider");

class ConnectionManager {
  constructor(connString, profile = undefined) {
    this.connString = connString;
    this.connStatus = false;
    this.connObj = null;
    this.dbName = undefined;
    this.hostName = undefined;
    this.user = undefined;
    this.pwd = undefined;
    this.port = undefined;
    this.serverName = undefined;
    this.dsn = undefined;
    this.profile = profile;
  }

  connect(cb) {
    //Try to deduce the parameters from conn string;
    let pattMatch = this.connString.match(/DATABASE=([ +\-!@#$%^&*()_.<>?=\w]*)/i);
    if (pattMatch && pattMatch.length > 0) {
      this.dbName = pattMatch[1];
    }

    pattMatch = this.connString.match(/HOSTNAME=([ +\-!@#$%^&*()_.<>?=\w]*)/i);
    if (pattMatch && pattMatch.length > 0) {
      this.hostName = pattMatch[1];
    }

    pattMatch = this.connString.match(/UID=([ +\-!@#$%^&*()_.<>?=\w]*)/i);
    if (pattMatch && pattMatch.length > 0) {
      this.user = pattMatch[1];
    }

    pattMatch = this.connString.match(/PWD=([ +\-!@#$%^&*()_.<>?=\w]*)/i);
    if (pattMatch && pattMatch.length > 0) {
      this.pwd = pattMatch[1];
    }

    pattMatch = this.connString.match(/PORT=([ +\-!@#$%^&*()_.<>?=\w]*)/i);
    if (pattMatch && pattMatch.length > 0) {
      this.port = pattMatch[1];
    }

    pattMatch = this.connString.match(/DSN=([ +\-!@#$%^&*()_.<>?=\w]*)/i);
    if (pattMatch && pattMatch.length > 0) {
      this.dsn = pattMatch[1];
    }

    ibmdb.open(this.connString, (err, conn) => {
      if (err) {
        cb(err, false);
      } else {
        let id;
        if (this.profile) {
          id = this.connString + ";profile=" + this.profile
        } else {
          id = this.connString
        }
        this.connObj = conn;
        let name = conn.getInfoSync(ibmdb.SQL_DBMS_NAME);
        if (name == "DB2") {
          this.serverName = "zos"
        } else if (name == "AS"){
          this.serverName = "iseries"
        } else {
          this.serverName = "luw"
        }
        if (this.dsn){
        Constants.connections[this.dsn] = {"dsn":this.dsn, "database":this.dsn, "connString":this.connString, "serverName":this.serverName, "connObj":this.connObj};
        } else {
          Constants.connections[id] = {"host":this.hostName, "database":this.dbName, "schema":this.user, "pwd":this.pwd, "port":this.port, "connString":this.connString, "serverName":this.serverName, "connObj":this.connObj, "profile":this.profile};
        }
        const tree = treeProvider.IBM_DBTreeDataprovider.getInstance();
        tree.refresh();
        cb({ db: this.dbName, host: this.hostName, user: this.user, connString: this.connString, connObj: this.connObj, serverName: this.serverName  }, true);
      }
    });
  }

  test(cs, cb){
    ibmdb.open(cs, (err, conn) => {
      if (err) {
        cb(err, false);
      } else {
        cb(undefined, true);
      }
    });
  }

  update(con, cb){
    this.dbName = con.database
    this.hostName = con.host
    this.user = con.schema
    this.pwd = con.pwd
    this.port = con.port
    this.connString = con.connString
    this.serverName = con.serverName
    this.connObj = con.connObj
    cb({ db: this.dbName, host: this.hostName, user: this.user });
  }

  executeQuery(q, cb) {
    this.connObj.query(q, (err, rows, sqlca) => {
      if (err) {
        //console.log(err);
        cb(err, false);
      } else {
        cb(rows, true);
      }
    });
  }

  executeNonQuery(q, cb) {
    this.connObj.prepare(q, function(err, stmt) {
      if (err) {
        //console.log(err);
        return cb(`${Constants.strError}: ${err}`, false);
      }

      //Bind and Execute the statment asynchronously
      stmt.executeNonQuery(function(err, result) {
        if (err) {
          //console.log(err);
          return cb(err, false);
        } else {        
          //In some cases closing of StatementHandle is also needed stmt.closeSync();
          return cb(
            `${Constants.strSuccess}: ${result} ${Constants.strRowsAff}`,
            true
          );
        }
      });
    });
  }

  terminate() {
    this.connString = undefined;
    this.connStatus = undefined;
    this.connObj = undefined;
    this.dbName = undefined;
    this.hostName = undefined;
    this.user = undefined;
    this.pwd = undefined;
    this.port = undefined;
    this.serverName = undefined;
  }
}

module.exports = ConnectionManager;
