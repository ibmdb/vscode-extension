var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
  return new (P || (P = Promise))(function (resolve, reject) {
      function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
      function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
      function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
      step((generator = generator.apply(thisArg, _arguments || [])).next());
  });
};
const vscode = require("vscode");
const Constants = require("../constants");
const ConnectionManager = require("../models/ConnectionManager");
const UIManager = require("../views/UIManager");
const ProfileManager = require("../models/ProfileManager");
const treeProvider = require("../tree/treeProvider");
const Utils = require("../utils");
const path = require("path");
const fs = require("fs");
const os = require("os");
const EasyXml = require('easyxml');
const LanguageServer = require("../../languageServer/dbServer");

/**
 * The main controller class that initializes the extension
 */
class MainController extends vscode.Disposable {
  constructor(context, outputChannel, vscodeWrapper) {
    super();
    this._connectionManager = undefined;
    this._profileManager = new ProfileManager();
    this._uiManager = new UIManager(context);
    this._context = context;
    this._extensionPath = context.extensionPath;
    this._connStatusBar = undefined;
    this._ignoreFocusOut = false;
    this._queryList = [];
    this._outputChannel = outputChannel;
  }

  initialize() {
    const self = this;
    return new Promise((resolve, reject) => {
      resolve(true);
    });
  }

  registerCommand(command, cb) {
    const self = this;
    this._context.subscriptions.push(
      vscode.commands.registerCommand(command, () => {
        cb();
      })
    );
  }

  activate() {
    const self = this;

    this.registerCommand(Constants.cmdConnect, () => {
      self.connectOptions();
    });
    // this.registerCommand(Constants.cmdDisconnect, () => {
    //   self.disconnect();
    // });
    this.registerCommand(Constants.cmdRunQuery, () => {
      self.executeQuery();
    });
    this.registerCommand(Constants.cmdExecuteFile, () => {
      self.executeFile();
    });
    this.registerCommand(Constants.cmdShowHistory, () => {
      self.showHistory();
    });
    this.registerCommand(Constants.cmdRunNonQuery, () => {
      self.executeNonQuery();
    });
    this.registerCommand(Constants.cmdManageConnProfiles, () => {
      self.manageProfiles();
    });
    this.registerCommand(Constants.cmdRunSingleQuery, () =>{
      self.runSingleQuery();
    });
    this.registerCommand(Constants.cmdRunMultipleQuery, () =>{
      self.runMultipleQuery();
    });
    this.registerCommand(Constants.cmdRunSqlFile, () =>{
      self.runMultipleQuery();
    });
    let disposable = vscode.commands.registerCommand(Constants.cmdDisconnect, self.disconnect, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdAddLicense, self.addLicense, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdOpenFile, self.getSPText, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdCallSP, self.callSP, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdSelectTop, self.SelectTop, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdSelectTop1000, self.SelectTop1000, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdInsertData, self.InsertData, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdRefresh, self.refresh, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdCreateSQL, self.createSQL, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdCreateSP, self.createSP, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdCreateUDF, self.createUDF, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdCreateIndex, self.createIndex, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdCreateTrigger, self.createTrigger, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdCreateSchema, self.createSchema, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdGetSchemaName, self.getSchemaName, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdCreateTable, self.createSQL, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdCreateView, self.createView, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdCreateAlias, self.createAlias, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdgetFuncBody,self.getFuncBody, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdExportResult, self.exportResult, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdgetTriggerBody, self.getTriggerBody, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdgetViewBody, self.getViewBody, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmddeleteTable, self.deleteTable, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmddescribeTable, self.describeTable, self);
    this._context.subscriptions.push(disposable);
    disposable = vscode.commands.registerCommand(Constants.cmdsetActiveConnection, self.setActiveConnection, self);
    this._context.subscriptions.push(disposable);
  }

  helloWorld() {
    vscode.window.showInformationMessage(this._extensionPath);
    //this._outputChannel.appendLine("HelloWorld");
  }

  manageProfiles() {
    const pickListItems = [];

    const option1 = {
      label: Constants.descProfCreate
    };
    const option2 = {
      label: Constants.descProfEdit
    };
    const option3 = {
      label: Constants.descProfDelete
    };
    pickListItems.push(option1, option2);

    if (!this._profileManager) {
      this._profileManager = new ProfileManager();
    }
    vscode.window
      .showQuickPick(pickListItems, {
        ignoreFocusOut: this._ignoreFocusOut,
        placeHolder: Constants.phProfileAction
      })
      .then(selected => {
        if (selected) {
          if (selected == option1) {
            this.createConnProfile();
          } else if (selected == option2){
            this.editConnProfile();
          } else {
            this.deleteConnProfile();
          }
        }
      });
  }

  createConnProfile() {
    this._uiManager.showProfilePanel(profile => {
      this._profileManager.saveProfileToDisk(profile, ret => {
        if (ret == Constants.strSuccess) {
          vscode.window.showInformationMessage(Constants.infProfSuccess);
        } else {
          vscode.window.showErrorMessage(`${Constants.errProfFail}:${ret}`);
        }
      });
    });
  }

  editConnProfile(){
    //Edit the available connection profiles
    this._profileManager.getProfileFileUri((path, ret) => {
    if (ret) {
      if (Utils.getFilesizeInBytes(path) != 0){
        var content = fs.readFileSync(path)
        this._uiManager.showEditProfPanel(content.toString(), cs => {
          if (cs.profile) {
            this._profileManager.updateProfileInDisk(cs.profile,css =>{
              vscode.window.showInformationMessage(css)
            });
          } else {
            this._profileManager.deleteProfileInDisk(cs.profileDelete, css =>{
              vscode.window.showInformationMessage(css)
            });
          }
        })
      } else {
        vscode.window.showErrorMessage(Constants.errEmptyProfileE);
      }
    } else {
      vscode.window.showErrorMessage(ret);
    }
    });
  }

  deleteConnProfile(){
    this._profileManager.getProfileFileUri((path, ret) => {
      if (ret) {
        if (Utils.getFilesizeInBytes(path) != 0){
          var content = fs.readFileSync(path)
          this._uiManager.showDeleteProfPanel(content.toString(), cs => {
            this._profileManager.deleteProfileInDisk(cs, css =>{
              vscode.window.showInformationMessage(css)
            })
          })
        }
        else {
          vscode.window.showErrorMessage(Constants.errEmptyProfileD);
        }
      } else {
        vscode.window.showErrorMessage(ret);
      }
      });
  }

  connectOptions() {
    const pickListItems = [];

    // if (this._connectionManager) {
    //   vscode.window.showErrorMessage(Constants.errConnExists);
    //   return;
    // }

    const option1 = {
      label: "Option 1",
      description: Constants.descConnOp1
    };
    const option2 = {
      label: "Option 2",
      description: Constants.descConnOp2
    };
    const option3 = {
      label: "Option 3",
      description: Constants.descConnOp3
    };

    pickListItems.push(option1, option2, option3);

    vscode.window
      .showQuickPick(pickListItems, {
        ignoreFocusOut: this._ignoreFocusOut,
        placeHolder: Constants.phConnOption
      })
      .then(selected => {
        if (selected) {
          if (selected == option1) {
            this.connectUsingConnString();
          } else if (selected == option2) {
            this.connectUsingManual();
          } else {
            this.connectUsingProfile();
          }
        }
      });
  }

  connectUsingConnString() {
    vscode.window
      .showInputBox({
        ignoreFocusOut: this._ignoreFocusOut,
        placeHolder: Constants.phConnString,
        prompt: Constants.prConnString
      })
      .then(inp => {
        if (inp) {
          this.initiateConnection(inp);
        }
      });
  }

  connectUsingManual() {
    this._uiManager.showConnectPanel(cs => {
      this.initiateConnection(cs);
    });
  }

  connectUsingProfile() {
    this._profileManager.readProfilesFromDisk((listObj, ret) => {
      if (ret == Constants.strSuccess) {
        vscode.window
          .showQuickPick(Object.keys(listObj), {
            ignoreFocusOut: this._ignoreFocusOut,
            placeHolder: Constants.phSavedProfile
          })
          .then(selected => {
            if (selected) {
              try {
                let cs = Utils.makeConnStrFromProfile(listObj[selected]);
                this.initiateConnection(cs, selected);
              } catch (e) {
                if (e.message.length) {
                  console.log(e.message);
                }
                vscode.window.showErrorMessage(Constants.errGeneric);
              }
            }
          });
      } else {
        vscode.window.showErrorMessage(ret);
      }
    });
  }

  initiateConnection(connString, profile = undefined) {
    let com = vscode.window.setStatusBarMessage(Constants.sbConnAttempt);

    this._connectionManager = new ConnectionManager(connString, profile);

    this._connectionManager.connect((info, status) => {
      com.dispose();
      if (status) {
        if (this._connStatusBar) {
          this._connStatusBar.dispose();
        }
        this._connStatusBar = undefined;
        const sbStr = Utils.makeStatusBarMsgOnConn(info);
        vscode.window.showInformationMessage(Constants.infConnSuccess);
        this._connStatusBar = vscode.window.setStatusBarMessage(sbStr);
        LanguageServer.db2MetaData(info, this._context)
      } else {
        vscode.window.showErrorMessage(`${Constants.errConnFail}: ${info}`);
        this._connectionManager = undefined;
      }
    });
  }

  setActiveConnection(connection){
    if (this._connStatusBar) {
      this._connStatusBar.dispose();
    }
    this._connStatusBar = undefined;
    if (connection.profile) {
      this._connectionManager = new ConnectionManager(connection.connString, connection.profile);
    } else {
      this._connectionManager = new ConnectionManager(connection.connString);
    }
    this._connectionManager.update(connection,(info) => {
      const sbStr = Utils.makeStatusBarMsgOnConn(info);
      this._connStatusBar = vscode.window.setStatusBarMessage(sbStr);
    });
    LanguageServer.db2MetaData(connection, this._context)
  }

  addLicense(){
    vscode.window
    .showOpenDialog({
      canSelectMany: false,
      openLabel: Constants.strInstall,
      title: Constants.strSelectLicFile
    }).then(uri => {
      if (uri && uri[0]) {
        uri = uri[0].fsPath;
      }
      if (uri != undefined) {
        var fileName = path.basename(uri);
        var copyPath;
        if (process.env.IBM_DB_HOME){
          copyPath = path.resolve(process.env.IBM_DB_HOME, "license");
        } else {
          copyPath = path.resolve(this._extensionPath, "node_modules/ibm_db/installer/clidriver/license");
        }
        fs.copyFile(uri, path.resolve(copyPath, fileName), (err) => {
          if (err) {
            vscode.window.showErrorMessage(err)
          }
          vscode.window.showInformationMessage("License Installed Successfully");
        });
      }
    });
  }

  executeQuery() {
    if (this._connectionManager) {
      // Display a message box to the user
      vscode.window
        .showInputBox({
          ignoreFocusOut: this._ignoreFocusOut,
          placeHolder: Constants.phSelectFrom,
          prompt: Constants.prInpQuery
        })
        .then(inp => {
          if(inp != undefined && inp != ''){
            let com = vscode.window.setStatusBarMessage(Constants.sbQueryInProg);
            this._queryList.push(`[${new Date().toUTCString()}]: ${inp}`);
            this._connectionManager.executeQuery(inp, (msg, ret) => {
              com.dispose();
              if (ret) {
                if (!this._uiManager) {
                  this._uiManager = new UIManager();
                }
                this._uiManager.showResultPanel(inp, msg);
                const tree = treeProvider.IBM_DBTreeDataprovider.getInstance();
                tree.refresh();
              } else {
                vscode.window.showErrorMessage(
                  `${Constants.errQueryFail}: ${msg}`
                );
              }
            });
          } else {
          }
        });
    } else {
      //No connection exists
      //Below code is only for testing purpose to play around with the grid w/o connecting to DB
      // const temp = [
      //   { COLUMN1: "value1", COLUMN2: 1, COLUMN3: "2", COLUMN4: 3 },
      //   { COLUMN1: "value2", COLUMN2: 4, COLUMN3: "5", COLUMN4: 6 }
      // ];
      // const uiMgr = new UIManager();
      // uiMgr.showResultPanel("SAMPLE RESULT", temp);
      vscode.window.showErrorMessage(Constants.errDbConnQuery);
    }
  }

  executeNonQuery() {
    if (this._connectionManager) {
      // Display a message box to the user
      vscode.window
        .showInputBox({
          ignoreFocusOut: this._ignoreFocusOut,
          placeHolder: Constants.phInsertInto,
          prompt: Constants.prInpQuery
        })
        .then(inp => {
          if(inp != undefined && inp != ''){
          let com = vscode.window.setStatusBarMessage(Constants.sbQueryInProg);
          this._queryList.push(`[${new Date().toUTCString()}]: ${inp}`);
          this._connectionManager.executeNonQuery(inp, (msg, ret) => {
            com.dispose();
            if (ret) {
              vscode.window.showInformationMessage(msg);
              const tree = treeProvider.IBM_DBTreeDataprovider.getInstance();
              tree.refresh();
            } else {
              vscode.window.showErrorMessage(`${Constants.errSttFail}: ${msg}`);
            }
          });
        }
        });
    } else {
      //No connection exists
      vscode.window.showErrorMessage(Constants.errDbConnQuery);
    }
  }

  executeFile() {
    let self = this;
    if (this._connectionManager) {
      // Display a message box to the user
      vscode.window
        .showOpenDialog({
          canSelectMany: false,
          openLabel: Constants.strExecute,
          title: Constants.strSelectFile
        })
        .then(uri => {
          if (uri && uri[0]) {
            uri = uri[0].fsPath;
          }
          if(uri != undefined){
            vscode.window.showInputBox({placeHolder: Constants.strGetDelimiter}).then(
              delimiter => {
                if(delimiter) {
                  delimiter = delimiter.trim();
                }
                if(!delimiter) delimiter = ";";
                let com = vscode.window.setStatusBarMessage(Constants.sbQueryInProg);
                fs.readFile(uri, 'utf8', function (err, sqls) {
                  if (err) {
                    vscode.window.showErrorMessage(err);
                  }
                  else {
                    self.executeMultipleSQL(uri, sqls, delimiter);
                    com.dispose();
                    const tree = treeProvider.IBM_DBTreeDataprovider.getInstance();
                    tree.refresh();
                  }
                }); //fs.readFile
              }); //showInputBox
            }
        });
    } else {
      vscode.window.showErrorMessage(Constants.errDbConnCommand);
    }
  }

  showHistory() {
    const newFile = vscode.Uri.parse(
      "untitled:" + path.join(this._context.extensionPath, "cmds_untitled")
    );
    let fileContent;
    if (this._queryList.length) {
      fileContent = this._queryList.join("\n");
    } else {
      fileContent = "Nothing to show";
    }
    vscode.workspace.openTextDocument(newFile).then(document => {
      const edit = new vscode.WorkspaceEdit();
      edit.insert(newFile, new vscode.Position(0, 0), fileContent);
      return vscode.workspace.applyEdit(edit).then(success => {
        if (success) {
          vscode.window.showTextDocument(document);
          vscode.languages.setTextDocumentLanguage(document, "db2_luw");
        } else {
          vscode.window.showInformationMessage("Error!");
        }
      });
    });
  }

  disconnect(treeNode) {
    if (this._connectionManager) {
      let constr;
      if (this._connectionManager.profile != undefined) {
        constr = this._connectionManager.connString + ";profile=" + this._connectionManager.profile
      } else {
        constr = this._connectionManager.connString
      }
      this._connectionManager.terminate();
      this._connectionManager = undefined;
      if (treeNode)
      {
        delete Constants.connections[treeNode.id]
        LanguageServer.disposedb2MetaData()
      } else {
        delete Constants.connections[constr]
        LanguageServer.disposedb2MetaData()
      }
      const tree = treeProvider.IBM_DBTreeDataprovider.getInstance();
      tree.refresh();
      vscode.window.showInformationMessage(Constants.infConnTerm);
      if (Object.keys(Constants.connections).length >= 1){
        vscode.window.showInformationMessage(Constants.infOtherConn)
      }
      if (this._connStatusBar) {
        this._connStatusBar.dispose();
      }
      this._connStatusBar = undefined;
    } else {
      vscode.window.showErrorMessage(Constants.errNoActConn);
    }
  }

  createSQL(treeNode){
    return __awaiter(this, void 0, void 0, function* () {
      let languageType = '';
      if (treeNode.connection.serverName == "luw") {
        languageType = 'db2_luw'
      } else if (treeNode.connection.serverName == "zos"){
        languageType = 'db2_z'
      } else {
        languageType = 'db2_i'
      }
      if (!this._connectionManager) {
        vscode.window.showErrorMessage(Constants.errDbConnCommand);
        return;
      }
      let name = this.addSchema(treeNode, "MYTAB");
      const sql = `\nCREATE TABLE ${name} (\n  col1 INT,\n  col2 VARCHAR(20),\n  col3 INT\n);\n`;
      const textDocument = yield vscode.workspace.openTextDocument({ content: sql, language: languageType });
      yield vscode.window.showTextDocument(textDocument);
    });
  }

  createSchema(treeNode){
    return __awaiter(this, void 0, void 0, function* () {
      if (!this._connectionManager) {
        vscode.window.showErrorMessage(Constants.errDbConnCommand);
        return;
      }
      let languageType = '';
      if (treeNode.connection.serverName == "luw") {
        languageType = 'db2_luw'
      } else if (treeNode.connection.serverName == "zos"){
        languageType = 'db2_z'
      } else {
        languageType = 'db2_i'
      }
      let name = "MYSCHEMA";
      const sql = `\nCREATE SCHEMA ${name};\n`;
      const textDocument = yield vscode.workspace.openTextDocument({ content: sql, language: languageType });
      yield vscode.window.showTextDocument(textDocument);
    });
  }

  getSchemaName() {
    if (!this._connectionManager) {
      vscode.window.showErrorMessage(Constants.errDbConnCommand);
      return;
    }
    vscode.window
      .showInputBox({
        ignoreFocusOut: this._ignoreFocusOut,
        placeHolder: Constants.phSchemaName,
        prompt: Constants.prInpSchema
      })
      .then(inp => {
        if (inp) {
          let com = vscode.window.setStatusBarMessage(Constants.sbSchemaInProg);
          const sql = `CREATE SCHEMA ${inp};\n`;
          this._connectionManager.executeQuery(sql, (msg, ret) => {
            com.dispose();
            if (ret) {
              const tree = treeProvider.IBM_DBTreeDataprovider.getInstance();
              tree.refresh();
              vscode.window.showInformationMessage(Constants.infSchemaCreated + inp);
            } else {
              vscode.window.showErrorMessage(
                `${Constants.errQueryFail}: ${msg}`
              );
            }
          });
        }
      });
  }

  createView(treeNode){
    return __awaiter(this, void 0, void 0, function* () {
      if (!this._connectionManager) {
        vscode.window.showErrorMessage(Constants.errDbConnCommand);
        return;
      }
      let languageType = '';
      if (treeNode.connection.serverName == "luw") {
        languageType = 'db2_luw'
      } else if (treeNode.connection.serverName == "zos"){
        languageType = 'db2_z'
      } else {
        languageType = 'db2_i'
      }
      let name = this.addSchema(treeNode, "MYVIEW");
      let tabname = this.addSchema(treeNode, "MYTAB");
      const sql = `\nCREATE VIEW ${name} (c1, c2)\nAS\n(SELECT col1, col2 FROM ${tabname});\n`;
      const textDocument = yield vscode.workspace.openTextDocument({ content: sql, language: languageType });
      yield vscode.window.showTextDocument(textDocument);
    });
  }

  createAlias(treeNode){
    return __awaiter(this, void 0, void 0, function* () {
      if (!this._connectionManager) {
        vscode.window.showErrorMessage(Constants.errDbConnCommand);
        return;
      }
      let languageType = '';
      if (treeNode.connection.serverName == "luw") {
        languageType = 'db2_luw'
      } else if (treeNode.connection.serverName == "zos"){
        languageType = 'db2_z'
      } else {
        languageType = 'db2_i'
      }
      let name = this.addSchema(treeNode, "MYALIAS");
      let tabname = this.addSchema(treeNode, "MYTAB");
      const sql = `\nCREATE /* OR REPLACE */ /* PUBLIC */ ALIAS ${name} FOR TABLE ${tabname};\n`;
      const textDocument = yield vscode.workspace.openTextDocument({ content: sql, language: languageType });
      yield vscode.window.showTextDocument(textDocument);
    });
  }

  createIndex(treeNode){
      if (!this._connectionManager) {
        vscode.window.showErrorMessage(Constants.errDbConnCommand);
        return;
      }
      let languageType = '';
      if (treeNode.connection.serverName == "luw") {
        languageType = 'db2_luw'
      } else if (treeNode.connection.serverName == "zos"){
        languageType = 'db2_z'
      } else {
        languageType = 'db2_i'
      }
      let name = this.addSchema(treeNode, "MYINDEX");
      let tabname = this.addSchema(treeNode, "MYTAB");
      const sql = `\nCREATE INDEX ${name} ON ${tabname}(COL1, COL2);\n`;
      vscode.workspace.openTextDocument({ content: sql, language: languageType }).then(
        textDocument => {
          vscode.window.showTextDocument(textDocument);
        });
  }

  createSP(treeNode){
    return __awaiter(this, void 0, void 0, function* () {
      if (!this._connectionManager) {
        vscode.window.showErrorMessage(Constants.errDbConnCommand);
        return;
      }
      let languageType = '';
      if (treeNode.connection.serverName == "luw") {
        languageType = 'db2_luw'
      } else if (treeNode.connection.serverName == "zos"){
        languageType = 'db2_z'
      } else {
        languageType = 'db2_i'
      }
      let procName = this.addSchema(treeNode, "MYPROC");
      const sql = `\nCREATE PROCEDURE ${procName} ( IN v1 INT, INOUT v2 VARCHAR(30), OUT v3 DATE )\n`+
                  "  DYNAMIC RESULT SETS 2\n"+
                  "  LANGUAGE SQL\n"+
                  "  BEGIN\n" +
                  "    DECLARE cursorName1 CURSOR WITH RETURN FOR\n" +
                  "      SELECT 1 FROM SYSIBM.SYSDUMMY1;\n" +
                  "    DECLARE cursorName2 CURSOR WITH RETURN FOR\n" +
                  "      SELECT 2 FROM SYSIBM.SYSDUMMY1;\n" +
                  "    OPEN cursorName1; OPEN cursorName2;\n" +
                  "    SET v2 = 'success';\n" +
                  "    SET v3 = CURRENT DATE;\n" +
                  "  END\n";
      ;
      const textDocument = yield vscode.workspace.openTextDocument({ content: sql, language: languageType });
      yield vscode.window.showTextDocument(textDocument);
    });
  }

  createUDF(treeNode){
    return __awaiter(this, void 0, void 0, function* () {
      if (!this._connectionManager) {
        vscode.window.showErrorMessage(Constants.errDbConnCommand);
        return;
      }
      let languageType = '';
      if (treeNode.connection.serverName == "luw") {
        languageType = 'db2_luw'
      } else if (treeNode.connection.serverName == "zos"){
        languageType = 'db2_z'
      } else {
        languageType = 'db2_i'
      }
      let name = this.addSchema(treeNode, "average");
      const sql = `\n/*Check this doc for UDF Syntax: https://www.ibm.com/support/knowledgecenter/SSEPGG_11.5.0/com.ibm.db2.luw.sql.ref.doc/doc/r0000917.html*/\n\n`+
                  `CREATE /* OR REPLACE */ FUNCTION ${name} (\n` +
                  "  var1  INTEGER,\n" +
                  "  var2  INTEGER )\n" +
                  "RETURN INTEGER\n" +
                  "IS\n" +
                  "BEGIN\n" +
                  "  RETURN (var1 + var2) / 2;\n" +
                  "END average;\n";
      const textDocument = yield vscode.workspace.openTextDocument({ content: sql, language: languageType });
      yield vscode.window.showTextDocument(textDocument);
    });
  }

  createTrigger(treeNode){
    return __awaiter(this, void 0, void 0, function* () {
      if (!this._connectionManager) {
        vscode.window.showErrorMessage(Constants.errDbConnCommand);
        return;
      }
      let languageType = '';
      if (treeNode.connection.serverName == "luw") {
        languageType = 'db2_luw'
      } else if (treeNode.connection.serverName == "zos"){
        languageType = 'db2_z'
      } else {
        languageType = 'db2_i'
      }
      let name = this.addSchema(treeNode, "User_ChangeTracking");
      let tabName = this.addSchema(treeNode, "users");
      const sql = `/* CREATE TABLE ${tabName} (C1 INT); */\n\n` +
                  `CREATE /*OR REPLACE*/ TRIGGER ${name}\n` +
                  `  AFTER INSERT ON ${tabName}\n` +
                  `  FOR EACH STATEMENT\n` +
                  `  BEGIN ATOMIC\n` +
                  `    SELECT * FROM ${tabName};\n` +
                  `  END;\n`;
      const textDocument = yield vscode.workspace.openTextDocument({ content: sql, language: languageType });
      yield vscode.window.showTextDocument(textDocument);
    });
  }

  addSchema(treeNode, name) {
    let schema = "";
    if(treeNode && treeNode.schemaName) {
      schema = treeNode.schemaName.trim() + ".";
    } else if (this._connectionManager.user) {
      schema = this._connectionManager.user.toUpperCase() + ".";
    }
    return schema + name;
  }

  SelectTop(treeNode){
    if (!this._connectionManager) {
      vscode.window.showErrorMessage(Constants.errDbConnCommand);
    }
    let sql =``;
    if (treeNode.table) {
      sql = `SELECT * FROM "${treeNode.schemaName.trim()}"."${treeNode.table}" FETCH FIRST N ROWS ONLY;`;
    } else if (treeNode.view) {
      sql = `SELECT * FROM "${treeNode.schemaName.trim()}"."${treeNode.view}" FETCH FIRST N ROWS ONLY;`;
    } else if (treeNode.alias){
      sql = `SELECT * FROM "${treeNode.schemaName.trim()}"."${treeNode.alias}" FETCH FIRST N ROWS ONLY;`;
    }
    vscode.window.showInputBox({value: sql}).then(
      Inp => {
        if (Inp) {
          let com = vscode.window.setStatusBarMessage(Constants.sbQueryInProg);
          this._connectionManager.executeQuery(Inp, (msg, ret) => {
            com.dispose();
            if (ret) {
              if (!this._uiManager) {
                this._uiManager = new UIManager();
              }
              this._uiManager.showResultPanel(Inp, msg);
            } else {
              vscode.window.showErrorMessage(
                `${Constants.errQueryFail}: ${msg}`
              );
            }
          });
        }
      }
    )
  }

  SelectTop1000(treeNode){
    if (!this._connectionManager) {
      vscode.window.showErrorMessage(Constants.errDbConnCommand);
      return;
    }
    let com = vscode.window.setStatusBarMessage(Constants.sbQueryInProg);
    let sql =``;
    if (treeNode.table) {
      sql = `SELECT * FROM "${treeNode.schemaName.trim()}"."${treeNode.table}" FETCH FIRST 1000 ROWS ONLY;`;
    } else if (treeNode.view) {
      sql = `SELECT * FROM "${treeNode.schemaName.trim()}"."${treeNode.view}" FETCH FIRST 1000 ROWS ONLY;`;
    } else if (treeNode.alias){
      sql = `SELECT * FROM "${treeNode.schemaName.trim()}"."${treeNode.alias}" FETCH FIRST 1000 ROWS ONLY;`;
    }
    this._connectionManager.executeQuery(sql, (msg, ret) => {
      com.dispose();
      if (ret) {
        if (!this._uiManager) {
          this._uiManager = new UIManager();
        }
        this._uiManager.showResultPanel(sql, msg);
      } else {
        vscode.window.showErrorMessage(
          `${Constants.errQueryFail}: ${msg}`
        );
      }
    });
  }

  deleteTable(treeNode){
    if (!this._connectionManager) {
      vscode.window.showErrorMessage(Constants.errDbConnCommand);
      return;
    }
    let formats = ['Yes','No'];
    vscode.window.showQuickPick(formats,{placeHolder: "Do you really want to delete"}).then(selected => {
      if (selected == 'Yes'){
        let com = vscode.window.setStatusBarMessage(Constants.sbQueryInProg);
        let sql = ``;
        if (treeNode.schemaN){
          sql = `DROP SCHEMA "${treeNode.schemaN.trim()}" RESTRICT;`
        } else if (treeNode.table) {
          sql = `DROP TABLE "${treeNode.schemaName.trim()}"."${treeNode.table}";`;
        } else if(treeNode.view){
          sql = `DROP VIEW "${treeNode.schemaName.trim()}"."${treeNode.view}";`
        } else if(treeNode.alias){
          sql = `DROP ALIAS "${treeNode.schemaName.trim()}"."${treeNode.alias}";`
        } else if(treeNode.trigger){
          sql = `DROP TRIGGER "${treeNode.schemaName.trim()}"."${treeNode.trigger}";`
        } else if(treeNode.funcName){
          sql = `DROP FUNCTION "${treeNode.schemaName.trim()}"."${treeNode.funcName}";`
        } else if(treeNode.spName){
          if (treeNode.connection.serverName == 'zos') {
            sql = `DROP PROCEDURE ${treeNode.spName};`
          } else {
            sql = `DROP SPECIFIC PROCEDURE ${treeNode.spid};`
          }
        } else if(treeNode.index){
          sql = `DROP INDEX "${treeNode.schemaName.trim()}"."${treeNode.index}";`
        }
        this._connectionManager.executeNonQuery(sql, (msg, ret) => {
          com.dispose();
          if (ret) {
            vscode.window.showInformationMessage(msg);
            const tree = treeProvider.IBM_DBTreeDataprovider.getInstance();
            tree.refresh();
          } else {
            vscode.window.showErrorMessage(`${Constants.errSttFail}: ${msg}`);
          }
        });
      } else {
        return;
      }
    });
  }

  describeTable(treeNode){
    if (!this._connectionManager) {
      vscode.window.showErrorMessage(Constants.errDbConnCommand);
      return;
    }
    let com = vscode.window.setStatusBarMessage(Constants.sbQueryInProg);
    let sql = ``;
    let res;
    if (treeNode.connection.serverName == "luw") {
      sql = `select COLNAME, TYPENAME, LENGTH, SCALE, DEFAULT, NULLS, IDENTITY, GENERATED, CASE WHEN KEYSEQ > 0  then 'YES' else 'NO' end AS PRIMARY_KEY from SYSCAT.COLUMNS where TABSCHEMA = '${treeNode.schemaName.trim()}' and TABNAME = '${treeNode.table}' ORDER BY COLNO`;
      res = this._connectionManager.connObj.querySync(sql);
      let res_fkey;
      sql = `SELECT B.COLNAME as FKEY FROM SYSCAT.REFERENCES A, SYSCAT.KEYCOLUSE B WHERE A.CONSTNAME = B.CONSTNAME AND B.TABSCHEMA = '${treeNode.schemaName.trim()}' AND B.TABNAME = '${treeNode.table}'`
      res_fkey = this._connectionManager.connObj.querySync(sql);
      var i,j;
      if (res.length > 0){
        for (i=0;i<res.length;i++) {
          res[i].FOREGIN_KEY = 'NO'
          if (res_fkey.length > 0) {
            for (j=0;j<res_fkey.length;j++){
              if (res[i].COLNAME == res_fkey[j].FKEY){
                res[i].FOREGIN_KEY = 'YES'
                break
              }
            }
          }
        }
      }
      let res_index;
      sql = `SELECT rtrim(b.INDSCHEMA) concat '.' concat b.INDNAME as INDNAME1, b.COLNAME FROM SYSCAT.INDEXES a, SYSCAT.INDEXCOLUSE b WHERE a.INDNAME = b.INDNAME AND a.INDSCHEMA = b.INDSCHEMA AND a.TABSCHEMA = '${treeNode.schemaName.trim()}' AND a.TABNAME = '${treeNode.table}' AND (a.UNIQUERULE = 'D' OR a.UNIQUERULE = 'U')`;
      res_index = this._connectionManager.connObj.querySync(sql);
      if (res.length > 0){
        for (i=0;i<res.length;i++){
          res[i].INDEX_NAME = ""
          if (res_index.length > 0 ) { 
            for (j=0;j<res_index.length;j++){
              if (res[i].COLNAME == res_index[j].COLNAME){
                if (res[i].INDEX_NAME != "") {
                  res[i].INDEX_NAME = res[i].INDEX_NAME + ", " + res_index[j].INDNAME1
                } else {
                  res[i].INDEX_NAME = res_index[j].INDNAME1
                }
              }
            }
          }
        }
      }
    } else if (treeNode.connection.serverName == "zos"){
      sql = `select NAME as COLNAME, TYPENAME, LENGTH, SCALE, DEFAULT, NULLS, GENERATED_ATTR, CASE WHEN KEYSEQ > 0  then 'YES' else 'NO' end AS PRIMARY_KEY from SYSIBM.SYSCOLUMNS where TBCREATOR = '${treeNode.schemaName.trim()}' and TBNAME = '${treeNode.table}' ORDER BY COLNO`;
      res = this._connectionManager.connObj.querySync(sql);
      let res_fkey;
      sql = `SELECT COLNAME AS FKEY FROM SYSIBM.SYSFOREIGNKEYS A, SYSIBM.SYSRELS B WHERE A.RELNAME = B.RELNAME AND B.TBNAME = '${treeNode.table}' AND B.REFTBCREATOR = '${treeNode.schemaName.trim()}' AND B.REFTBCREATOR = A.CREATOR`
      res_fkey = this._connectionManager.connObj.querySync(sql);
      var i,j;
      if (res.length > 0){
        for (i=0;i<res.length;i++) {
          res[i].FOREGIN_KEY = 'NO'
          if (res_fkey.length > 0) {
            for (j=0;j<res_fkey.length;j++){
              if (res[i].COLNAME == res_fkey[j].FKEY){
                res[i].FOREGIN_KEY = 'YES'
                break
              }
            }
          }
        }
      }
      let res_index;
      sql = `SELECT rtrim(b.IXCREATOR) concat '.' concat b.IXNAME as INDNAME1, b.COLNAME FROM SYSIBM.SYSINDEXES a, SYSIBM.SYSKEYS b WHERE a.NAME = b.IXNAME AND a.CREATOR = b.IXCREATOR AND a.TBCREATOR = '${treeNode.schemaName.trim()}' AND a.TBNAME = '${treeNode.table}' AND (a.UNIQUERULE = 'D' OR a.UNIQUERULE = 'U')`;
      res_index = this._connectionManager.connObj.querySync(sql);
      if (res.length > 0){
        for (i=0;i<res.length;i++){
          res[i].INDEX_NAME = ""
          if (res_index.length > 0 ) { 
            for (j=0;j<res_index.length;j++){
              if (res[i].COLNAME == res_index[j].COLNAME){
                if (res[i].INDEX_NAME != "") {
                  res[i].INDEX_NAME = res[i].INDEX_NAME + ", " + res_index[j].INDNAME1
                } else {
                  res[i].INDEX_NAME = res_index[j].INDNAME1
                }
              }
            }
          }
        }
      }
    } else {
      sql = `select COLUMN_NAME as COLNAME, DATA_TYPE, LENGTH, NUMERIC_SCALE, IS_NULLABLE, COLUMN_DEFAULT, IDENTITY_GENERATION from QSYS2.SYSCOLUMNS where TABLE_NAME = '${treeNode.table}' and TABLE_SCHEMA = '${treeNode.schemaName.trim()}' ORDER BY ORDINAL_POSITION`;
      res = this._connectionManager.connObj.querySync(sql);
      let res_pkey;
      sql = `SELECT COLUMN_NAME as KEYSEQ FROM QSYS2.SYSKEYCST A, QSYS2.SYSCST B WHERE A.CONSTRAINT_NAME = B.CONSTRAINT_NAME AND A.TABLE_NAME = '${treeNode.table}' AND A.TABLE_SCHEMA = '${treeNode.schemaName.trim()}' AND B.CONSTRAINT_TYPE = 'PRIMARY KEY'`;
      res_pkey = this._connectionManager.connObj.querySync(sql);
      var i,j;
      if (res.length > 0){
        for (i=0;i<res.length;i++){
          res[i].PRIMARY_KEY = 'NO'
          for (j=0;j<res_pkey.length;j++){
            if (res[i].COLNAME == res_pkey[j].KEYSEQ){
              res[i].PRIMARY_KEY = 'YES'
              break
            }
          }
        }
      }
      let res_fkey;
      sql = `SELECT COLUMN_NAME as FKEY FROM QSYS2.SYSKEYCST A, QSYS2.SYSCST B, QSYS2.SYSREFCST C WHERE A.CONSTRAINT_NAME = B.CONSTRAINT_NAME AND A.CONSTRAINT_NAME = C.CONSTRAINT_NAME AND A.TABLE_NAME = '${treeNode.table}' AND A.TABLE_SCHEMA = '${treeNode.schemaName.trim()}' AND B.CONSTRAINT_TYPE = 'FOREIGN KEY'`
      res_fkey = this._connectionManager.connObj.querySync(sql);
      if (res.length > 0){
        for (i=0;i<res.length;i++) {
          res[i].FOREGIN_KEY = 'NO'
          if (res_fkey.length > 0) {
            for (j=0;j<res_fkey.length;j++){
              if (res[i].COLNAME == res_fkey[j].FKEY){
                res[i].FOREGIN_KEY = 'YES'
                break
              }
            }
          }
        }
      }
      let res_index;
      sql = `SELECT rtrim(b.INDEX_SCHEMA) concat '.' concat b.INDEX_NAME as INDNAME1, b.COLUMN_NAME as COLNAME FROM QSYS2.SYSINDEXES a, QSYS2.SYSKEYS b WHERE a.INDEX_NAME = b.INDEX_NAME AND a.INDEX_SCHEMA = b.INDEX_SCHEMA AND a.TABLE_NAME = '${treeNode.table}' AND a.TABLE_SCHEMA = '${treeNode.schemaName.trim()}'`;
      res_index = this._connectionManager.connObj.querySync(sql);
      if (res.length > 0){
        for (i=0;i<res.length;i++){
          res[i].INDEX_NAME = ""
          if (res_index.length > 0 ) { 
            for (j=0;j<res_index.length;j++){
              if (res[i].COLNAME == res_index[j].COLNAME){
                if (res[i].INDEX_NAME != "") {
                  res[i].INDEX_NAME = res[i].INDEX_NAME + ", " + res_index[j].INDNAME1
                } else {
                  res[i].INDEX_NAME = res_index[j].INDNAME1
                }
              }
            }
          }
        }
      }

    }
    com.dispose();
    if (!this._uiManager) {
      this._uiManager = new UIManager();
    }
    this._uiManager.showResultPanel(`DESCRIBE TABLE for '${treeNode.schemaName.trim()}'.'${treeNode.table}' `, res);
  }

  InsertData(treeNode){
    let self = this;
    return __awaiter(this, void 0, void 0, function* () {
        let res
        let query = "INSERT INTO "+ treeNode.schemaName.trim() +"." + treeNode.table + " VALUES (";
        // check the server and get the routine parms describe.
        if (treeNode.connection.serverName == "luw") {
            res = treeNode.connection.connObj.querySync("SELECT COLNAME as NAME, TYPENAME as COLTYPE from SYSCAT.COLUMNS where TABNAME = ? and TABSCHEMA = ? ORDER BY COLNO", [treeNode.table, treeNode.schemaName]);
        } else if (treeNode.connection.serverName == "zos"){
            res = treeNode.connection.connObj.querySync("SELECT NAME, COLTYPE from SYSIBM.SYSCOLUMNS where TBNAME = ? and TBCREATOR = ? ORDER BY COLNO", [treeNode.table, treeNode.schemaName]);
        } else {
            res = treeNode.connection.connObj.querySync("select COLUMN_NAME as NAME, DATA_TYPE as COLTYPE from QSYS2.SYSCOLUMNS where TABLE_NAME = ? and TABLE_SCHEMA = ? ORDER BY ORDINAL_POSITION", [treeNode.table, treeNode.schemaName]);
        }
        if (res.length > 0 ) {
          for (let i=0;i<res.length;i++) {
            var inp = yield vscode.window.showInputBox({
              ignoreFocusOut: true,
              placeHolder: "Enter Value for " + res[i].NAME + " of Type " + res[i].COLTYPE,
              prompt: " "
            })
            if (inp) {
              if (res[i].COLTYPE == "INTEGER" || res[i].COLTYPE == "SMALLINT" || res[i].COLTYPE == "BIGINT" || res[i].COLTYPE == "DOUBLE" || res[i].COLTYPE == "DECIMAL" || res[i].COLTYPE == "DECFLOAT"){
                if (i == 0) {
                  query = query + inp
                } else {
                  query = query + "," + inp
                }
              } else if (res[i].COLTYPE == "BLOB") {
                if (i == 0 ){
                  query = query + "BLOB(x'" + inp + "')"
                } else {
                  query = query + "," + "BLOB(x'" + inp + "')"
                }
              } else {
                if (i == 0) {
                  query = query + inp
                } else {
                  query = query + "," + "'" + inp + "'"
                }
              }
            }
          }
        }
        query = query + ")"
        let com = vscode.window.setStatusBarMessage(Constants.sbQueryInProg);
        this.executeSingleSQL("Results", query);
        com.dispose();
        const tree = treeProvider.IBM_DBTreeDataprovider.getInstance();
        tree.refresh();
    })
}

  refresh(treeNode){
    const tree = treeProvider.IBM_DBTreeDataprovider.getInstance();
    tree.refresh(treeNode);
  }

  runSingleQuery(){
    if (this._connectionManager) {
      if (!vscode.window.activeTextEditor) {
        vscode.window.showWarningMessage('No SQL file selected');
        return
      }
      let editor = vscode.window.activeTextEditor;
      // if (editor.document.languageId != 'sql') {
      //   vscode.window.showWarningMessage('Please change the language of a file to SQL');
      //   return
      // }
      let sqlToTrim = editor.selection.isEmpty ? undefined : editor.selection;
      let sql = editor.document.getText(sqlToTrim);
      sql = sql.trim();
      if (sql.length === 0) {
        vscode.window.showWarningMessage('No SQL found to run');
        return;
      }
      let com = vscode.window.setStatusBarMessage(Constants.sbQueryInProg);
      this.executeSingleSQL("Results", sql);
      com.dispose();
      const tree = treeProvider.IBM_DBTreeDataprovider.getInstance();
      tree.refresh();
    } else {
      //No connection exists
      vscode.window.showErrorMessage(Constants.errDbConnQuery);
    }
  }

  runMultipleQuery(){
    if (this._connectionManager) {
      if (!vscode.window.activeTextEditor) {
        vscode.window.showWarningMessage('No SQL file selected');
        return
      }
      let editor = vscode.window.activeTextEditor;
      // if (editor.document.languageId != 'sql') {
      //   vscode.window.showWarningMessage('Please change the language of a file to SQL');
      //   return
      // }
      let sqlToTrim = editor.selection.isEmpty ? undefined : editor.selection;
      let sql = editor.document.getText(sqlToTrim);
      if (sql.trim().length === 0) {
        vscode.window.showWarningMessage('No SQL found to run');
        return;
      }
      vscode.window.showInputBox({placeHolder: Constants.strGetDelimiter}).then(
        delimiter => {
          if(delimiter) {
            delimiter = delimiter.trim();
          }
          if(!delimiter) delimiter = ";";
          let com = vscode.window.setStatusBarMessage(Constants.sbQueryInProg);
          this.executeMultipleSQL("Results", sql, delimiter);
          com.dispose();
          const tree = treeProvider.IBM_DBTreeDataprovider.getInstance();
          tree.refresh();
        }); //showInputBox
    } else {
      //No connection exists
      vscode.window.showErrorMessage(Constants.errDbConnQuery);
    }
  }

  executeSingleSQL(uri, sql) {
    let result = "";
    let first_word = "";
    if (!this._uiManager) {
      this._uiManager = new UIManager();
    }
    let view = this._uiManager.createNewView(uri);
    view._resource = uri;
    this._queryList.push(`[${new Date().toUTCString()}]: ${sql}`);
    first_word = sql.trim().split(" ")[0].toUpperCase()
    if (first_word == "CALL"){
      this.executeStoredProcedure(view, sql, false)
    } else {
      result = this._connectionManager.connObj.querySync(sql);
      view.update(sql, result);
    }
  }

  executeMultipleSQL(uri, sqls, delimiter) {
    let myarray = sqls.split(delimiter);
    let result = "";
    let sql = "";
    let first_word = "";
    if (!this._uiManager) {
      this._uiManager = new UIManager();
    }
    let view = this._uiManager.createNewView(uri);
    let arrayLength = myarray.length;
    view._resource = uri;
    for (let i = 0; i < arrayLength; i++) {
      sql = (myarray[i]).trim();
      if(sql) {
        if (sql.startsWith("--")){
            let sqlArr = sql.split("\n");
            let comment = sqlArr[0];
            if(sqlArr.length > 1) {
                sqlArr.shift();
                sql = sqlArr.join(" ");
                view.append(comment, null);
            } else {
                view.append(comment + " " + delimiter);
                continue;
            }
        }
        first_word = sql.split(" ")[0].toUpperCase();
        if (first_word == "CALL"){
          this.executeStoredProcedure(view, sql, true)
        } else {
          this._queryList.push(`[${new Date().toUTCString()}]: ${sql}`);
          result = this._connectionManager.connObj.querySync(sql);
          sql += " " + delimiter;
          if (arrayLength == 1) {
            view.update(sql, result);
          } else {
            view.append(sql, result);
          }
        }
      }
    }
  }

  getSPText(treeNode){
    return __awaiter(this, void 0, void 0, function* () {
      let res = '';
      if (treeNode.connection.serverName == "luw") {
        res = yield treeNode.connection.connObj.query("select TEXT from SYSCAT.PROCEDURES where SPECIFICNAME = ? ", [treeNode.spid]);
      } else if (treeNode.connection.serverName == "zos"){
        res = yield treeNode.connection.connObj.query("select TEXT from SYSIBM.SYSROUTINES where SPECIFICNAME = ? and SCHEMA = ? and ROUTINETYPE = 'P'", [treeNode.spid, treeNode.schemaName]);
      } else {
        res = yield treeNode.connection.connObj.query("select ROUTINE_DEFINITION as TEXT from QSYS2.SYSROUTINES where SPECIFIC_NAME = ? and ROUTINE_SCHEMA = ? and ROUTINE_TYPE= 'PROCEDURE'", [treeNode.spid, treeNode.schemaName]);
      }
      const sql = res[0].TEXT;
      let languageType = '';
      if (treeNode.connection.serverName == "luw") {
        languageType = 'db2_luw'
      } else if (treeNode.connection.serverName == "zos"){
        languageType = 'db2_z'
      } else {
        languageType = 'db2_i'
      }
      // Open an untitled Document
      // const textDocument = yield vscode.workspace.openTextDocument({ content: sql, language: 'sql' });
      // yield vscode.window.showTextDocument(textDocument);

      //Open document with name
      let fileName = createFileName(treeNode.schemaName, "SP", treeNode.spName, ".spsql");
      const newFile = vscode.Uri.parse("untitled:" + path.join(fileName));
      if (sql != null) {
      vscode.workspace.openTextDocument(newFile).then(document => {
        const edit = new vscode.WorkspaceEdit();
        edit.insert(newFile, new vscode.Position(0, 0), sql);
        return vscode.workspace.applyEdit(edit).then(success => {
          if (success) {
            vscode.window.showTextDocument(document);
            vscode.languages.setTextDocumentLanguage(document, languageType);
          } else {
            vscode.window.showInformationMessage("Error!");
          }
        });
      })
      .then(undefined, err => {
        vscode.window.showErrorMessage(`${err}`);
      })
    } else {
      vscode.window.showInformationMessage("No Body found for this Stored Procedure at server");
    }
    });
  }

  executeStoredProcedure(view,sql, multiple_sqls){
    var now = this
    return __awaiter(this, void 0, void 0, function* () {
      let params= {};
      var params_pass = [];
      let temp = {}
      let result_pass = [];
      var schema_spname = sql.trim().split(" ")[1]
      var schema = schema_spname.trim().split(".")[0]
      var spname = schema_spname.trim().split(".")[1]
      spname = spname.split("(")[0]
      var param_count = sql.split(",").length
      var formatted_sql = "CALL " + schema+ "." + spname + " ("
      var param_string = sql.split("(")[1].split(")")[0]
      // user params contains data
      var user_params = param_string.split(",")
      for (let i = 0; i< user_params.length;i++) {
        if (i != user_params.length-1) {
          formatted_sql = formatted_sql + " ?,"
        } else {
          formatted_sql = formatted_sql + " ? )"
        }
        if (user_params[i] != "?"){
          user_params[i] = user_params[i].trim()
          if (user_params[i].charAt(0) == "'" && user_params[i].charAt(user_params[i].length-1) == "'") {
            user_params[i] = user_params[i].slice(1,-1)
          } else  if (user_params[i].charAt(0) == '"' && user_params[i].charAt(user_params[i].length-1) == '"') {
            user_params[i] = user_params[i].slice(1,-1)
          } else {
            user_params[i] = user_params[i]
          }
        }
      }
      // reterive the specific name from using param_count and routine name
      let routine_specific = null;
      if (now._connectionManager.serverName == "luw") {
        routine_specific = yield now._connectionManager.connObj.querySync("select SPECIFICNAME as PROCEDURE_ID from SYSCAT.ROUTINES where ROUTINESCHEMA = ? and ROUTINETYPE = 'P' and ROUTINENAME = ? and PARM_COUNT = ?", [schema,spname,param_count]);
      } else if (now._connectionManager.serverName == "zos"){
        routine_specific = yield now._connectionManager.connObj.querySync("select SPECIFICNAME as PROCEDURE_ID from SYSIBM.SYSROUTINES where SCHEMA = ? and ROUTINETYPE = 'P' and NAME = ? and PARM_COUNT = ?", [schema,spname,param_count]);
      } else {
        routine_specific = yield now._connectionManager.connObj.querySync("select SPECIFIC_NAME as PROCEDURE_ID from QSYS2.SYSROUTINES where ROUTINE_SCHEMA = ? and ROUTINE_TYPE= 'PROCEDURE'and ROUTINE_NAME = ? ", [schema,spname]);
      }

      let returned_params = null;
      // check the server and get the routine parms describe.
      if (routine_specific.length > 0) {
        if (now._connectionManager.serverName == "luw") {
          returned_params = yield now._connectionManager.connObj.querySync("select PARMNAME, TYPENAME, LENGTH, CASE WHEN ROWTYPE = 'P' THEN 'INPUT' WHEN ROWTYPE = 'O' THEN 'OUTPUT' WHEN ROWTYPE = 'B' THEN 'INOUT' END AS PARM_MODE from SYSCAT.ROUTINEPARMS where SPECIFICNAME = ? and ROUTINESCHEMA = ? ORDER BY ORDINAL",[routine_specific[0].PROCEDURE_ID, schema]);
        } else if (now._connectionManager.serverName == "zos"){
          returned_params = yield now._connectionManager.connObj.querySync("SELECT PARMNAME, TYPENAME, LENGTH, CASE WHEN ROWTYPE = 'P' THEN 'INPUT' WHEN ROWTYPE = 'O' THEN 'OUTPUT' WHEN ROWTYPE = 'B' THEN 'INOUT' END AS PARM_MODE from SYSIBM.SYSPARMS WHERE SPECIFICNAME = ? and SCHEMA = ? ORDER BY ORDINAL", [routine_specific[0].PROCEDURE_ID, schema]);
        } else {
          returned_params = yield now._connectionManager.connObj.querySync("SELECT PARAMETER_NAME as PARMNAME, DATA_TYPE as TYPENAME, CHARACTER_MAXIMUM_LENGTH as LENGTH, PARAMETER_MODE as PARM_MODE from QSYS2.SYSPARMS where SPECIFIC_NAME = ? and SPECIFIC_SCHEMA = ? ORDER BY ORDINAL_POSITION", [routine_specific[0].PROCEDURE_ID, schema]);
        }
      }

      let j = 0;
      let out_params = [];
      returned_params.map( sp => {
        if (sp.PARM_MODE == "OUTPUT" || sp.PARM_MODE == "INOUT") {
          out_params.push(sp.PARMNAME)
          if (sp.PARM_MODE == "OUTPUT"){
            if ( sp.TYPENAME == "INTEGER" || sp.TYPENAME == "SMALLINT" || sp.TYPENAME == "BIGINT" || sp.TYPENAME == "DOUBLE" ){
              user_params[j] = 0
            } else {
              user_params[j] = ""
            }
          }
        }
        if ( sp.TYPENAME == "INTEGER" || sp.TYPENAME == "SMALLINT" || sp.TYPENAME == "BIGINT" || sp.TYPENAME == "DOUBLE"){
          params["param"+j] = {ParamType:sp.PARM_MODE, DataType:1, Data:Number(user_params[j])}
        } else if(sp.TYPENAME == "DECIMAL"){
          if (user_params[j] == "") {
            params["param"+j] = {ParamType:sp.PARM_MODE, DataType:"DECIMAL", Data:user_params[j]}
          } else {
            params["param"+j] = {ParamType:sp.PARM_MODE, DataType:"DECIMAL", Data:Number(user_params[j])}
          }
        } else if(sp.TYPENAME == "DATE"){
          params["param"+j] = {ParamType:sp.PARM_MODE, DataType:"DATE", Data:user_params[j], Length:30}
        } else if(sp.TYPENAME == "TIME"){
          params["param"+j] = {ParamType:sp.PARM_MODE, DataType:"TIME", Data:user_params[j], Length:30}
        } else if (sp.TYPENAME == "TIMESTAMP"){
          params["param"+j] = {ParamType:sp.PARM_MODE, DataType:"TIMESTAMP", Data:user_params[j], Length:30}
        } else if(sp.TYPENAME == "XML"){
          params["param"+j] = {ParamType:sp.PARM_MODE, DataType:"XML", Data:user_params[j], Length:200}
        } else if(sp.TYPENAME == "BLOB"){
          params["param"+j] = {ParamType:sp.PARM_MODE, DataType:"BLOB", Data:new Buffer.from(user_params[j]), Length:sp.LENGTH}
        } else {
          params["param"+j] = {ParamType:sp.PARM_MODE, DataType:1, Data:user_params[j], Length:sp.LENGTH}
        }
        j++;
      })

      Object.keys(params).forEach(function (key) {
        params_pass.push(params[key])
      });

      let result;
      let other_results = []
      result = yield now._connectionManager.connObj.querySync(formatted_sql, params_pass);
      if (result.length || multiple_sqls) {
        for (let i=0;i<result.length;i++){
          if (out_params[i] != undefined) {
            temp[out_params[i]] = result[i]
          } else {
            other_results.push(result[i])
          }
        }
        result_pass.push(temp)
        view.append(formatted_sql, result_pass);
        if (other_results.length){
          for (let i=0;i<other_results.length;i++){
            view.append(formatted_sql,other_results[i])
          }
        }
      } else {
        view.update(formatted_sql, result);
      }
    })
  }

  callSP(treeNode){
    return __awaiter(this, void 0, void 0, function* () {
      let query = "CALL "+ treeNode.schemaName.trim() +"." + treeNode.spName + "(";
      let params= {};
      let sp_params = {};
      //let param_length = {};
      var params_pass = [];
      let res;
      let temp = {}
      let result_pass = [];
      // out_params will have values of out and inout parms which can be
      // used to frame the rsult
      let out_params = [];
      if (!this._uiManager) {
        this._uiManager = new UIManager();
      }

      // check the server and get the routine parms describe.
      if (treeNode.connection.serverName == "luw") {
        res = treeNode.connection.connObj.querySync("select PARMNAME, TYPENAME, LENGTH, CASE WHEN ROWTYPE = 'P' THEN 'INPUT' WHEN ROWTYPE = 'O' THEN 'OUTPUT' WHEN ROWTYPE = 'B' THEN 'INOUT' END AS PARM_MODE from SYSCAT.ROUTINEPARMS where SPECIFICNAME = ? and ROUTINESCHEMA = ? ORDER BY ORDINAL",[treeNode.spid, treeNode.schemaName]);
      } else if (treeNode.connection.serverName == "zos"){
        res = treeNode.connection.connObj.querySync("SELECT PARMNAME, TYPENAME, LENGTH, CASE WHEN ROWTYPE = 'P' THEN 'INPUT' WHEN ROWTYPE = 'O' THEN 'OUTPUT' WHEN ROWTYPE = 'B' THEN 'INOUT' END AS PARM_MODE from SYSIBM.SYSPARMS WHERE SPECIFICNAME = ? and SCHEMA = ? ORDER BY ORDINAL", [treeNode.spid, treeNode.schemaName]);
      } else {
        res = treeNode.connection.connObj.querySync("SELECT PARAMETER_NAME as PARMNAME, DATA_TYPE as TYPENAME, CHARACTER_MAXIMUM_LENGTH as LENGTH, PARAMETER_MODE as PARM_MODE from QSYS2.SYSPARMS where SPECIFIC_NAME = ? and SPECIFIC_SCHEMA = ? ORDER BY ORDINAL_POSITION", [treeNode.spid, treeNode.schemaName]);
      }
      // check the param mode and get inputs from the user
      if (res.length > 0){
        // form query
        for(let i=0;i<res.length;i++){
          if (i == res.length-1){
            query = query + "? "
          } else {
            query = query + "?, "
          }
          if (res[i].PARM_MODE == "INPUT"){
            var inp = yield vscode.window.showInputBox({
                ignoreFocusOut: true,
                placeHolder: "Enter Value for " + res[i].PARMNAME + " of Type " + res[i].TYPENAME,
                prompt: " "
              })
              if (inp) {
                sp_params[res[i].PARMNAME] = inp
              } else {
                return
              }
              //param_length[res[i].PARMNAME] = res[i].LENGTH
          } else if (res[i].PARM_MODE == "OUTPUT"){
            out_params.push(res[i].PARMNAME)
            if ( res[i].TYPENAME == "INTEGER" || res[i].TYPENAME == "SMALLINT" || res[i].TYPENAME == "BIGINT" || res[i].TYPENAME == "DOUBLE" ){
              sp_params[res[i].PARMNAME] = 0
            } else {
              sp_params[res[i].PARMNAME] = ""
            }
            //param_length[res[i].PARMNAME] = res[i].LENGTH
           /* if (!integer){
                // Ask the user to enter the length of non int's value
            } */
          } else {
            out_params.push(res[i].PARMNAME)
            var inp = yield vscode.window.showInputBox({
              ignoreFocusOut: true,
              placeHolder: "Enter Value for " + res[i].PARMNAME + " of Type " + res[i].TYPENAME,
              prompt: " "
            })
            if (inp) {
              sp_params[res[i].PARMNAME] = inp
            } else {
              return
            }
            //param_length[res[i].PARMNAME] = res[i].LENGTH
            /* if (!integer){
                // Ask the user to enter the length of non int's value
              } */
          }
        }
        query = query + ")"
        let i = 1;
        res.map( sp => {
          if ( sp.TYPENAME == "INTEGER" || sp.TYPENAME == "SMALLINT" || sp.TYPENAME == "BIGINT" || sp.TYPENAME == "DOUBLE"){
            params["param"+i] = {ParamType:sp.PARM_MODE, DataType:1, Data:Number(sp_params[sp.PARMNAME])}
          } else if(sp.TYPENAME == "DECIMAL"){
            if (sp_params[sp.PARMNAME] == "") {
              params["param"+i] = {ParamType:sp.PARM_MODE, DataType:"DECIMAL", Data:sp_params[sp.PARMNAME]}
            } else {
              params["param"+i] = {ParamType:sp.PARM_MODE, DataType:"DECIMAL", Data:Number(sp_params[sp.PARMNAME])}
            }
          } else if(sp.TYPENAME == "DATE"){
            params["param"+i] = {ParamType:sp.PARM_MODE, DataType:"DATE", Data:sp_params[sp.PARMNAME], Length:30}
          } else if(sp.TYPENAME == "TIME"){
            params["param"+i] = {ParamType:sp.PARM_MODE, DataType:"TIME", Data:sp_params[sp.PARMNAME], Length:30}
          } else if (sp.TYPENAME == "TIMESTAMP"){
            params["param"+i] = {ParamType:sp.PARM_MODE, DataType:"TIMESTAMP", Data:sp_params[sp.PARMNAME], Length:30}
          } else if(sp.TYPENAME == "XML"){
            params["param"+i] = {ParamType:sp.PARM_MODE, DataType:"XML", Data:sp_params[sp.PARMNAME], Length:200}
          } else if(sp.TYPENAME == "BLOB"){
            params["param"+i] = {ParamType:sp.PARM_MODE, DataType:"BLOB", Data:new Buffer.from(sp_params[sp.PARMNAME]), Length:sp.LENGTH}
          } else { 
            params["param"+i] = {ParamType:sp.PARM_MODE, DataType:1, Data:sp_params[sp.PARMNAME], Length:sp.LENGTH}
          }
          i++;
        })
        Object.keys(params).forEach(function (key) {
          params_pass.push(params[key])
        });
        let result;
        let other_results = [] // this stores the other data(not out or inout) returned by the call sp
        //console.log(params_pass);
        result = treeNode.connection.connObj.querySync(query, params_pass);
        //console.log("This is result from callSP", result);
        if (result.length) {
          for (let i=0;i<result.length;i++){
            if (out_params[i] != undefined) {
              temp[out_params[i]] = result[i]
            } else {
              other_results.push(result[i])
            }
          }
          result_pass.push(temp)
          let view = this._uiManager.createNewView("Results");
          view._resource = "Results";
          //console.log("This is result_pass: ", result_pass);
          //console.log("This is other_results: ", other_results)
          view.update(query, result_pass);
          if (other_results.length){
            for (let i=0;i<other_results.length;i++){
              view.append(query,other_results[i])
            }
          }
        } else {
          let view = this._uiManager.createNewView("Results");
          view._resource = "Results";
          view.update(query, result);
        }
      } else {
        vscode.window.showInformationMessage("No PARAMETERS in this Stored Procedure");
      }
    })
  }

  getFuncBody(treeNode){
    return __awaiter(this, void 0, void 0, function* () {
      if (!this._connectionManager) {
        vscode.window.showErrorMessage(Constants.errDbConnCommand);
        return;
      }
      let res = '';
      if (treeNode.connection.serverName == "luw") {
        res = yield treeNode.connection.connObj.query("select BODY as TEXT from SYSCAT.FUNCTIONS where SPECIFICNAME = ? and FUNCSCHEMA = ? and FUNCNAME = ? ", [treeNode.funcid, treeNode.schemaName,treeNode.funcName]);
      } else if (treeNode.connection.serverName == "zos"){
        res = yield treeNode.connection.connObj.query("select TEXT from SYSIBM.SYSROUTINES where SPECIFICNAME = ? and SCHEMA = ? and NAME = ? and ROUTINETYPE = 'F'", [treeNode.funcid, treeNode.schemaName, treeNode.funcName]);
      } else {
        res = yield treeNode.connection.connObj.query("select ROUTINE_DEFINITION as TEXT from QSYS2.SYSROUTINES where SPECIFIC_NAME = ? and ROUTINE_SCHEMA = ? and ROUTINE_TYPE= 'FUNCTION'", [treeNode.funcid, treeNode.schemaName])
      }
      const sql = res[0].TEXT;
      let languageType = '';
      if (treeNode.connection.serverName == "luw") {
        languageType = 'db2_luw'
      } else if (treeNode.connection.serverName == "zos"){
        languageType = 'db2_z'
      } else {
        languageType = 'db2_i'
      }
      // if (sql != null) {
      //   const textDocument = yield vscode.workspace.openTextDocument({ content: sql, language: 'sql' });
      //   yield vscode.window.showTextDocument(textDocument);
      // } else {
      //   vscode.window.showInformationMessage("No Body found for this function at server");
      // }
      let fileName = createFileName(treeNode.schemaName, "FUNC", treeNode.spName, ".udfsql");
      if (sql != null) {
        const newFile = vscode.Uri.parse("untitled:" + path.join(fileName));
        vscode.workspace.openTextDocument(newFile).then(document => {
          const edit = new vscode.WorkspaceEdit();
          edit.insert(newFile, new vscode.Position(0, 0), sql);
          return vscode.workspace.applyEdit(edit).then(success => {
            if (success) {
              vscode.window.showTextDocument(document);
              vscode.languages.setTextDocumentLanguage(document, languageType);
            } else {
              vscode.window.showInformationMessage("Error!");
            }
          });
        })
        .then(undefined, err => {
          vscode.window.showErrorMessage(`${err}`);
        })
      } else {
        vscode.window.showInformationMessage("No Body found for this function at server");
      }
    });
  }

  getTriggerBody(treeNode){
    return __awaiter(this, void 0, void 0, function* () {
      if (!this._connectionManager) {
        vscode.window.showErrorMessage(Constants.errDbConnCommand);
        return;
      }
      let res = '';
      if (treeNode.connection.serverName == "luw") {
        res = yield treeNode.connection.connObj.query("select TEXT from SYSCAT.TRIGGERS where TRIGNAME = ? and TRIGSCHEMA = ? ", [treeNode.trigger, treeNode.schemaName]);
      } else if (treeNode.connection.serverName == "zos"){
        res = yield treeNode.connection.connObj.query("select STATEMENT as TEXT from SYSIBM.SYSTRIGGERS where NAME = ? and SCHEMA = ? ", [treeNode.trigger, treeNode.schemaName]);
      } else {
        res = yield treeNode.connection.connObj.query("select ACTION_STATEMENT as TEXT from QSYS2.SYSTRIGGERS where TRIGGER_NAME = ? and TRIGGER_SCHEMA = ? ", [treeNode.trigger, treeNode.schemaName])
      }
      const sql = res[0].TEXT;
      let languageType = '';
      if (treeNode.connection.serverName == "luw") {
        languageType = 'db2_luw'
      } else if (treeNode.connection.serverName == "zos"){
        languageType = 'db2_z'
      } else {
        languageType = 'db2_i'
      }
      // const textDocument = yield vscode.workspace.openTextDocument({ content: sql, language: 'sql' });
      // yield vscode.window.showTextDocument(textDocument);
      let fileName = createFileName(treeNode.schemaName, "TRIG", treeNode.spName, ".sql");
      if (sql != null) {
        const newFile = vscode.Uri.parse("untitled:" + path.join(fileName));
        vscode.workspace.openTextDocument(newFile).then(document => {
          const edit = new vscode.WorkspaceEdit();
          edit.insert(newFile, new vscode.Position(0, 0), sql);
          return vscode.workspace.applyEdit(edit).then(success => {
            if (success) {
              vscode.window.showTextDocument(document);
              vscode.languages.setTextDocumentLanguage(document, languageType);
            } else {
              vscode.window.showInformationMessage("Error!");
            }
          });
        })
        .then(undefined, err => {
          vscode.window.showErrorMessage(`${err}`);
        })
      } else {
        vscode.window.showInformationMessage("No Body found for this Trigger at server");
      }
    });
  }

  getViewBody(treeNode){
    return __awaiter(this, void 0, void 0, function* () {
      if (!this._connectionManager) {
        vscode.window.showErrorMessage(Constants.errDbConnCommand);
        return;
      }
      let res = '';
      if (treeNode.connection.serverName == "luw") {
        res = yield treeNode.connection.connObj.query("select TEXT from SYSCAT.VIEWS where VIEWNAME = ? and VIEWSCHEMA = ?",[treeNode.view, treeNode.schemaName]);
      } else if (treeNode.connection.serverName == "zos"){
        res = yield treeNode.connection.connObj.query("select STATEMENT as TEXT from SYSIBM.SYSVIEWS where NAME = ? and CREATOR = ?",[treeNode.view, treeNode.schemaName]);
      } else {
        res = yield treeNode.connection.connObj.query("select VIEW_DEFINITION from QSYS2.SYSVIEWS where TABLE_NAME = ? and TABLE_SCHEMA = ? ",[treeNode.view, treeNode.schemaName])
      }
      const sql = res[0].TEXT;
      let languageType = '';
      if (treeNode.connection.serverName == "luw") {
        languageType = 'db2_luw'
      } else if (treeNode.connection.serverName == "zos"){
        languageType = 'db2_z'
      } else {
        languageType = 'db2_i'
      }
      // const textDocument = yield vscode.workspace.openTextDocument({ content: sql, language: 'sql' });
      // yield vscode.window.showTextDocument(textDocument);
      let fileName = createFileName(treeNode.schemaName, "VIEW", treeNode.spName, ".sql");
      if (sql != null) {
        const newFile = vscode.Uri.parse("untitled:" + path.join(fileName));
        vscode.workspace.openTextDocument(newFile).then(document => {
          const edit = new vscode.WorkspaceEdit();
          edit.insert(newFile, new vscode.Position(0, 0), sql);
          return vscode.workspace.applyEdit(edit).then(success => {
            if (success) {
              vscode.window.showTextDocument(document);
              vscode.languages.setTextDocumentLanguage(document, languageType);
            } else {
              vscode.window.showInformationMessage("Error!");
            }
          });
        })
        .then(undefined, err => {
          vscode.window.showErrorMessage(`${err}`);
        })
      } else {
        vscode.window.showInformationMessage("No Body found for this view at server");
      }
    });
  }

  exportResult(){
    let result = this._uiManager.activeWinResults;
    if (!result) {
      vscode.window.showWarningMessage('Unable to save data - results not found');
      return;
    }
    if (result.length < 1) {
      vscode.window.showWarningMessage('Unable to save data - table has no data');
      return;
    }

    let formats = ['json', 'xml', 'csv'];
    vscode.window.showQuickPick(formats).then(selected => {
      if(selected != undefined && selected != ''){
      let res = null;
      if(selected == 'json') {
        res = JSON.stringify(result, null, 3);
      } else {
        if (Array.isArray(result[0])) {
          for (const x of result) {
            if (res == null) {
              res = this.getResult(x, selected);
            } else {
              res += "\n\n" + this.getResult(x, selected);
            }
          }
        } else {
          res = this.getResult(result, selected);
        }
      }
      vscode.workspace.openTextDocument({ content: res, language: selected }).then(textDocument => {
        vscode.window.showTextDocument(textDocument);
      });
    } else {
    }
  });
  }

  getResult(result, selected) {
    let colName = [];
    let colValues = [];

    Object.keys(result[0]).forEach(key => {
      colName.push(key);
    });
    for (let eachRow of result) {
      let temp = [];
      Object.values(eachRow).forEach(val => {
        temp.push(val);
      });
      colValues.push(temp);
    }

    if(selected == 'xml'){
      var serializer = new EasyXml({
        singularize: true,
        rootElement: 'results',
        dateFormat: 'ISO',
        manifest: true
      });
      let data = this.Output(colName, colValues);
      return serializer.render(data);
    }
    else {
      let csvCol = colName.join(",");
      let csvVal = colValues.join("\n")
      return csvCol + "\n" + csvVal;
    }
  }

  Output(cols, rows) {
    let col = this.frameColNames.bind(null, cols);
    return rows.map(col);
  }

  frameColNames(fields, row) {
    let Row = {};
    let fieldCounts = {};
    fields.forEach((field, i) => {
        fieldCounts[field] = 0;
        Row[field] = row[i];
    });
    return Row;
  }
}

function createFileName(schemaName, type, Name, ExtensionType){
  let extPath;
  let fileName = schemaName.trim() + "_" + type + "_" + Name + "_" +`${new Date().getTime()}` + ExtensionType;
  try {
  if (os.type() == Constants.strWinOS) {
    if (!process.env.USERPROFILE) {
      throw new Error(Constants.errUserProfDir);
    } else {
      extPath = path.resolve(
        process.env.USERPROFILE,
        ".vscode",
        "extensions"
      );
    }
  } else {
    if (!process.env.HOME) {
      throw new Error(Constants.errHomeDir);
    } else {
      extPath = path.resolve(process.env.HOME, ".vscode", "extensions");
    }
  }
  extPath = path.resolve(extPath, Constants.extFolderName);
  if (!fs.existsSync(extPath)) {
    fs.mkdirSync(extPath);
  }
  extPath = path.resolve(extPath, "Data");
  fileName = path.resolve(extPath, fileName);
  if (!fs.existsSync(extPath)) {
    fs.mkdirSync(extPath);
  }
  if (fs.existsSync(extPath)) {
    if (!fs.existsSync(fileName)) {
      return fileName;
    }
    else {
      fs.unlinkSync(fileName);
      return fileName;
    }
  }
} catch (e) {
  vscode.window.showErrorMessage(e.message);
}
}


module.exports = MainController;
