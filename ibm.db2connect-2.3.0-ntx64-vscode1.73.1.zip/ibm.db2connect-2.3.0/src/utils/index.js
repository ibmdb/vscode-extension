const fs = require("fs");
const Constants = require("../constants");
const crypto = require("crypto");
const child_process = require("child_process");
const path = require("path");
const vscode = require("vscode");
const IV_LENGTH = 16;
const ENCRYPTION_KEY = Buffer.from('FoCKvdLslUuB4y3EZlKate7XGottHski1LmyqJHvUhs=', 'base64');

function getFilesizeInBytes(filename) {
  var stats = fs.statSync(filename);
  var fileSizeInBytes = stats["size"];
  return fileSizeInBytes;
}

function encrypt(text) {
	let iv = crypto.randomBytes(IV_LENGTH);
	let cipher = crypto.createCipheriv(Constants.encryptionAlgorithm, Buffer.from(ENCRYPTION_KEY, 'hex'), iv);
	let encrypted = cipher.update(text);
	encrypted = Buffer.concat([encrypted, cipher.final()]);
	return iv.toString('hex') + ':' + encrypted.toString('hex');
}

function decrypt(text) {
	let textParts = text.split(':');
	let iv = Buffer.from(textParts.shift(), 'hex');
	let encryptedText = Buffer.from(textParts.join(':'), 'hex');
	let decipher = crypto.createDecipheriv(Constants.encryptionAlgorithm, Buffer.from(ENCRYPTION_KEY, 'hex'), iv);
	let decrypted = decipher.update(encryptedText);
	decrypted = Buffer.concat([decrypted, decipher.final()]);
	return decrypted.toString();
}

function makeConnStrFromProfile(p) {
  p.Password = decrypt(p.Password);
  var connStr = "";
  if (p.Others) {
    connStr = `DATABASE=${p.Database};HOSTNAME=${p.Hostname};UID=${p.User};PWD=${p.Password};PORT=${p.Port};${p.Others}`
    if (p.SECURITY) {
      if (p.SSLSERVERCERTIFICATE) {
        connStr = `DATABASE=${p.Database};HOSTNAME=${p.Hostname};UID=${p.User};PWD=${p.Password};PORT=${p.Port};SECURITY=${p.SECURITY};SSLSERVERCERTIFICATE=${p.SSLSERVERCERTIFICATE};${p.Others}`
      } else {
        connStr = `DATABASE=${p.Database};HOSTNAME=${p.Hostname};UID=${p.User};PWD=${p.Password};PORT=${p.Port};SECURITY=${p.SECURITY};${p.Others}`
      }
    }
  } else {
    if (p.SECURITY) {
      if (p.SSLSERVERCERTIFICATE) {
        connStr = `DATABASE=${p.Database};HOSTNAME=${p.Hostname};UID=${p.User};PWD=${p.Password};PORT=${p.Port};SECURITY=${p.SECURITY};SSLSERVERCERTIFICATE=${p.SSLSERVERCERTIFICATE}`
      } else {
        connStr = `DATABASE=${p.Database};HOSTNAME=${p.Hostname};UID=${p.User};PWD=${p.Password};PORT=${p.Port};SECURITY=${p.SECURITY}`
      }
    } else {
      connStr = `DATABASE=${p.Database};HOSTNAME=${p.Hostname};UID=${p.User};PWD=${p.Password};PORT=${p.Port}`
    }
  }
  return connStr;
}

function makeStatusBarMsgOnConn(connInfo) {
  return `${Constants.sbConnected}: ${connInfo.host}@${connInfo.user}${connInfo.user.length &&
    "@"}${connInfo.db || ""}`;
}

function isRebuildDone(extPath, outputChannel) {
  if (fs.existsSync(path.join(extPath, Constants.rebuildMarkerFile))) {
    outputChannel.appendLine(`[${getTimestamp()}] ${Constants.infRebuildDone}`);
    return true;
  } else {
    outputChannel.appendLine(
      `[${getTimestamp()}] Proceeding to rebuild native modules`
    );
    return false;
  }
}

function showWaitingMsg() {
  vscode.window.showInformationMessage(
    "Please wait for the setup to finish..."
  );
}

function registerCommand(ctx, command, cb) {
  ctx.subscriptions.push(
    vscode.commands.registerCommand(command, () => {
      cb();
    })
  );
}

function registerTemporaryCommands(ctx) {
  registerCommand(ctx, Constants.cmdConnect, () => {
    showWaitingMsg();
  });
  registerCommand(ctx, Constants.cmdDisconnect, () => {
    showWaitingMsg();
  });
  registerCommand(ctx, Constants.cmdRunQuery, () => {
    showWaitingMsg();
  });
  registerCommand(ctx, Constants.cmdExecuteFile, () => {
    showWaitingMsg();
  });
  registerCommand(ctx, Constants.cmdShowHistory, () => {
    showWaitingMsg();
  });
  registerCommand(ctx, Constants.cmdRunNonQuery, () => {
    showWaitingMsg();
  });
  registerCommand(ctx, Constants.cmdManageConnProfiles, () => {
    showWaitingMsg();
  });
  registerCommand(ctx, Constants.cmdRebuild, () => {
    showWaitingMsg();
  });
  //Use the below command to test any trial code
  registerCommand(ctx, Constants.cmdHelloWorld, () => {
    showWaitingMsg();
  });
}

function cleanNativeModules(extPath, outputChannel) {
  const ibm_db_path = path.join(extPath, "node_modules", "ibm_db");
  if (fs.existsSync(ibm_db_path)) {
    outputChannel.appendLine(
      `[${getTimestamp()}] Cleaning up the current ibm_db`
    );
    //fs.renameSync(ibm_db_path, `${ibm_db_path}_obsolete`);
    deleteFolderRecursive(ibm_db_path);
  } else {
    outputChannel.appendLine(`[${getTimestamp()}] No ibm_db found...`);
  }
}

function getTimestamp() {
  let dateTime = new Date().toLocaleString(); // Example format 02/11/2018, 10:47:21
  dateTime = dateTime.replace(",", ""); // Remove comma
  return dateTime;
}

function deleteFolderRecursive(p) {
  if (fs.existsSync(p)) {
    fs.readdirSync(p).forEach(function(file, index) {
      var curPath = path.join(p, file);
      if (fs.lstatSync(curPath).isDirectory()) {
        // recurse
        deleteFolderRecursive(curPath);
      } else {
        // delete file
        fs.unlinkSync(curPath);
      }
    });
    fs.rmdirSync(p);
  }
}

function runCommand(command, args, cwd, env, outputAdapter) {
  const shell = process.platform === "win32" ? true : false;
  const options = {
    cwd,
    env,
    shell
  };
  outputAdapter.appendLine(`Running ${command} ${args} in ${cwd}...`);
  const child = child_process.spawn(command, args, options);
  child.stdout.on("data", data => {
    const str = data.toString();
    str
      .replace(/[\r\n]+$/, "")
      .split(/[\r\n]+/)
      .forEach(line => {
        outputAdapter.appendLine(line);
        //process.stdout.write('=');
        //console.log(line);
      });
  });
  child.stderr.on("data", data => {
    const str = data.toString();
    str
      .replace(/[\r\n]+$/, "")
      .split(/[\r\n]+/)
      .forEach(line => {
        outputAdapter.appendLine(line);
        //process.stdout.write('+');
        //console.log(line);
      });
  });
  return new Promise((resolve, reject) => {
    child.on("error", reject);
    child.on("exit", code => {
      if (code) {
        outputAdapter.appendLine(`[${getTimestamp()}] ibm_db installation failed with code: ${code}`);
        return reject(
          new Error(
            `Failed to execute command "${command}" with  arguments "${args.join(
              ", "
            )}" return code ${code}`
          )
        );
      }
      outputAdapter.appendLine(
        `[${getTimestamp()}] Finished successfully installing the component`
      );
      resolve();
    });
  });
}

module.exports = {
  encrypt,
  decrypt,
  getFilesizeInBytes,
  makeConnStrFromProfile,
  makeStatusBarMsgOnConn,
  runCommand,
  getTimestamp,
  cleanNativeModules,
  isRebuildDone,
  deleteFolderRecursive,
  registerTemporaryCommands
};
