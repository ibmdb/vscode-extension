var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const ibmdb = require("ibm_db");
const path = require("path");
const vscode = require("vscode");
const tableFolder = require("./TableFolder");
const viewFolder = require("./ViewFolder");
const aliasFolder = require("./AliasFolder");
const trigerFolder = require("./TriggerFolder");
const spFolder = require("./SPFolder");
const functionFolder = require("./FunctionFolder");
const indexFolder = require("./IndexFolder");
const errorNode = require("./ErrorNode");

class SchemaNode {
    constructor(connection, schemaName) {
        this.connection = connection;
        this.schemaName = schemaName;
        this.schemaN = schemaName;
    }
    getTreeItem() {
        return {
            label: this.schemaName,
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.schema',
            command: {
                title: 'select-schema',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light: path.join(__dirname, '../../Resources/light/schema.svg'),
                dark: path.join(__dirname, '../../Resources/dark/schema.svg')
            }
        };
    }
    getChildren() {
        return __awaiter(this, void 0, void 0, function* () {
            //let table1 = {"name":"Tablename", "schema":this.connection.schema,"is_table":true};
            try {
                let childs = [];
                childs.push(new tableFolder.TableFolder(this.connection, this.schemaName));
                childs.push(new viewFolder.ViewFolder(this.connection, this.schemaName));
                childs.push(new aliasFolder.AliasFolder(this.connection, this.schemaName));
                childs.push(new spFolder.SPFolder(this.connection, this.schemaName));
                childs.push(new functionFolder.FunctionFolder(this.connection, this.schemaName));
                childs.push(new trigerFolder.TriggerFolder(this.connection, this.schemaName));
                childs.push(new indexFolder.IndexFolder(this.connection, this.schemaName));
                return childs;
            }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
        });
    }
}
exports.SchemaNode = SchemaNode;