var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const path = require("path");
const vscode = require("vscode");

class FunctionNode {
    constructor(connection, funcName, funcid ,schemaName) {
        this.connection = connection;
        this.funcName = funcName;
        this.funcid = funcid;
        this.schemaName = schemaName
    }
    getTreeItem() {
        return {
            label: this.funcName,
            collapsibleState: vscode.TreeItemCollapsibleState.None,
            contextValue: 'db2connect.tree.function',
            command: {
                title: 'select-function',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light:  path.join(__dirname, '../../Resources/light/function_folder.svg'),
                dark:   path.join(__dirname, '../../Resources/dark/function_folder.svg')
            }
        };
    }
    getChildren() {
        return [];
    }
}
exports.FunctionNode = FunctionNode;