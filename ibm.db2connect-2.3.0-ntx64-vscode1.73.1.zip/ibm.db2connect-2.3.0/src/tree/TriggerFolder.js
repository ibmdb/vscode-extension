var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const path = require("path");
const vscode = require("vscode");
const triggerNode = require("./TriggerNode");
const errorNode = require("./ErrorNode");

class TriggerFolder {
    constructor(connection, schemaName) {
        this.connection = connection;
        this.schemaName = schemaName;
    }
    getTreeItem() {
        return {
            label: 'Triggers',
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.triggerfolder',
            command: {
                title: 'expand-triggers',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light: path.join(__dirname, '../../Resources/light/trigger.svg'),
                dark: path.join(__dirname, '../../Resources/dark/trigger.svg')
            }
        };
    }
    getChildren() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                    let res = null;
                    if (this.connection.serverName == "luw") {
                        res = yield this.connection.connObj.query("select TRIGNAME as NAME from SYSCAT.TRIGGERS where TRIGSCHEMA = ? order by TRIGNAME", [this.schemaName]);
                    } else if (this.connection.serverName == "zos"){
                        res = yield this.connection.connObj.query("select NAME from SYSIBM.SYSTRIGGERS where SCHEMA = ? order by NAME", [this.schemaName]);
                    } else {
                        res = yield this.connection.connObj.query("select TRIGGER_NAME as NAME from QSYS2.SYSTRIGGERS where TRIGGER_SCHEMA = ? ORDER BY TRIGGER_NAME", [this.schemaName]);
                    }
                    if (res.length > 0){
                    return res.map( trigger => {
                        return new triggerNode.TriggerNode(this.connection, trigger.NAME, this.schemaName);
                    });
                } else {
                    vscode.window.showInformationMessage("No TRIGGERS in this schema");
                    return [];
                }
            }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
        });
    }
}
exports.TriggerFolder = TriggerFolder;