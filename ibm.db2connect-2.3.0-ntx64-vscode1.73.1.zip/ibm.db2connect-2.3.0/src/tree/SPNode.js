var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const path = require("path");
const vscode = require("vscode");
const inoutNode = require("./InOutNode");
const errorNode = require("./ErrorNode");

class SPNode {
    constructor(connection, spName, spid, schemaName) {
        this.connection = connection;
        this.spName = spName;
        this.spid = spid;
        this.schemaName = schemaName;
    }
    getTreeItem() {
        return {
            label: this.spName,
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.storedprocedure',
            command: {
                title: 'select-storeprocedure',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light:  path.join(__dirname, '../../Resources/light/stored_procedure.svg'),
                dark:   path.join(__dirname, '../../Resources/dark/stored_procedure.svg')
            }
        };
    }
    getChildren() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                    let res = null;
                    //res = yield this.connection.connObj.query("select param.parmname as parm_name,typename as data_type from syscat.routines proc left join syscat.routineparms param on proc.routineschema = param.routineschema and proc.specificname = param.specificname where proc.routinetype = 'P' and proc.routinename = ? ", [this.spName.toUpperCase()]);
                    //res = yield this.connection.connObj.query("select case when column_type = 1 then 'IN' when column_type = 2 then 'INOUT' when column_type = 4 then 'OUT' end as mode , column_name, type_name from sysibm.sqlprocedurecols where procedure_name = ? ", [this.spName.toUpperCase()]);
                    //res = yield this.connection.connObj.query("select DISTINCT case when cols.column_type = 1 then 'IN' when cols.column_type = 2 then 'INOUT' when cols.column_type = 4 then 'OUT' end as mode, param.parmname as column_name, typename as type_name from syscat.routines proc left join syscat.routineparms param on proc.routineschema = param.routineschema and proc.specificname = param.specificname left join sysibm.sqlprocedurecols cols on param.parmname = cols.column_name where proc.routinetype = 'P' and proc.routineid = ? order by column_name",[this.spid]);
                    //res = yield this.connection.connObj.query("select DISTINCT param.parmname as column_name, typename as type_name from syscat.routines proc left join syscat.routineparms param on proc.routineschema = param.routineschema and proc.specificname = param.specificname where proc.routinetype = 'P' and proc.routineid = ? order by column_name",[this.spid]);
                    if (this.connection.serverName == "luw") {
                        res = yield this.connection.connObj.query("select PARMNAME, TYPENAME, CASE WHEN ROWTYPE = 'P' THEN 'IN' WHEN ROWTYPE = 'O' THEN 'OUT' WHEN ROWTYPE = 'B' THEN 'INOUT' END AS PARM_MODE from SYSCAT.ROUTINEPARMS where SPECIFICNAME = ? and ROUTINESCHEMA = ? ORDER BY ORDINAL",[this.spid, this.schemaName]);
                    } else if (this.connection.serverName == "zos"){
                        res = yield this.connection.connObj.query("SELECT PARMNAME, TYPENAME, CASE WHEN ROWTYPE = 'P' THEN 'IN' WHEN ROWTYPE = 'O' THEN 'OUT' WHEN ROWTYPE = 'B' THEN 'INOUT' END AS PARM_MODE from SYSIBM.SYSPARMS WHERE SPECIFICNAME = ? and SCHEMA = ? ORDER BY ORDINAL", [this.spid,this.schemaName]);
                    } else {
                        res = yield this.connection.connObj.query("SELECT PARAMETER_NAME as PARMNAME, DATA_TYPE as TYPENAME, PARAMETER_MODE as PARM_MODE from QSYS2.SYSPARMS where SPECIFIC_NAME = ? and SPECIFIC_SCHEMA = ? ORDER BY ORDINAL_POSITION", [this.spid, this.schemaName]);
                    }
                    if (res.length > 0){
                        return res.map( sp => {
                            return new inoutNode.InOutNode(this.connection, sp.PARMNAME, sp.TYPENAME, sp.PARM_MODE);
                        })
                    } else {
                        vscode.window.showInformationMessage("No PARAMETERS in this Stored Procedure");
                        return [];
                    }
            }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
        });
    }
}
exports.SPNode = SPNode;