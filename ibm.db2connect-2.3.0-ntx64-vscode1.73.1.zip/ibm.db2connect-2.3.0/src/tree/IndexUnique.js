const path = require("path");
const vscode = require("vscode");

class IndexUnique {
    constructor(connection, Iunique, schemaName) {
        this.connection = connection;
        this.Iunique = Iunique;
        this.schemaName = schemaName;
    }
    getTreeItem() {
        return {
            label: `Unique: ${this.Iunique}`,
            collapsibleState: vscode.TreeItemCollapsibleState.None,
            contextValue: 'db2connect.tree.Iunique',
            command: {
                title: 'select-Iunique',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light:  path.join(__dirname, '../../Resources/light/column.svg'),
                dark:   path.join(__dirname, '../../Resources/dark/column.svg')
            }
        };
    }
    getChildren() {
        return []
    }
}
exports.IndexUnique = IndexUnique;