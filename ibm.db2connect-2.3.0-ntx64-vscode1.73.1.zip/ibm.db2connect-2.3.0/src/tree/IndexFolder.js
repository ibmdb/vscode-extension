const path = require("path");
const vscode = require("vscode");
const indexNode = require("./IndexNode");
const errorNode = require("./ErrorNode");

class IndexFolder {
    constructor(connection, schemaName) {
        this.connection = connection;
        this.schemaName = schemaName;
    }
    getTreeItem() {
        return {
            label: 'Indexes',
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.indexfolder',
            command: {
                title: 'expand-indexes',
                command: 'db2connect.setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light: path.join(__dirname, '../../Resources/light/table_folder.svg'),
                dark: path.join(__dirname, '../../Resources/dark/table_folder.svg')
            }
        };
    }
    getChildren() {
            try {

                    let res = null;
                    if (this.connection.serverName == "luw") {
                        res = this.connection.connObj.querySync("SELECT INDNAME AS NAME FROM SYSCAT.INDEXES WHERE INDSCHEMA = ? ORDER BY INDNAME", [this.schemaName]);
                    } else if (this.connection.serverName == "zos"){
                        res = this.connection.connObj.querySync("SELECT NAME FROM SYSIBM.SYSINDEXES WHERE CREATOR = ? ORDER BY NAME", [this.schemaName]);
                    } else {
                        res = this.connection.connObj.querySync("SELECT INDEX_NAME AS NAME FROM QSYS2.SYSINDEXES WHERE INDEX_SCHEMA = ? ORDER BY INDEX_NAME", [this.schemaName]);
                    }
                    if (res.length > 0) {
                    return res.map( index => {
                        return new indexNode.IndexNode(this.connection, index.NAME, this.schemaName)
                    })
                    } else {
                        vscode.window.showInformationMessage("No INDEXES in this schema");
                        return [];
                    }
            }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
    }
}
exports.IndexFolder = IndexFolder;