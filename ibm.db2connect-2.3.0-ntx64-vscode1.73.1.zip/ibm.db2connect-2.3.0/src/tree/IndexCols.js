const path = require("path");
const vscode = require("vscode");

class IndexCols {
    constructor(connection, ICols, schemaName) {
        this.connection = connection;
        this.ICols = ICols;
        this.schemaName = schemaName;
    }
    getTreeItem() {
        return {
            label: `Columns: ${this.ICols}`,
            collapsibleState: vscode.TreeItemCollapsibleState.None,
            contextValue: 'db2connect.tree.ICols',
            command: {
                title: 'select-ICols',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light:  path.join(__dirname, '../../Resources/light/column.svg'),
                dark:   path.join(__dirname, '../../Resources/dark/column.svg')
            }
        };
    }
    getChildren() {
        return []
    }
}
exports.IndexCols = IndexCols;