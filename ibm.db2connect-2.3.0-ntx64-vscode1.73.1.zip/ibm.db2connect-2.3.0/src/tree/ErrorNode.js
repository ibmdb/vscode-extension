const path = require("path");
const vscode = require("vscode");
class ErrorNode {
    constructor(label) {
        this.label = label;
    }
    getTreeItem() {
        return {
            label: this.label.toString(),
            collapsibleState: vscode.TreeItemCollapsibleState.None,
            contextValue: 'vscode-postgres.tree.error',
            iconPath: {
                light: path.join(__dirname, '../../Resources/light/error.svg'),
                dark: path.join(__dirname, '../../Resources/dark/error.svg')
            }
        };
    }
    getChildren() { return []; }
}
exports.ErrorNode = ErrorNode;