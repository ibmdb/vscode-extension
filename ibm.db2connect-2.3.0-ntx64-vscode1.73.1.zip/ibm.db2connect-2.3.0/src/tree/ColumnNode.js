var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const path = require("path");
const vscode = require("vscode");

class ColumnNode {
    constructor(connection, tablename, column) {
        this.connection = connection;
        this.tablename = tablename;
        this.column = column;
    }

    getTreeItem() {
        let icon = 'column.svg';
        let label = `${this.column.NAME} : ${this.column.COLTYPE} (${this.column.LENGTH})`;
        let tooltip = `NULLABLE:${this.column.NULLS}, DEFAULT:${this.column.DEFAULT}, GENERATED:${this.column.GENERATED}`;
        if (this.column.KEYSEQ){
            icon = 'primaryKey.png';
        }
        if (this.column.FKEY) {
            icon = 'foreignKey.png';
            tooltip = tooltip + `, PARENT_TABLE:${this.column.PARENTTABLE}`
        }
        if (this.column.KEYSEQ && this.column.FKEY){
            icon = 'bothKeys.png';
        }
        if (this.column.INDNAME){
            tooltip = tooltip + `, INDEX:${this.column.INDNAME}`
            if (this.column.UNIQUE){
                label = label + ` {${this.column.UNIQUE} }`
            }
        }
        return {
            label,
            tooltip,
            collapsibleState: vscode.TreeItemCollapsibleState.None,
            contextValue: 'db2connect.tree.column',
            command: {
                title: 'select-column',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light: path.join(__dirname, `../../Resources/light/${icon}`),
                dark: path.join(__dirname, `../../Resources/dark/${icon}`)
            }
        };
    }

    getChildren() {
        return __awaiter(this, void 0, void 0, function* () { return []; });
    }
}
exports.ColumnNode = ColumnNode;