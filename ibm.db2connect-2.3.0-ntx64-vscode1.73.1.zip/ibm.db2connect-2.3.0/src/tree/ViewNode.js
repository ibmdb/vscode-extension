var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const path = require("path");
const vscode = require("vscode");
const columnNode = require("./ColumnNode");
const errorNode = require("./ErrorNode");

class ViewNode {
    constructor(connection, view, schemaName) {
        this.connection = connection;
        this.view = view;
        this.schemaName = schemaName;
    }

    getTreeItem() {
        return {
            label: this.view,
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.view',
            command: {
                title: 'select-trigger',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light: path.join(__dirname, `../../Resources/light/view.svg`),
                dark: path.join(__dirname, `../../Resources/dark/view.svg`)
            }
        };
    }
    getChildren() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                    let res = null;
                    if (this.connection.serverName == "luw") {
                        res = yield this.connection.connObj.query("select COLNAME as NAME, TYPENAME as COLTYPE, LENGTH, NULLS, DEFAULT, GENERATED from SYSCAT.COLUMNS where TABNAME = ? and TABSCHEMA = ? ORDER BY COLNO", [this.view,this.schemaName]);
                    } else if (this.connection.serverName == "zos"){
                        res = yield this.connection.connObj.query("select NAME, COLTYPE, LENGTH, NULLS, DEFAULT, GENERATED_ATTR as GENERATED from SYSIBM.SYSCOLUMNS where TBNAME = ? and TBCREATOR = ? ORDER BY COLNO", [this.view,this.schemaName]);
                    } else {
                        res = yield this.connection.connObj.query("select COLUMN_NAME as NAME, DATA_TYPE as COLTYPE, LENGTH, IS_NULLABLE as NULLS, COLUMN_DEFAULT as DEFAULT, IDENTITY_GENERATION as GENERATED from QSYS2.SYSCOLUMNS where TABLE_NAME = ? and TABLE_SCHEMA = ? ORDER BY ORDINAL_POSITION", [this.view, this.schemaName]);
                    }
                    return res.map( column => {
                        return new columnNode.ColumnNode(this.connection, this.view, column)
                    })
                }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
        });
    }
}
exports.ViewNode = ViewNode;