var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const ibmdb = require("ibm_db");
const path = require("path");
const vscode = require("vscode");
const tableNode = require("./TableNode");
const errorNode = require("./ErrorNode");

class TableFolder {
    constructor(connection, schemaName) {
        this.connection = connection;
        this.schemaName = schemaName;
    }
    getTreeItem() {
        return {
            label: 'Tables',
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.tablefolder',
            command: {
                title: 'expand-tables',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light: path.join(__dirname, '../../Resources/light/table_folder.svg'),
                dark: path.join(__dirname, '../../Resources/dark/table_folder.svg')
            }
        };
    }
    getChildren() {
        return __awaiter(this, void 0, void 0, function* () {
            //let table1 = {"name":"Tablename", "schema":this.connection.schema,"is_table":true};
            try {
                    let res = null;
                    //select * from syscat.TABLES where TABSCHEMA = 'SCH1';
                    if (this.connection.serverName == "luw") {
                        res = yield this.connection.connObj.query("select TABNAME as NAME from SYSCAT.TABLES where TYPE = 'T' AND TABSCHEMA = ? ORDER BY TABNAME", [this.schemaName]);
                    } else if (this.connection.serverName == "zos"){
                        res = yield this.connection.connObj.query("select NAME from SYSIBM.SYSTABLES where TYPE = 'T' AND CREATOR = ? ORDER BY NAME", [this.schemaName]);
                    } else {
                        res = yield this.connection.connObj.query("select TABLE_NAME as NAME from QSYS2.SYSTABLES where TABLE_SCHEMA = ? and TABLE_TYPE = 'T' ORDER BY TABLE_NAME", [this.schemaName]);
                    }
                    if (res.length > 0) {
                    return res.map( table => {
                        return new tableNode.TableNode(this.connection, table.NAME, this.schemaName)
                    })
                    } else {
                        vscode.window.showInformationMessage("No TABLES in this schema");
                        return [];
                    }
                    //return [new tableNode.TableNode(this.connection, table.name, table1.is_table, table1.schema)];
            }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
        });
    }
}
exports.TableFolder = TableFolder;