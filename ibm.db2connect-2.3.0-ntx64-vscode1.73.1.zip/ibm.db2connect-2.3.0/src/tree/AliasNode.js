var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const path = require("path");
const vscode = require("vscode");
const aliascolumnNode = require("./AliasColumnNode");
const errorNode = require("./ErrorNode");

class AliasNode {
    constructor(connection, alias, schema) {
        this.connection = connection;
        this.alias = alias;
        this.schemaName = schema;
    }

    getTreeItem() {
        return {
            label: this.alias,
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.alias',
            command: {
                title: 'select-alias',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light: path.join(__dirname, `../../Resources/light/table.svg`),
                dark: path.join(__dirname, `../../Resources/dark/table.svg`)
            }
        };
    }

    // getChildren() {
    //     return __awaiter(this, void 0, void 0, function* () { return []; });
    // }

    getChildren() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                    let res = null;
                    res = yield this.connection.connObj.query("SELECT 'BASE_TABLE' as NAME, rtrim(BASE_TABSCHEMA) concat '.' concat BASE_TABNAME as COLTYPE from SYSCAT.TABLES where TYPE = 'A' and TABNAME = ? and TABSCHEMA = ?", [this.alias, this.schemaName])
                    return res.map( column => {
                        return new aliascolumnNode.AliasColumnNode(this.connection, this.alias, column)
                    })
            }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
        });
    }
}
exports.AliasNode = AliasNode;