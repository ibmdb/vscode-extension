var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const path = require("path");
const vscode = require("vscode");
const errorNode = require("./ErrorNode");
const triggerTableName = require("./TriggerTableName");
const triggerActivation = require("./TriggerActivation");
const triggerEvent = require("./TriggerEvent");
const triggerStatus = require("./TriggerStatus");

class TriggerNode {
    constructor(connection, trigger, schemaName) {
        this.connection = connection;
        this.trigger = trigger;
        this.schemaName = schemaName;
    }

    getTreeItem() {
        return {
            label: this.trigger,
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.trigger',
            command: {
                title: 'select-trigger',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light: path.join(__dirname, `../../Resources/light/trigger.svg`),
                dark: path.join(__dirname, `../../Resources/dark/trigger.svg`)
            }
        };
    }

    getChildren() {
        return __awaiter(this, void 0, void 0, function* () { 
            try {
                let childs = [];
                let res = null;
                if (this.connection.serverName == "luw") {
                    res = yield this.connection.connObj.query("select rtrim(tabschema) concat '.' concat tabname as table_name, case trigtime when 'B' then 'before' when 'A' then 'after' when 'I' then 'instead of' end as activation, rtrim(case when eventupdate ='Y' then  'update ' else '' end concat case when eventdelete ='Y' then  'delete ' else '' end concat case when eventinsert ='Y' then  'insert ' else '' end) as event, case when ENABLED = 'N' then 'disabled' else 'active' end as status from SYSCAT.TRIGGERS where TRIGNAME = ? and TRIGSCHEMA = ?", [this.trigger, this.schemaName]);
                } else if (this.connection.serverName == "zos"){
                    res = yield this.connection.connObj.query("select rtrim(TBOWNER) concat '.' concat TBNAME as TABLE_NAME, case TRIGTIME when 'B' then 'before' when 'A' then 'after' when 'I' then 'instead of' end as ACTIVATION, case TRIGEVENT when 'I' then 'Insert' when 'U' then 'Update' when 'D' then 'DELETE' end as EVENT, case when ACTIVE = 'N' then 'disabled' WHEN ACTIVE = 'Y' then 'active' else 'blank' end as status from SYSIBM.SYSTRIGGERS where NAME = ? and SCHEMA = ?", [this.trigger, this.schemaName]);
                } else {
                    res = yield this.connection.connObj.query("select rtrim(EVENT_OBJECT_SCHEMA) concat '.' concat EVENT_OBJECT_TABLE as TABLE_NAME, ACTION_TIMING as ACTIVATION, EVENT_MANIPULATION as event, case when ENABLED = 'N' then 'disabled' else 'active' end as status from QSYS2.SYSTRIGGERS where TRIGGER_NAME = ? and TRIGGER_SCHEMA = ? ", [this.trigger, this.schemaName]);
                }
                res.map( trigger => {
                    childs.push(new triggerTableName.TriggerTableName(this.connection, trigger.TABLE_NAME, this.schemaName));
                    childs.push(new triggerActivation.TriggerActivation(this.connection, trigger.ACTIVATION, this.schemaName));
                    childs.push(new triggerEvent.TriggerEvent(this.connection, trigger.EVENT, this.schemaName));
                    childs.push(new triggerStatus.TriggerStatus(this.connection, trigger.STATUS, this.schemaName));
                });
                return childs;
            }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
        });
    }

    // getChildren() {
    //     return __awaiter(this, void 0, void 0, function* () {
    //         try {
    //                 let res = null;
    //                 res = yield this.connection.connObj.query("SELECT NAME, COLTYPE FROM SYSIBM.SYSCOLUMNS WHERE TBNAME = ?", [this.alias])
    //                 return res.map( column => {
    //                     return new columnNode.ColumnNode(this.connection, this.alias, column)
    //                 })
    //         }
    //         catch (err) {
    //             return [new errorNode.ErrorNode(err)];
    //         }
    //         finally {
    //             vscode.window.showInformationMessage("This is getchildren in alias");
    //         }
    //     });
    // }
}
exports.TriggerNode = TriggerNode;