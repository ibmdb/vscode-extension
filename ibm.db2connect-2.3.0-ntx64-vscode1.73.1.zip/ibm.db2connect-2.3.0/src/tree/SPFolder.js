var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const path = require("path");
const vscode = require("vscode");
const spNode = require("./SPNode");
const errorNode = require("./ErrorNode");

class SPFolder {
    constructor(connection, schemaName) {
        this.connection = connection;
        this.schemaName = schemaName;
    }
    getTreeItem() {
        return {
            label: "StoredProcedures",
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.spfolder',
            command: {
                title: 'expand-storeprocedures',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light:  path.join(__dirname, '../../Resources/light/stored_procedure.svg'),
                dark:   path.join(__dirname, '../../Resources/dark/stored_procedure.svg')
            }
        };
    }
    getChildren() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                    let res = null;
                    if (this.connection.serverName == "luw") {
                        res = yield this.connection.connObj.query("select ROUTINENAME as PROCNAME, SPECIFICNAME as PROCEDURE_ID from SYSCAT.ROUTINES where ROUTINESCHEMA = ? and ROUTINETYPE = 'P' ORDER BY ROUTINENAME", [this.schemaName]);
                    } else if (this.connection.serverName == "zos"){
                        res = yield this.connection.connObj.query("select SPECIFICNAME as PROCEDURE_ID, NAME as PROCNAME from SYSIBM.SYSROUTINES where SCHEMA = ? and ROUTINETYPE = 'P' ORDER BY NAME", [this.schemaName]);
                    } else {
                        res = yield this.connection.connObj.query("select SPECIFIC_NAME as PROCEDURE_ID, ROUTINE_NAME as PROCNAME from QSYS2.SYSROUTINES where ROUTINE_SCHEMA = ? and ROUTINE_TYPE= 'PROCEDURE' ORDER BY ROUTINE_NAME", [this.schemaName]);
                    }
                if (res.length > 0){
                    return res.map( sp => {
                        return new spNode.SPNode(this.connection, sp.PROCNAME, sp.PROCEDURE_ID, this.schemaName)
                    })
                } else {
                    vscode.window.showInformationMessage("No STORED PROCEDURES in this schema");
                    return [];
                }
            }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
        });
    }
}
exports.SPFolder = SPFolder;