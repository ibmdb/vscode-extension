const path = require("path");
const vscode = require("vscode");
const indexTableName = require("./IndexTableName");
const indexUnique = require("./IndexUnique");
const indexCols = require("./IndexCols");
const errorNode = require("./ErrorNode");

class IndexNode {
    constructor(connection, index, schema) {
        this.connection = connection;
        this.index = index;
        this.schemaName = schema;
    }

    getTreeItem() {
        return {
            label: this.index,
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.index',
            command: {
                title: 'select-index',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light: path.join(__dirname, `../../Resources/light/table.svg`),
                dark: path.join(__dirname, `../../Resources/dark/table.svg`)
            }
        };
    }
    getChildren() {
            try {
                    let childs = []
                    let res = null;
                    let index_cols = '';
                    let res_index_cols = null;
                    if (this.connection.serverName == "luw") {
                        res = this.connection.connObj.querySync("select rtrim(TABSCHEMA) concat '.' concat TABNAME as TABLE_NAME, CASE WHEN UNIQUERULE = 'D' then 'false' else 'true' end AS UNIQUE FROM SYSCAT.INDEXES WHERE INDNAME = ? AND INDSCHEMA = ?", [this.index, this.schemaName]);
                        res_index_cols = this.connection.connObj.querySync("SELECT COLNAME FROM SYSCAT.INDEXCOLUSE WHERE INDNAME = ? AND INDSCHEMA = ?", [this.index, this.schemaName]);
                        var i;
                        if (res_index_cols.length > 0) {
                            for (i=0;i<res_index_cols.length;i++){
                                if(index_cols == ''){
                                    index_cols = res_index_cols[i].COLNAME
                                } else {
                                    index_cols = index_cols + ',' + res_index_cols[i].COLNAME
                                }
                            }
                            res[0].Columns = index_cols
                        } else {
                            res[0].Columns = ""
                        }
                    } else if (this.connection.serverName == "zos"){
                        res = this.connection.connObj.querySync("select rtrim(TBCREATOR) concat '.' concat TBNAME as TABLE_NAME, CASE WHEN UNIQUERULE = 'D' then 'false' else 'true' end AS UNIQUE FROM SYSIBM.SYSINDEXES WHERE NAME = ? AND CREATOR = ? ", [this.index, this.schemaName]);
                        res_index_cols = this.connection.connObj.querySync("SELECT COLNAME FROM SYSIBM.SYSKEYS WHERE IXNAME = ? AND IXCREATOR = ?", [this.index, this.schemaName]);
                        var i;
                        if (res_index_cols.length > 0) {
                            for (i=0;i<res_index_cols.length;i++){
                                if(index_cols == ''){
                                    index_cols = res_index_cols[i].COLNAME
                                } else {
                                    index_cols = index_cols + ',' + res_index_cols[i].COLNAME
                                }
                            }
                            res[0].Columns = index_cols
                        } else {
                            res[0].Columns = ""
                        }
                    } else {
                        res = this.connection.connObj.querySync("select rtrim(TABLE_SCHEMA) concat '.' concat TABLE_NAME as TABLE_NAME, CASE WHEN UNIQUERULE = 'D' then 'false' else 'true' end AS UNIQUE FROM QSYS2.SYSINDEXES WHERE INDEX_NAME = ? AND INDEX_SCHEMA = ? ", [this.index, this.schemaName]);
                        res_index_cols = this.connection.connObj.querySync("SELECT COLUMN_NAME as COLNAME FROM QSYS2.SYSKEYS WHERE INDEX_NAME = ? AND INDEX_SCHEMA = ?", [this.index, this.schemaName]);
                        var i;
                        if (res_index_cols.length > 0) {
                            for (i=0;i<res_index_cols.length;i++){
                                if(index_cols == ''){
                                    index_cols = res_index_cols[i].COLNAME
                                } else {
                                    index_cols = index_cols + ',' + res_index_cols[i].COLNAME
                                }
                            }
                            res[0].Columns = index_cols
                        } else {
                            res[0].Columns = ""
                        }
                    }
                    if (res.length > 0) {
                        res.map( index => {
                            childs.push(new indexTableName.IndexTableName(this.connection, index.TABLE_NAME, this.schemaName));
                            childs.push(new indexUnique.IndexUnique(this.connection, index.UNIQUE, this.schemaName));
                            childs.push(new indexCols.IndexCols(this.connection, index.Columns, this.schemaName));
                        })
                        return childs
                    } else {
                        vscode.window.showInformationMessage("No COLUMNS in this index");
                        return [];
                    }
                }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
    }
}
exports.IndexNode = IndexNode;