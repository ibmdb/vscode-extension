var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const path = require("path");
const vscode = require("vscode");
const columnNode = require("./ColumnNode");
const errorNode = require("./ErrorNode");

class TableNode {
    constructor(connection, table, schema) {
        this.connection = connection;
        this.table = table;
        this.schemaName = schema;
    }

    getTreeItem() {
        return {
            label: this.table,
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.table',
            command: {
                title: 'select-table',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light: path.join(__dirname, `../../Resources/light/table.svg`),
                dark: path.join(__dirname, `../../Resources/dark/table.svg`)
            }
        };
    }
    getChildren() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                    let res = null;
                    let res1 = null;
                    let res2 = null;
                    let res_index = null;
                    if (this.connection.serverName == "luw") {
                        res = yield this.connection.connObj.query("SELECT COLNAME as NAME, TYPENAME as COLTYPE, LENGTH, NULLS, DEFAULT, GENERATED, KEYSEQ from SYSCAT.COLUMNS where TABNAME = ? and TABSCHEMA = ? ORDER BY COLNO", [this.table, this.schemaName]);
                        res1 = yield this.connection.connObj.query("SELECT B.COLNAME as FKEY, rtrim(REFTABSCHEMA) concat '.' concat REFTABNAME as PARENTTABLE FROM SYSCAT.REFERENCES A, SYSCAT.KEYCOLUSE B WHERE A.CONSTNAME = B.CONSTNAME AND  B.TABNAME = ? AND B.TABSCHEMA = ?", [this.table, this.schemaName]);
                        res_index = yield this.connection.connObj.query("SELECT rtrim(b.INDSCHEMA) concat '.' concat b.INDNAME as INDNAME1, b.COLNAME, CASE WHEN a.UNIQUERULE = 'D' then 'NUI' else 'UI' end AS UNIQUE FROM SYSCAT.INDEXES a, SYSCAT.INDEXCOLUSE b WHERE a.INDNAME = b.INDNAME AND a.INDSCHEMA = b.INDSCHEMA AND a.TABSCHEMA = ? AND a.TABNAME = ? AND (a.UNIQUERULE = 'D' OR a.UNIQUERULE = 'U')", [this.schemaName, this.table]);
                        var i,j;
                        if (res1.length > 0){
                            for (i=0;i<res.length;i++){
                                for (j=0;j<res1.length;j++){
                                    if (res[i].NAME == res1[j].FKEY){
                                        res[i].FKEY = i + 1
                                        res[i].PARENTTABLE = res1[j].PARENTTABLE
                                        break
                                    } else {
                                        res[i].FKEY = null
                                    }
                                }
                            }
                        }
                        if (res_index.length > 0){
                            for (i=0;i<res.length;i++){
                                for (j=0;j<res_index.length;j++){
                                    if (res[i].NAME == res_index[j].COLNAME){
                                        if (res[i].INDNAME) {
                                            res[i].INDNAME = res[i].INDNAME + ", " + res_index[j].INDNAME1
                                        } else {
                                            res[i].INDNAME = res_index[j].INDNAME1
                                        }
                                        if (res[i].UNIQUE) {
                                            res[i].UNIQUE = res[i].UNIQUE + ", " + res_index[j].UNIQUE
                                        } else {
                                            res[i].UNIQUE = " " + res_index[j].UNIQUE
                                        }
                                    }
                                }
                            }
                        }
                    } else if (this.connection.serverName == "zos"){
                        res = yield this.connection.connObj.query("SELECT NAME, COLTYPE, LENGTH, NULLS, DEFAULT, GENERATED_ATTR as GENERATED, KEYSEQ from SYSIBM.SYSCOLUMNS where TBNAME = ? and TBCREATOR = ? ORDER BY COLNO", [this.table, this.schemaName]);
                        res1 = yield this.connection.connObj.query("SELECT COLNAME AS FKEY, rtrim(REFTBCREATOR) concat '.' concat REFTBNAME as PARENTTABLE FROM SYSIBM.SYSFOREIGNKEYS A, SYSIBM.SYSRELS B WHERE A.RELNAME = B.RELNAME AND B.TBNAME = ? AND B.REFTBCREATOR = ? AND B.REFTBCREATOR = A.CREATOR", [this.table, this.schemaName]);
                        res_index = yield this.connection.connObj.query("SELECT rtrim(b.IXCREATOR) concat '.' concat b.IXNAME as INDNAME1, b.COLNAME, CASE WHEN a.UNIQUERULE = 'D' then 'NUI' else 'UI' end AS UNIQUE FROM SYSIBM.SYSINDEXES a, SYSIBM.SYSKEYS b WHERE a.NAME = b.IXNAME AND a.CREATOR = b.IXCREATOR AND a.TBCREATOR = ? AND a.TBNAME = ? AND (a.UNIQUERULE = 'D' OR a.UNIQUERULE = 'U')", [this.schemaName, this.table])
                        var i,j;
                        if (res1.length > 0){
                            for (i=0;i<res.length;i++){
                                for (j=0;j<res1.length;j++){
                                    if (res[i].NAME == res1[j].FKEY){
                                        res[i].FKEY = i + 1
                                        res[i].PARENTTABLE = res1[j].PARENTTABLE
                                        break
                                    } else {
                                        res[i].FKEY = null
                                    }
                                }
                            }
                        }
                        if (res_index.length > 0){
                            for (i=0;i<res.length;i++){
                                for (j=0;j<res_index.length;j++){
                                    if (res[i].NAME == res_index[j].COLNAME){
                                        if (res[i].INDNAME) {
                                            res[i].INDNAME = res[i].INDNAME + ", " + res_index[j].INDNAME1
                                        } else {
                                            res[i].INDNAME = res_index[j].INDNAME1
                                        }
                                        if (res[i].UNIQUE) {
                                            res[i].UNIQUE = res[i].UNIQUE + ", " + res_index[j].UNIQUE
                                        } else {
                                            res[i].UNIQUE = " " + res_index[j].UNIQUE
                                        }
                                    }
                                }
                            }
                        }
                    } else {
                        res = yield this.connection.connObj.query("select COLUMN_NAME as NAME, DATA_TYPE as COLTYPE, LENGTH, IS_NULLABLE as NULLS, COLUMN_DEFAULT as DEFAULT, IDENTITY_GENERATION as GENERATED from QSYS2.SYSCOLUMNS where TABLE_NAME = ? and TABLE_SCHEMA = ? ORDER BY ORDINAL_POSITION", [this.table, this.schemaName]);
                        res1 = yield this.connection.connObj.query("SELECT COLUMN_NAME as KEYSEQ FROM QSYS2.SYSKEYCST A, QSYS2.SYSCST B WHERE A.CONSTRAINT_NAME = B.CONSTRAINT_NAME AND A.TABLE_NAME = ? AND A.TABLE_SCHEMA = ? AND B.CONSTRAINT_TYPE = 'PRIMARY KEY'", [this.table, this.schemaName]);
                        res2 = yield this.connection.connObj.query("SELECT COLUMN_NAME as FKEY, C.UNIQUE_CONSTRAINT_NAME as PARENTTABLE FROM QSYS2.SYSKEYCST A, QSYS2.SYSCST B, QSYS2.SYSREFCST C WHERE A.CONSTRAINT_NAME = B.CONSTRAINT_NAME AND A.CONSTRAINT_NAME = C.CONSTRAINT_NAME AND A.TABLE_NAME = ? AND A.TABLE_SCHEMA = ? AND B.CONSTRAINT_TYPE = 'FOREIGN KEY'", [this.table, this.schemaName]);
                        res_index =  yield this.connection.connObj.query("SELECT rtrim(b.INDEX_SCHEMA) concat '.' concat b.INDEX_NAME as INDNAME1, b.COLUMN_NAME as COLNAME, CASE WHEN a.IS_UNIQUE = 'U' then 'UI' else 'NUI' end AS UNIQUE FROM QSYS2.SYSINDEXES a, QSYS2.SYSKEYS b WHERE a.INDEX_NAME = b.INDEX_NAME AND a.INDEX_SCHEMA = b.INDEX_SCHEMA AND a.TABLE_NAME = ? AND a.TABLE_SCHEMA = ?", [this.table, this.schemaName]);
                        var i,j;
                        if (res1.length > 0){
                            for (i=0;i<res.length;i++){
                                for (j=0;j<res1.length;j++){
                                    if (res[i].NAME == res1[j].KEYSEQ){
                                        res[i].KEYSEQ = i + 1
                                        break
                                    } else {
                                        res[i].KEYSEQ = null
                                    }
                                }
                            }
                        }
                        if (res2.length > 0){
                            for (i=0;i<res.length;i++){
                                for (j=0;j<res2.length;j++){
                                    if (res[i].NAME == res2[j].FKEY){
                                        res[i].FKEY = i + 1
                                        res[i].PARENTTABLE = res2[j].PARENTTABLE
                                        break
                                    } else {
                                        res[i].FKEY = null
                                    }
                                }
                            }
                        }
                        if (res_index.length > 0){
                            for (i=0;i<res.length;i++){
                                for (j=0;j<res_index.length;j++){
                                    if (res[i].NAME == res_index[j].COLNAME){
                                        if (res[i].INDNAME) {
                                            res[i].INDNAME = res[i].INDNAME + ", " + res_index[j].INDNAME1
                                        } else {
                                            res[i].INDNAME = res_index[j].INDNAME1
                                        }
                                        if (res[i].UNIQUE) {
                                            res[i].UNIQUE = res[i].UNIQUE + ", " + res_index[j].UNIQUE
                                        } else {
                                            res[i].UNIQUE = " " + res_index[j].UNIQUE
                                        }
                                    }
                                }
                            }
                        }
                    }
                    if (res.length > 0) {
                        return res.map( column => {
                            return new columnNode.ColumnNode(this.connection, this.table, column)
                        })
                    } else {
                        vscode.window.showInformationMessage("No COLUMNS in this table");
                        return [];
                    }
                    //return [new columnNode.ColumnNode(this.connection, this.table, column)];
                }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
        });
    }
}
exports.TableNode = TableNode;