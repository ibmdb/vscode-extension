var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const ibmdb = require("ibm_db");
const path = require("path");
const vscode = require("vscode");
const aliasNode = require("./AliasNode");
const errorNode = require("./ErrorNode");

class AliasFolder {
    constructor(connection, schemaName) {
        this.connection = connection;
        this.schemaName = schemaName;
    }
    getTreeItem() {
        return {
            label: 'Alias',
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.aliasfolder',
            command: {
                title: 'expand-alias',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light: path.join(__dirname, '../../Resources/light/table_folder.svg'),
                dark: path.join(__dirname, '../../Resources/dark/table_folder.svg')
            }
        };
    }
    getChildren() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                    let res = null;
                    if (this.connection.serverName == "luw") {
                        res = yield this.connection.connObj.query("select TABNAME as NAME from SYSCAT.TABLES where TYPE = 'A' and TABSCHEMA = ? ORDER BY TABNAME", [this.schemaName]);
                    } else if (this.connection.serverName == "zos"){
                        res = yield this.connection.connObj.query("select NAME from SYSIBM.SYSTABLES where TYPE = 'A' AND CREATOR = ? ORDER BY NAME", [this.schemaName]);
                    } else {
                        res = yield this.connection.connObj.query("select TABLE_NAME as NAME from QSYS2.SYSTABLES where TABLE_SCHEMA = ? and TABLE_TYPE = 'A' ORDER BY TABLE_NAME", [this.schemaName]);
                    }
                    if (res.length > 0) {
                        return res.map( alias => {
                            return new aliasNode.AliasNode(this.connection, alias.NAME, this.schemaName)
                        });
                    } else {
                        vscode.window.showInformationMessage("No ALIAS in this schema");
                        return [];
                    }
                }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
        });
    }
}
exports.AliasFolder = AliasFolder;