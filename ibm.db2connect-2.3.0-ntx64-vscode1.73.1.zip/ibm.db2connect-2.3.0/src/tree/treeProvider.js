var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const vscode = require("vscode")
const path = require("path")
const Constants = require("../constants")
const connectionNode_1 = require("./ConnectionNode")

class IBM_DBTreeDataprovider{
    constructor(context) {
        this.context = context;
        this._onDidChangeTreeData = new vscode.EventEmitter();
        this.onDidChangeTreeData = this._onDidChangeTreeData.event;
        this.refresh();
    }
    
    static getInstance(context) {
        if (context && !this._instance) {
            this._instance = new IBM_DBTreeDataprovider(context);
            context.subscriptions.push(vscode.window.registerTreeDataProvider("db2connect", this._instance));
        }
        return this._instance;
    }

    refresh(element) {
        this._onDidChangeTreeData.fire(element);
    }

    getTreeItem(element) {
        return element.getTreeItem();
    }

    getChildren(element) {
        if (!element) {
            return this.getConnectionNodes();
        }
        return element.getChildren();
    }
    
    getConnectionNodes() {
        return __awaiter(this, void 0, void 0, function* () {
            //const connections = this.context.globalState.get(Constants.GlobalStateKey);
            const ConnectionNodes = [];
            if (Object.keys(Constants.connections).length >= 1) {
                for (const id of Object.keys(Constants.connections)) {
                    let connection = Object.assign({}, Constants.connections[id]);
                    ConnectionNodes.push(new connectionNode_1.ConnectionNode(id, connection));
                }
            }
            return ConnectionNodes;
        });
    }
}

IBM_DBTreeDataprovider._instance = null;
exports.IBM_DBTreeDataprovider = IBM_DBTreeDataprovider;