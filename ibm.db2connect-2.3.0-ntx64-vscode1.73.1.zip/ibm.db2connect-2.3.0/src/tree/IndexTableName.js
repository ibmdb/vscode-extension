const path = require("path");
const vscode = require("vscode");

class IndexTableName {
    constructor(connection, ITabName, schemaName) {
        this.connection = connection;
        this.ITabName = ITabName;
        this.schemaName = schemaName;
    }
    getTreeItem() {
        return {
            label: `TableName: ${this.ITabName}`,
            collapsibleState: vscode.TreeItemCollapsibleState.None,
            contextValue: 'db2connect.tree.ITabName',
            command: {
                title: 'select-ITabName',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light:  path.join(__dirname, '../../Resources/light/column.svg'),
                dark:   path.join(__dirname, '../../Resources/dark/column.svg')
            }
        };
    }
    getChildren() {
        return []
    }
}
exports.IndexTableName = IndexTableName;