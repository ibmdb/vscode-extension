var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const path = require("path");
const vscode = require("vscode");
const schemaNode = require("./SchemaNode");
const errorNode = require("./ErrorNode");

class DatabaseNode {
    constructor(connection) {
        this.connection = connection;
    }
    getTreeItem() {
        return {
            label: this.connection.database || this.connection.dsn,
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.database',
            command: {
                title: 'select-database',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light:  path.join(__dirname, '../../Resources/light/database.svg'),
                dark:   path.join(__dirname, '../../Resources/dark/database.svg')
            }
        };
    }
    getChildren() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                let childs = [];
                let res = null;
                if (this.connection.serverName == "luw") {
                    res = yield this.connection.connObj.query("select SCHEMANAME from SYSCAT.SCHEMATA ORDER BY SCHEMANAME");
                } else if (this.connection.serverName == "zos"){
                    res = yield this.connection.connObj.query("select distinct schemaname from (select creator from sysibm.systables union all select schema from sysibm.sysdatatypes union all select schema from sysibm.sysroutines union all select schema from sysibm.systriggers) schemata(schemaname)");
                } else {
                    res = yield this.connection.connObj.query("select SCHEMA_NAME as SCHEMANAME from QSYS2.SYSSCHEMAS");
                }
                if (res.length > 0) {
                    res.map( schema => {
                        childs.push(new schemaNode.SchemaNode(this.connection, schema.SCHEMANAME));
                    });
                    return childs;
                } else {
                    vscode.window.showInformationMessage("No SCHEMAS in this database");
                    return [];
                }
                //return [new schemaNode.SchemaNode(this.connection, this.connection.schema)];
            }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
        });
    }
}
exports.DatabaseNode = DatabaseNode;