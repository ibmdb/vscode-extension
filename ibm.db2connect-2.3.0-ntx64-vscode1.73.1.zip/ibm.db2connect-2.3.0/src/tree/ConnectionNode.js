var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
const vscode = require("vscode");
const path = require("path");
const databaseNode = require("./DatabaseNode");

class ConnectionNode {
    constructor(id, connection) {
        this.id = id;
        this.connection = connection;
    }
    getTreeItem() {
        return {
            label: this.connection.profile || this.connection.dsn || this.connection.host + '@' + this.connection.schema + '@' + this.connection.port,
            tooltip: this.connection.host + '@' + this.connection.schema + '@' + this.connection.port + '@' + this.connection.database,
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: "db2connect.tree.connection",
            command: {
                title: 'select-connection',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light: path.join(__dirname, '../../Resources/light/server.svg'),
                dark: path.join(__dirname, '../../Resources/dark/server.svg')
            }
        };
    }
    getChildren() {
        return __awaiter(this, void 0, void 0, function* () {
            if (this.connection.database) {
                return [new databaseNode.DatabaseNode(this.connection)];
            }
            else {
                vscode.window.showInformationMessage("No database in the global connection");
            }
        });
    }
}
exports.ConnectionNode = ConnectionNode;