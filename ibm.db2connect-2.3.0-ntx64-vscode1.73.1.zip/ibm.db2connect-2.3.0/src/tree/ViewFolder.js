var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const ibmdb = require("ibm_db");
const path = require("path");
const vscode = require("vscode");
const viewNode = require("./ViewNode");
const errorNode = require("./ErrorNode");

class ViewFolder {
    constructor(connection, schemaName) {
        this.connection = connection;
        this.schemaName = schemaName;
    }
    getTreeItem() {
        return {
            label: 'Views',
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.viewfolder',
            command: {
                title: 'expand-views',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light: path.join(__dirname, '../../Resources/light/view_folder.svg'),
                dark: path.join(__dirname, '../../Resources/dark/view_folder.svg')
            }
        };
    }
    getChildren() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                    let res = null;
                    if (this.connection.serverName == "luw") {
                        res = yield this.connection.connObj.query("select VIEWNAME as NAME from SYSCAT.VIEWS where VIEWSCHEMA = ? ORDER BY VIEWNAME", [this.schemaName]);
                    } else if (this.connection.serverName == "zos"){
                        res = yield this.connection.connObj.query("select NAME from SYSIBM.SYSVIEWS where CREATOR = ? ORDER BY NAME", [this.schemaName]);
                    } else {
                        res = yield this.connection.connObj.query("select TABLE_NAME as NAME from QSYS2.SYSTABLES where TABLE_SCHEMA = ? and TABLE_TYPE = 'V' ORDER BY TABLE_NAME", [this.schemaName]);
                    }
                    
                if (res.length > 0) {
                    return res.map( view => {
                        return new viewNode.ViewNode(this.connection, view.NAME, this.schemaName)
                    });
                    } else {
                    vscode.window.showInformationMessage("No VIEWS in this schema");
                    return [];
                }
            }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
        });
    }
}
exports.ViewFolder = ViewFolder;