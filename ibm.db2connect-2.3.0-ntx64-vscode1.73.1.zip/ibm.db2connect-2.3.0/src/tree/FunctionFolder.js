var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const path = require("path");
const vscode = require("vscode");
const funcNode = require("./FunctionNode")
const errorNode = require("./ErrorNode");

class FunctionFolder {
    constructor(connection, schemaName) {
        this.connection = connection;
        this.schemaName = schemaName;
    }
    getTreeItem() {
        return {
            label: "Functions",
            collapsibleState: vscode.TreeItemCollapsibleState.Collapsed,
            contextValue: 'db2connect.tree.functionfolder',
            command: {
                title: 'expand-functions',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light:  path.join(__dirname, '../../Resources/light/function_folder.svg'),
                dark:   path.join(__dirname, '../../Resources/dark/function_folder.svg')
            }
        };
    }
    getChildren() {
        return __awaiter(this, void 0, void 0, function* () {
            try {
                    let res = null;
                    if (this.connection.serverName == "luw") {
                        res = yield this.connection.connObj.query("select ROUTINENAME as NAME, SPECIFICNAME as SPECIFIC from SYSCAT.ROUTINES where ROUTINESCHEMA = ? and ROUTINETYPE = 'F' ORDER BY NAME", [this.schemaName]);
                    } else if (this.connection.serverName == "zos"){
                        res = yield this.connection.connObj.query("select NAME, SPECIFICNAME as SPECIFIC from SYSIBM.SYSROUTINES where SCHEMA = ? and ROUTINETYPE = 'F' ORDER BY NAME", [this.schemaName]);
                    } else {
                        res = yield this.connection.connObj.query("select SPECIFIC_NAME as SPECIFIC, ROUTINE_NAME as NAME from QSYS2.SYSROUTINES where ROUTINE_SCHEMA = ? and ROUTINE_TYPE= 'FUNCTION' ORDER BY ROUTINE_NAME", [this.schemaName]);
                    }
                    if (res.length > 0){
                        return res.map( func => {
                            return new funcNode.FunctionNode(this.connection, func.NAME, func.SPECIFIC, this.schemaName)
                        });
                    } else {
                        vscode.window.showInformationMessage("No FUNCTIONS in this schema");
                        return [];
                    }
                }
            catch (err) {
                return [new errorNode.ErrorNode(err)];
            }
            finally {
            }
        });
    }
}
exports.FunctionFolder = FunctionFolder;