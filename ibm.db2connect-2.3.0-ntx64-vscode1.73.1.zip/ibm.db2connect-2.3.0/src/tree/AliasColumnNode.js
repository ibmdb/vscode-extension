var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const path = require("path");
const vscode = require("vscode");

class AliasColumnNode {
    constructor(connection, tablename, column) {
        this.connection = connection;
        this.tablename = tablename;
        this.column = column;
    }

    getTreeItem() {
        let label = `${this.column.NAME} : ${this.column.COLTYPE}`;
        let tooltip = `${this.column.NAME} : ${this.column.COLTYPE}`;
        return {
            label,
            tooltip,
            collapsibleState: vscode.TreeItemCollapsibleState.None,
            contextValue: 'db2connect.tree.aliascolumn',
            command: {
                title: 'select-column',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light: path.join(__dirname, `../../Resources/light/column.svg`),
                dark: path.join(__dirname, `../../Resources/dark/column.svg`)
            }
        };
    }

    getChildren() {
        return __awaiter(this, void 0, void 0, function* () { return []; });
    }
}
exports.AliasColumnNode = AliasColumnNode;