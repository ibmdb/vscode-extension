var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : new P(function (resolve) { resolve(result.value); }).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};

const path = require("path");
const vscode = require("vscode");
const errorNode = require("./ErrorNode");

class InOutNode {
    constructor(connection, parmName, dataType, mode) {
        this.connection = connection;
        this.parmName = parmName;
        this.dataType = dataType;
        this.mode = mode;
    }
    getTreeItem() {
        return {
            label: `${this.parmName} : ${this.dataType} : ${this.mode}`,
            collapsibleState: vscode.TreeItemCollapsibleState.None,
            contextValue: 'db2connect.tree.inout',
            command: {
                title: 'select-inout',
                command: 'extension.Db2setActiveConnection',
                arguments: [this.connection]
            },
            iconPath: {
                light:  path.join(__dirname, '../../Resources/light/column.svg'),
                dark:   path.join(__dirname, '../../Resources/dark/column.svg')
            }
        };
    }
    getChildren() {
        return __awaiter(this, void 0, void 0, function* () { return [] });
    }
}
exports.InOutNode = InOutNode;