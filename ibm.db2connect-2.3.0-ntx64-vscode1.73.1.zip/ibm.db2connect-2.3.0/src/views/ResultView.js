const vscode = require("vscode");
const htmlContent = require("./htmlContent");
const EasyXml = require('easyxml');

class ResultView {
    constructor(webview, resource) {
        this._results = [];
        this._resource = resource;
        this._disposed = false;
        this.disposables = [];
        this._onDisposeEmitter = new vscode.EventEmitter();
        this.onDispose = this._onDisposeEmitter.event;
        this._onDidChangeViewStateEmitter = new vscode.EventEmitter();
        this.onDidChangeViewState = this._onDidChangeViewStateEmitter.event;
        this.editor = webview;
        this.editor.onDidDispose(() => this.dispose(), null, this.disposables);
        this.editor.onDidChangeViewState(e => this._onDidChangeViewStateEmitter.fire(e), null, this.disposables);
    }

    static createResult(resource) {
        const view = vscode.window.createWebviewPanel("Db2ConnectResult", "Results", vscode.ViewColumn.Active , Object.assign({ enableFindWidget: true },{ enableScripts: true , enableCommandUris: true}));
        return new ResultView(view, resource);
    }

    static create(resource) {
        const view = vscode.window.createWebviewPanel("Db2ConnectResult", resource, vscode.ViewColumn.Active , Object.assign({ enableFindWidget: true },{ enableScripts: true , enableCommandUris: true}));
        return new ResultView(view, resource);
    }

    get currentResults() {
        return this._results;
    }

    dispose() {
        if (this._disposed) {
            return;
        }
        this._disposed = true;
        this._onDisposeEmitter.fire();
        this._onDisposeEmitter.dispose();
        this._onDidChangeViewStateEmitter.dispose();
        this.editor.dispose();
        disposeAll(this.disposables);
    }

    update(resource, res) {
        this._results = res;
        this._resource = resource;
        this.editor.webview.html = htmlContent.getTableContent(resource, res);
    }

    append(title, data) {
        if (data && data.length) {
          this._results.push(data);
        }
        this.editor.webview.html += htmlContent.getResultContent(title, data);
    }
}

function disposeAll(disposables) {
    while (disposables.length) {
        const item = disposables.pop();
        if (!item)
            continue;
        item.dispose();
    }
}

exports.ResultView = ResultView;
exports.disposeAll = disposeAll;