function getTableBody(title, data) {
  let tableBody = "";
  let tHeaderContent = "";
  let tBodyContent = "";
  let tRowContent = "";

  if (data && data.length) {
    //Generate header content
    Object.keys(data[0]).forEach(key => {
      tHeaderContent += `<th style="background-color:#4CAF50;color:white;text-align:center;">${key}</th>`;
    });
    tHeaderContent = `<thead><tr>${tHeaderContent}</tr></thead>`;

    //Generate rows
    for (let eachRow of data) {
      let temp = "";
      Object.values(eachRow).forEach(val => {
        temp += `<td>${val}</td>`;
      });
      tRowContent += `<tr>${temp}</tr>`;
    }

    tBodyContent = `<tbody style="background-color:white;color:black;text-align:center;">${tRowContent}</tbody>`;
    tableBody = `<div><table>${tHeaderContent}${tBodyContent}</table></div>`;
  }
  return tableBody;
}

function getTableContent(title, data) {
  let tableBody = getTableBody(title, data);

  return `<!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">   
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Db2 Connect</title>
  </head>
  <body>
      <h3>QUERY: ${title}</h3>
      ${tableBody}
      <span>
      <h3>Number of Rows returned: ${data.length}</h3>
      </span>
  </body>
  <script type = "text/javascript">
  const vscodeApi = acquireVsCodeApi();

  (function() {
    //All buttons
    document.querySelectorAll('button').forEach(e => {
      e.style =
        'border-radius:0.25em;background-color:darkcyan;color:white;width:90px;height:25px;font-weight:bold;font-size:10px';
    });
  })();

  function exportR(){
    var data1 = [];
    var rows = document.querySelectorAll('table tr');
    for (var i = 0; i < rows.length; i++) {
      var row = [];
      var cols = rows[i].querySelectorAll('td, th');

      for (var j = 0; j < cols.length; j++)
        row.push(cols[j].innerText);

        data1.push(row);
    }
    vscodeApi.postMessage({
      msg:data1
    });
  }

  function downloadFile(csv, filename) {
    var csvFile;
    var downloadLink;

    // CSV file
    csvFile = new Blob([csv], { type: 'text/csv' });
    // Download link
    downloadLink = document.createElement('a');
    // File name
    downloadLink.download = filename;
    // Create a link to the file
    downloadLink.href = window.URL.createObjectURL(csvFile);
    // Hide download link
    //downloadLink.style.display = 'none';
    downloadLink.text = 'Download';
    // Add the link to DOM
    document.body.appendChild(downloadLink);
    downloadLink.addEventListener('click',()=>{
      console.log('downloading')
    })
    // Click download link
    downloadLink.click();
    console.log('downloading')
  }

  function exportResult() {
    alert('exporting')
    var csv = [];
    var rows = document.querySelectorAll('table tr');

    for (var i = 0; i < rows.length; i++) {
      var row = [];
      var cols = rows[i].querySelectorAll('td, th');

      for (var j = 0; j < cols.length; j++)
        row.push(cols[j].innerText);

      csv.push(row.join(','));
    }

    downloadFile(csv.join("\\n"), 'results.csv');
  }

  </script>
  </html>`;
}

function getResultContent(title, data) {
  let tableBody = getTableBody(title, data);

  let html = `<!DOCTYPE html>
  <html lang="en">
  <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>Db2 Connect</title>
  </head>
  <body>
      <h3>${title}</h3>
      ${tableBody}`;

  if (data && data.length) {
    html += `<span>
             Number of Rows returned: ${data.length}
             </span>`;
  }
  else if (data && data.length == 0) {
    html += `SQL Executed Successfully.`;
  }
  html += `
  </body>
  </html>`;
  return html;
}

function getConnectFormContent() {
  return`
  <!DOCTYPE html>
<html>
   <head>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
      <script>
         const vscodeApi = acquireVsCodeApi();
         var rowCount = 1;
         function validateFields(){
            var locationName = document.getElementById("locationName");
            var host = document.getElementById("host");
            var port = document.getElementById("port");
            var userId = document.getElementById("userId");
            var password = document.getElementById("password");
            var finishButton = document.getElementById("Finish");
            if(locationName.value && port.value && host.value && userId.value && password.value){
               finishButton.className = "finishButton";
               finishButton.disabled = false;
               return;
            }
            finishButton.className = "disablefinishButton";
            finishButton.disabled = true;
            return;
         }
         
         function addElement() {
          rowCount++;
		 document.getElementById('clearBtn').style.display = "none";
		 var checkBoxCounter = 0;
		  
		  // validate "selectAllCheckBox" checkBox conditions to render 
          var selectAllCheckBox = document.getElementById('selectAllCheckBox');
			  selectAllCheckBox.style.display = "block";
			
		  if(selectAllCheckBox.checked){
			 selectAllCheckBox.checked = false;
			}
			
          // create row
          var newRow = document.createElement('tr');
			  newRow.setAttribute('id', 'row'+rowCount);
			  
		  // add checkBox to row
          var checkBoxCell = document.createElement('td');
			  checkBoxCell.setAttribute('style','width:40px');
			  checkBoxCell.setAttribute('id', 'td_CheckBox'+rowCount);
			  checkBoxCell.innerHTML = '<input type="checkbox" id = "checkBox'+rowCount+'" onchange="onCheckSingleItem(this);" name="dynamicCheckBox" style="margin-top: 8px;width: 43px;height: 20px;border-radius: 1px;"></input>'
		      newRow.appendChild(checkBoxCell);
			  
		  // add inputputBox :: property to row
          var propertyCell = document.createElement('td');
			  propertyCell.setAttribute('style','width:200px');
			  propertyCell.setAttribute('id', 'td_propertyCell'+rowCount);
			  propertyCell.innerHTML = '<input id = "inputPropertyCell'+rowCount+'" type = "text" placeholder="Enter Property" style="margin-bottom: 5px;margin-left: 5px;background: #313131;padding: 10px;width: 200px;border-radius: 4px;height: 30px;border-right: none;border-bottom: none;color: white;"></input>'
			  newRow.appendChild(propertyCell);
			  
          // add inputputBox :: Value to row
          var valueCell = document.createElement('td');
			  valueCell.setAttribute('style','width:200px');
			  valueCell.setAttribute('id', 'td_valueCell'+rowCount);
			  valueCell.innerHTML = '<input id = "inputValueCell'+rowCount+'" type = "text" placeholder="Enter Value" style="margin-bottom: 5px;margin-left: 5px;background: #313131;padding: 10px;width: 200px;border-radius: 4px;height: 30px;border-right: none;border-bottom: none;color: white;"></input>'
			  newRow.appendChild(valueCell);
			  
		  // add row to the parentNode
          document.getElementById('content').appendChild(newRow);
         }
         
         function onClickFinish() {
            var connString = '';
            var finalObj = {};
            var optionCheck = true;
            // get General config values
            var db = document.getElementById("locationName").value;
            var host = document.getElementById("host").value;
            var port = document.getElementById("port").value;
            var userId = document.getElementById("userId").value;
            var password = document.getElementById("password").value;
            connString = 'DATABASE=' + db + ';HOSTNAME=' + host + ';UID=' + userId + ';PWD=' + password + ';PORT=' + port;
            var sslcheckbox = document.getElementById("sslbtn")
            if (sslcheckbox.checked) {
               connString = connString + ';SECURITY=SSL'
            }
            var sslcert = document.getElementById("sslfile").value;
            if (sslcert) {
               connString = connString + ';SSLSERVERCERTIFICATE=' + sslcert
            }
            // get optional config values
            var tableRows = document.getElementById('content');
            var totalRows = tableRows.rows.length;
            for (i = 1; i < totalRows; i++){
               var inputs = tableRows.rows.item(i).getElementsByTagName("input");
               if (inputs[1].value != "" && inputs[2].value != ""){
                  connString = connString + ";" + inputs[1].value + "=" + inputs[2].value;
               } else {
                optionCheck = false;
               }
            }
            if (optionCheck == true) {
              vscodeApi.postMessage({
                connString: connString
             })
            } else {
              vscodeApi.postMessage({
                optionFill: "Please fill all the values in optional ODBC properties"
             })
            }
         }
         
         function removeElement() {
         var table = document.getElementById('content');
         var checkboxes = document.getElementsByName('dynamicCheckBox');
         var removeButton = document.getElementById("removeBtn");
         var addButton = document.getElementById("addBtn");
         var selectAllCheckBox = document.getElementById('selectAllCheckBox');
		 document.getElementById('clearBtn').style.display = "none";
         var uncheckedCounter = 0;
         
		 // Iterate dynamically created checkBoxes
         for (var i = checkboxes.length - 1; i >= 0; i--){
			if(checkboxes[i].checked){
         		// find the parent of the checkbox
         		var rowElement = document.getElementById(checkboxes[i].id).parentNode.parentNode;
         		// delete entire row
         		rowElement.parentNode.removeChild(rowElement);
         	}
         	else{
         		uncheckedCounter++;
         	}
         }

         // get checkboxes after deleting the selected
         var checkboxes = document.getElementsByName('dynamicCheckBox');
		 
		 // render add or remove buttons based on conditions
         if(checkboxes.length == 0 || uncheckedCounter>0){
         	removeButton.style.display = "none";
         	addButton.style.display = "block";
         }
         
         if(checkboxes.length == 0){
         	selectAllCheckBox.style.display = "none";
         }
         if(uncheckedCounter>0){
         	// uncheck selectAll checkbox
         	selectAllCheckBox.style.display = "block";
         	selectAllCheckBox.checked = false;
         }
         }
         
         function clearElements(){
		 var checkboxes = document.getElementsByName('dynamicCheckBox');
         document.getElementById("removeBtn").style.display = "none";
         document.getElementById("addBtn").style.display = "block";
		 document.getElementById('selectAllCheckBox').checked = false;
		 document.getElementById('clearBtn').style.display = "none"
		 for(var i=0;i<checkboxes.length;i++) {
           if(checkboxes[i].checked){
				checkboxes[i].checked = false;
			 }}
		 }
		 
         function onCheckAll(checkBoxInfo) {
         // TODO: Code refactor
         var removeButton = document.getElementById("removeBtn");
         var addButton = document.getElementById("addBtn");
         var checkboxes = document.getElementsByName('dynamicCheckBox');
		 var clearButton = document.getElementById('clearBtn')
		 clearButton.style.display = "block";
         
         // get check boxes
         if(checkboxes.length == 0){
			checkBoxInfo.checked = false;
			return;
         }
		 
         // select all the check boxes
         for(var i=0; i<checkboxes.length;i++) {
			checkboxes[i].checked = checkBoxInfo.checked;
         }
         
         if(!checkBoxInfo.checked){
			// display add button
			removeButton.style.display = "none";
            addButton.style.display = "block";
			document.getElementById('clearBtn').style.display = "none"
         }
         else{
			// display remove button
			removeButton.style.display = "block";
			addButton.style.display = "none";
         }
         }
         function sslChange(){
          var sslfile = document.getElementById('sslfile');
          if (sslfile.disabled) {
             sslfile.disabled = false
          } else {
             sslfile.disabled = true
          }
       }
         
         function onCheckSingleItem(checkBoxInfo) {
         var checkboxes = document.getElementsByName('dynamicCheckBox');
         var removeButton = document.getElementById("removeBtn");
         var addButton = document.getElementById("addBtn");
		 var selectAllCheckBox = document.getElementById('selectAllCheckBox');
		 var clearButton = document.getElementById('clearBtn');
		 var selectedCheckBoxCounter = 0;

         // render add and remove buttons based on conditions 
         for(var i=0;i<checkboxes.length;i++) {
           if(checkboxes[i].checked){
				removeButton.style.display = "block";
				addButton.style.display = "none";
				selectAllCheckBox.checked = false;
				selectedCheckBoxCounter++;
			}
         }

         if(checkBoxInfo.checked){
          clearButton.style.display="block"
         }
		 	
			if(selectedCheckBoxCounter == 0){
				removeButton.style.display = "none";
				addButton.style.display = "block";
				selectAllCheckBox.checked = false;
        clearButton.style.display="none"
			}
			
		 
			if(selectedCheckBoxCounter == checkboxes.length){
				selectAllCheckBox.checked = true;
				removeButton.style.display = "block";
				addButton.style.display = "none";
		 }
         }
         
         function openTabs(evt, cityName) {
           var i, tabcontent, tablinks;
           tabcontent = document.getElementsByClassName("tabcontent");
           for (i = 0; i < tabcontent.length; i++) {
             tabcontent[i].style.display = "none";
           }
           tablinks = document.getElementsByClassName("tablinks");
           for (i = 0; i < tablinks.length; i++) {
             tablinks[i].className = tablinks[i].className.replace(" active", "");
           }
           document.getElementById(cityName).style.display = "block";
           evt.currentTarget.className += " active";
         }
         
         window.onload = function() {
          document.getElementById('optionalDiv').style.display = 'none';
         };
         
      </script>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <style>
         * {box-sizing: border-box}
         body {font-family: "Lato", sans-serif;}
         /* Style the tab */
         .tab {
         float: left;
         border: 1px solid #ccc;
         background-color: black;
         width: 20%;
         height: 410px;
         border: none;
         }
         ::-webkit-scrollbar {
         width: 0px;
         background: transparent; /* make scrollbar transparent */
         }
         /* Style the buttons inside the tab */
         .tab button {
         display: block;
         background-color: inherit;
         padding: 14px 8px;
         width: 100%;
         border: none;
         outline: none;
         text-align: left;
         cursor: pointer;
         transition: 0.3s;
         font-size: 17px;
         color: white;
         }
         /* Change background color of buttons on hover */
         .tab button:hover {
         background-color: #313131;
         }
         /* Create an active/current "tab button" class */
         .tab button.active {
         background-color: #313131;
         }
         /* Style the tab content */
         .tabcontent {
         float: left;
         padding: 0px 12px;
         border: 1px solid #ccc;
         width: 80%;
         border-left: none;
         height: 410px;
         }
         .label {
         color: white;
         font-family: monospace;
         }
         .inputBox {
         width: 500px;
         height: 37px;
         background: #313131;
         border:0px;
         color: white;
         }
         .fontColor {
         color: white;
         }
         .finishButton {
         margin-top: 20px;
         width: 100px;
         height: 40px;
         background: gray;
         color: white;
         font-family: monospace;
         border: none;
         border-radius: 5px;
         }
         .finishButton:hover {
         margin-top: 20px;
         width: 100px;
         height: 40px;
         background: #313131;
         color: white;
         font-family: monospace;
         border: none;
         border-radius: 5px;
         }
		 .disablefinishButton{
		     margin-top: 20px;
         width: 100px;
         height: 40px;
         background: #948d8d6e;
		     color: #ffffff6b;
         font-family: monospace;
         border: none;
         border-radius: 5px;   
		  }
         .sideNavButton {
         color: white;
         }
         .sideNavButton:hover {
         color: white;
         background: #313131;
         }
         .addButton {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #5555e6;
         font-weight: bold;
         color: white;
         font-family: monospace;
         margin-right: 5px;
         }
         .addButton:hover {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #a7a7ea;
         font-weight: bold;
         color: Black;
         font-family: monospace;
         margin-right: 5px;
         }
         .removeButton {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #3385ff;
         font-weight: bold;
         color: white;
         font-family: monospace;
         margin-right: 5px;
         display: none;
         }
         .removeButton:hover {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #80b3ff;
         font-weight: bold;
         color: Black;
         font-family: monospace;
         margin-right: 5px;
         }
		 .clearButton {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #3385ff;
         font-weight: bold;
         color: white;
         font-family: monospace;
         margin-right: 5px;
         display: none;
         }
         .clearButton:hover {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #80b3ff;
         font-weight: bold;
         color: Black;
         font-family: monospace;
         margin-right: 5px;
         }
         .checkbox {
         margin-top: 8px;
         width: 43px;
         height: 20px;
         border-radius: 1px;
         display: none; }
		 
		 .inputError {
		 border-color: #ec8383;
		 width: 500px;
         height: 37px;
         background: #313131;
         color: white;
		 }
      </style>
   </head>
   <body style="background: black; border: none; margin-top: 15px;">
      <div class="tab">
         <button class="tablinks" onclick="openTabs(event, 'generalDiv')" id="defaultOpen">General</button>
         <button class="tablinks" onclick="openTabs(event, 'optionalDiv')">Optional</button>
      </div>
      <div id="generalDiv" class="tabcontent" style="overflow:auto; border: none">
         <h4 class = "label" >
         Database Name</h3>
         <input type="text" id="locationName" name="locationName" style="" class= "inputBox" onkeyup="validateFields();" placeholder="Enter Database Name">
         <h4 class = "label" >
         Host</h3>
         <input type="text" id="host" name="Host" style="" class= "inputBox"  onkeyup="validateFields();"  placeholder="Enter Hostname or IP address">
         <h4 class = "label" >
         Port</h3>
		 <input type="text" id="port" name="port" style="" class= "inputBox" onkeyup="validateFields();"  placeholder="Enter Port Number">
       <h4 class = "label" >
         UserID</h3>
         <input type="text" id="userId" name="UserId" style="" class= "inputBox"  onkeyup="validateFields();"  placeholder="Enter UserID">
         <h4 class = "label" >
         Password</h3>
         <input type="password" id="password" name="Password" style="margin-bottom: 20px;" class= "inputBox"  onkeyup="validateFields();"  placeholder="Enter Password">
         <i class="far fa-eye" id="togglePassword" style="color: white;"></i>
         <br>
         <input type="checkbox" id="sslbtn" name="ssl" value="ssl" onclick="sslChange()" style="margin-left: 0px">
         <label for="ssl" class="label"> Enable SSL Security</label>
         <br>
         <input type="text" id="sslfile" name="sslfile" style="" class= "inputBox" disabled="true" placeholder="Enter Full Path Of SSL Server Certificate">
         <br>
      </div>
      <div id="optionalDiv" class="tabcontent" style="overflow:auto; border: none">
         <p style="color:white;">Optional ODBC properties</p>
         <div style="display: flex;flex-direction: row-reverse;align-items: center;background: #545252fa; height: 40px;">
            <button class="addButton" id="addBtn" onclick="addElement();">Add</button>
            <button class="removeButton" id="removeBtn" onclick="removeElement(this);">Remove</button>
			<button class="clearButton" id="clearBtn" onclick="clearElements(this);">Clear</button>
         </div>
         <div>
            <table style="width: 100%;background: gray;">
         </div>
         <tbody id="content">
         <tr>
         <td style="width:40px"> <input type="checkbox" id = "selectAllCheckBox" class="checkbox" name="selectAllCheckBox" onchange="onCheckAll(this);"></input> </td>
         <td style="width:200px;padding: 10px;"> <label style="color:white"> Property </label></td>
         <td style="width:200px;padding: 10px;"> <label style="color:white"> Value </label></td>
         </tr>
         </tbody>
         </table>
      </div>
      </div>
      <div>
         <button class="disablefinishButton" disabled="disabled" style="margin-left: 21.5%;" type="submit" id="Finish" name="Finish" onclick="onClickFinish()">
         Connect</button>
         <br>
         <br>
      </div>
      <script>
         //var togglePassword = document.querySelector('#togglePassword');
         var password = document.querySelector('#password');
         togglePassword.addEventListener('click', function (e) {
            // toggle the type attribute
            const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
            password.setAttribute('type', type);
            // toggle the eye slash icon
            this.classList.toggle('fa-eye-slash');
         });
      </script>
   </body>
</html>
  `;
}

function getProfileFormContent() {
  return`
  <!DOCTYPE html>
<html>
   <head>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
      <script>
         const vscodeApi = acquireVsCodeApi();
         var rowCount = 1;
         var profileUser = false;
		 
		 function validateFields(inputBoxInfo){
		    var locationName = document.getElementById("locationName");
        var host = document.getElementById("host");
        var port = document.getElementById("port");
        var userId = document.getElementById("userId");
        var password = document.getElementById("password");
		    var finishButton = document.getElementById("Finish");
        var profileValue = document.getElementById("profile").value
        if(inputBoxInfo.id == "profile"){
          profileUser = true
        }

        if (!profileValue) {
          profileUser = false 
        }

		    if(inputBoxInfo.id !== "profile" && !profileUser){
          if (locationName.value && userId.value) {
            document.getElementById("profile").value = locationName.value+"-"+userId.value;
          } else if (userId.value){
            document.getElementById("profile").value = userId.value;
          } else if (locationName.value){
            document.getElementById("profile").value = locationName.value;
          }
        }
		
        if(locationName.value && port.value && host.value && userId.value && password.value){
          finishButton.className = "finishButton";
          finishButton.disabled = false;
          return;
        }
        finishButton.className = "disablefinishButton";
        finishButton.disabled = true;
        return;
		  }
		 
      function addElement() {
        rowCount++;
		    document.getElementById('clearBtn').style.display = "none";
		    var checkBoxCounter = 0;
		    // validate "selectAllCheckBox" checkBox conditions to render 
        var selectAllCheckBox = document.getElementById('selectAllCheckBox');
			  selectAllCheckBox.style.display = "block";
			
        if(selectAllCheckBox.checked){
          selectAllCheckBox.checked = false;
        }
			
        // create row
        var newRow = document.createElement('tr');
        newRow.setAttribute('id', 'row'+rowCount);
			  
		  // add checkBox to row
          var checkBoxCell = document.createElement('td');
			  checkBoxCell.setAttribute('style','width:40px');
			  checkBoxCell.setAttribute('id', 'td_CheckBox'+rowCount);
			  checkBoxCell.innerHTML = '<input type="checkbox" id = "checkBox'+rowCount+'" onchange="onCheckSingleItem(this);" name="dynamicCheckBox" style="margin-top: 8px;width: 43px;height: 20px;border-radius: 1px;"></input>'
		      newRow.appendChild(checkBoxCell);
			  
		  // add inputputBox :: property to row
          var propertyCell = document.createElement('td');
			  propertyCell.setAttribute('style','width:200px');
			  propertyCell.setAttribute('id', 'td_propertyCell'+rowCount);
			  propertyCell.innerHTML = '<input id = "inputPropertyCell'+rowCount+'" type = "text" placeholder="Enter Property" style="margin-bottom: 5px;margin-left: 5px;background: #313131;padding: 10px;width: 200px;border-radius: 4px;height: 30px;border-right: none;border-bottom: none;color: white;"></input>'
			  newRow.appendChild(propertyCell);
			  
          // add inputputBox :: Value to row
          var valueCell = document.createElement('td');
			  valueCell.setAttribute('style','width:200px');
			  valueCell.setAttribute('id', 'td_valueCell'+rowCount);
			  valueCell.innerHTML = '<input id = "inputValueCell'+rowCount+'" type = "text" placeholder="Enter Value" style="margin-bottom: 5px;margin-left: 5px;background: #313131;padding: 10px;width: 200px;border-radius: 4px;height: 30px;border-right: none;border-bottom: none;color: white;"></input>'
			  newRow.appendChild(valueCell);
			  
		  // add row to the parentNode
          document.getElementById('content').appendChild(newRow);
         }
         
         function sslChange(){
          var sslfile = document.getElementById('sslfile');
          if (sslfile.disabled) {
             sslfile.disabled = false
          } else {
             sslfile.disabled = true
          }
       }

         function onClickFinish() {
		      var profile = {};
          var optionCheck = true;
         // get General config values
         var locationName = document.getElementById("locationName").value;
         var host = document.getElementById("host").value;
         var port = document.getElementById("port").value;
         var userId = document.getElementById("userId").value;
         var password = document.getElementById("password").value;
        var profile_name = document.getElementById("profile").value;
        profile["Database"]=document.getElementById("locationName").value;
        profile["Hostname"]=document.getElementById("host").value;
        profile["Port"]=document.getElementById("port").value;
        profile["User"]=document.getElementById("userId").value;
        profile["Password"]=document.getElementById("password").value;
        if(!profile_name){
          document.getElementById("profile").value = locationName+host+port;
        }
         profile["Name"]=document.getElementById("profile").value;
        var sslcheckbox = document.getElementById("sslbtn")
        if (sslcheckbox.checked) {
           profile["SECURITY"]="SSL"
        }
        var sslcert = document.getElementById("sslfile").value;
        if (sslcert) {
           profile["SSLSERVERCERTIFICATE"] = sslcert
        }
		 
         // get optional config values
         var tableRows = document.getElementById('content');
         var totalRows = tableRows.rows.length;
         for (i = 1; i < totalRows; i++){
            var inputs = tableRows.rows.item(i).getElementsByTagName("input");
            if (inputs[1].value != "" && inputs[2].value != ""){
              if(profile["Others"]) {
                  profile["Others"] = profile["Others"] + ";" + inputs[1].value + "=" + inputs[2].value; 
              } else {
                  profile["Others"] = inputs[1].value + "=" + inputs[2].value; 
              }
            } else {
              optionCheck = false;
            }
         }
          if (locationName && host && port && userId && password){
            if (optionCheck) {
              vscodeApi.postMessage({
                profile: profile
              })
            } else {
              vscodeApi.postMessage({
                optionFill: "Please fill all the values in optional ODBC properties"
              })
            }
          }
			    profile={}
        }
         
         function removeElement() {
         var table = document.getElementById('content');
         var checkboxes = document.getElementsByName('dynamicCheckBox');
         var removeButton = document.getElementById("removeBtn");
         var addButton = document.getElementById("addBtn");
         var selectAllCheckBox = document.getElementById('selectAllCheckBox');
		 document.getElementById('clearBtn').style.display = "none";
         var uncheckedCounter = 0;
         
		 // Iterate dynamically created checkBoxes
         for (var i = checkboxes.length - 1; i >= 0; i--){
			if(checkboxes[i].checked){
         		// find the parent of the checkbox
         		var rowElement = document.getElementById(checkboxes[i].id).parentNode.parentNode;
         		// delete entire row
         		rowElement.parentNode.removeChild(rowElement);
         	}
         	else{
         		uncheckedCounter++;
         	}
         }

         // get checkboxes after deleting the selected
         var checkboxes = document.getElementsByName('dynamicCheckBox');
		 
		 // render add or remove buttons based on conditions
         if(checkboxes.length == 0 || uncheckedCounter>0){
         	removeButton.style.display = "none";
         	addButton.style.display = "block";
         }
         
         if(checkboxes.length == 0){
         	selectAllCheckBox.style.display = "none";
         }
         if(uncheckedCounter>0){
         	// uncheck selectAll checkbox
         	selectAllCheckBox.style.display = "block";
         	selectAllCheckBox.checked = false;
         }
         }
         
         function clearElements(){
		 var checkboxes = document.getElementsByName('dynamicCheckBox');
         document.getElementById("removeBtn").style.display = "none";
         document.getElementById("addBtn").style.display = "block";
		 document.getElementById('selectAllCheckBox').checked = false;
		 document.getElementById('clearBtn').style.display = "none"
		 for(var i=0;i<checkboxes.length;i++) {
           if(checkboxes[i].checked){
				checkboxes[i].checked = false;
			 }}
		 }
		 
         function onCheckAll(checkBoxInfo) {
         // TODO: Code refactor
         var removeButton = document.getElementById("removeBtn");
         var addButton = document.getElementById("addBtn");
         var checkboxes = document.getElementsByName('dynamicCheckBox');
		 var clearButton = document.getElementById('clearBtn')
		 clearButton.style.display = "block";
         
         // get check boxes
         if(checkboxes.length == 0){
			checkBoxInfo.checked = false;
			return;
         }
		 
         // select all the check boxes
         for(var i=0; i<checkboxes.length;i++) {
			checkboxes[i].checked = checkBoxInfo.checked;
         }
         
         if(!checkBoxInfo.checked){
			// display add button
			removeButton.style.display = "none";
            addButton.style.display = "block";
			document.getElementById('clearBtn').style.display = "none"
         }
         else{
			// display remove button
			removeButton.style.display = "block";
			addButton.style.display = "none";
         }
         }
         
         function onCheckSingleItem(checkBoxInfo) {
         var checkboxes = document.getElementsByName('dynamicCheckBox');
         var removeButton = document.getElementById("removeBtn");
         var addButton = document.getElementById("addBtn");
		 var selectAllCheckBox = document.getElementById('selectAllCheckBox');
		 var clearButton = document.getElementById('clearBtn');
		 var selectedCheckBoxCounter = 0;

         // render add and remove buttons based on conditions 
         for(var i=0;i<checkboxes.length;i++) {
           if(checkboxes[i].checked){
				removeButton.style.display = "block";
				addButton.style.display = "none";
				selectAllCheckBox.checked = false;
				selectedCheckBoxCounter++;
			}
         }

         if(checkBoxInfo.checked){
          clearButton.style.display="block"
          }
		 	
			if(selectedCheckBoxCounter == 0){
				removeButton.style.display = "none";
				addButton.style.display = "block";
				selectAllCheckBox.checked = false;
        clearButton.style.display="none"
			}
			
		 
			if(selectedCheckBoxCounter == checkboxes.length){
				selectAllCheckBox.checked = true;
				removeButton.style.display = "block";
				addButton.style.display = "none";
		 }
         }
         
         function openTabs(evt, cityName) {
           var i, tabcontent, tablinks;
           tabcontent = document.getElementsByClassName("tabcontent");
           for (i = 0; i < tabcontent.length; i++) {
             tabcontent[i].style.display = "none";
           }
           tablinks = document.getElementsByClassName("tablinks");
           for (i = 0; i < tablinks.length; i++) {
             tablinks[i].className = tablinks[i].className.replace(" active", "");
           }
           document.getElementById(cityName).style.display = "block";
           evt.currentTarget.className += " active";
        }
            window.onload = function() {
            document.getElementById('optionalDiv').style.display = 'none';
            };
         
      </script>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <style>
         * {box-sizing: border-box}
         body {font-family: "Lato", sans-serif;}
         /* Style the tab */
         .tab {
         float: left;
         border: 1px solid #ccc;
         background-color: black;
         width: 20%;
         height: 410px;
         border: none;
         }
         ::-webkit-scrollbar {
         width: 0px;
         background: transparent; /* make scrollbar transparent */
         }
         /* Style the buttons inside the tab */
         .tab button {
         display: block;
         background-color: inherit;
         padding: 14px 8px;
         width: 100%;
         border: none;
         outline: none;
         text-align: left;
         cursor: pointer;
         transition: 0.3s;
         font-size: 17px;
         color: white;
         }
         /* Change background color of buttons on hover */
         .tab button:hover {
         background-color: #313131;
         }
         /* Create an active/current "tab button" class */
         .tab button.active {
         background-color: #313131;
         }
         /* Style the tab content */
         .tabcontent {
         float: left;
         padding: 0px 12px;
         border: 1px solid #ccc;
         width: 80%;
         border-left: none;
         height: 410px;
         }
         .label {
         color: white;
         font-family: monospace;
         }
         .inputBox {
         width: 500px;
         height: 37px;
         background: #313131;
         border:0px;
         color: white;
         }
         .fontColor {
         color: white;
         }
         .finishButton {
         margin-top: 20px;
         width: 100px;
         height: 40px;
         background: gray;
         color: white;
         font-family: monospace;
         border: none;
         border-radius: 5px;
         }
         .finishButton:hover {
         margin-top: 20px;
         width: 100px;
         height: 40px;
         background: #313131;
         color: white;
         font-family: monospace;
         border: none;
         border-radius: 5px;
         }
		 .disablefinishButton{
		 margin-top: 20px;
         width: 100px;
         height: 40px;
         background: #948d8d6e;
		 color: #ffffff6b;
         font-family: monospace;
         border: none;
         border-radius: 5px;   
		}
         .sideNavButton {
         color: white;
         }
         .sideNavButton:hover {
         color: white;
         background: #313131;
         }
         .addButton {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #5555e6;
         font-weight: bold;
         color: white;
         font-family: monospace;
         margin-right: 5px;
         }
         .addButton:hover {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #a7a7ea;
         font-weight: bold;
         color: Black;
         font-family: monospace;
         margin-right: 5px;
         }
         .removeButton {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #3385ff;
         font-weight: bold;
         color: white;
         font-family: monospace;
         margin-right: 5px;
         display: none;
         }
         .removeButton:hover {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #80b3ff;
         font-weight: bold;
         color: Black;
         font-family: monospace;
         margin-right: 5px;
         }
		 .clearButton {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #3385ff;
         font-weight: bold;
         color: white;
         font-family: monospace;
         margin-right: 5px;
         display: none;
         }
         .clearButton:hover {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #80b3ff;
         font-weight: bold;
         color: black;
         font-family: monospace;
         margin-right: 5px;
         }
         .checkbox {
         margin-top: 8px;
         width: 43px;
         height: 20px;
         border-radius: 1px;
         display: none; }
		 
		 .inputError {
		 border-color: #ec8383;
		 width: 500px;
         height: 37px;
         background: #313131;
         color: white;
		 }
      </style>
   </head>
   <body style="background: black; border: none; margin-top: 15px;">
      <div class="tab">
         <button class="tablinks" onclick="openTabs(event, 'generalDiv')" id="defaultOpen">General</button>
         <button class="tablinks" onclick="openTabs(event, 'optionalDiv')">Optional</button>
      </div>
      <div id="generalDiv" class="tabcontent" style="overflow:auto; border: none">
        <h4 class = "label" >
        Profile(optional)</h3>
        <input type="text" id="profile" name="profile" style="" class= "inputBox" onkeyup="validateFields(this);"  placeholder="Default : DatabaseName + UserID">
         <h4 class = "label" >
         Database Name</h3>
         <input type="text" id="locationName" name="locationName" style="" class= "inputBox" onkeyup="validateFields(this);" placeholder="Enter Database Name">
         <h4 class = "label" >
         Host</h3>
         <input type="text" id="host" name="Host" style="" class= "inputBox"  onkeyup="validateFields(this);"  placeholder="Enter Hostname or IP address">
         <h4 class = "label" >
         Port</h3>
		 <input type="text" id="port" name="port" style="" class= "inputBox" onkeyup="validateFields(this);"  placeholder="Enter Port Number">
         <h4 class = "label" >
         UserID</h3>
         <input type="text" id="userId" name="UserId" style="" class= "inputBox"  onkeyup="validateFields(this);"  placeholder="Enter UserID">
         <h4 class = "label" >
         Password</h3>
         <input type="password" id="password" name="Password" style="margin-bottom: 20px;" class= "inputBox"  onkeyup="validateFields(this);"  placeholder="Enter Password">
         <i class="far fa-eye" id="togglePassword" style="color: white;"></i>
         <br>
         <input type="checkbox" id="sslbtn" name="ssl" value="ssl" onclick="sslChange()" style="margin-left: 0px">
         <label for="ssl" class="label"> Enable SSL Security </label>
         <br>
         <input type="text" id="sslfile" name="sslfile" style="" class= "inputBox" disabled="true" placeholder="Enter Full Path Of SSL Server Certificate">
         <br>
      </div>
      <div id="optionalDiv" class="tabcontent" style="overflow:auto; border: none">
         <p style="color:white;">Optional ODBC properties</p>
         <div style="display: flex;flex-direction: row-reverse;align-items: center;background: #545252fa; height: 40px;">
            <button class="addButton" id="addBtn" onclick="addElement();">Add</button>
            <button class="removeButton" id="removeBtn" onclick="removeElement(this);">Remove</button>
			<button class="clearButton" id="clearBtn" onclick="clearElements(this);">Clear</button>
         </div>
         <div>
            <table style="width: 100%;background: gray;">
         </div>
         <tbody id="content">
         <tr>
         <td style="width:40px"> <input type="checkbox" id = "selectAllCheckBox" class="checkbox" name="selectAllCheckBox" onchange="onCheckAll(this);"></input> </td>
         <td style="width:200px;padding: 10px;"> <label style="color:white"> Property </label></td>
         <td style="width:200px;padding: 10px;"> <label style="color:white"> Value </label></td>
         </tr>
         </tbody>
         </table>
      </div>
      </div>
      <div style="margin-left: 21.5%">
         <button class="disablefinishButton" disabled="disabled" type="submit" id="Finish" name="Finish" onclick="onClickFinish()"> Save & Close </button>
         <br>
         <br>
      </div>
      <script>
        //var togglePassword = document.querySelector('#togglePassword');
        var password = document.querySelector('#password');
        togglePassword.addEventListener('click', function (e) {
           // toggle the type attribute
           const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
           password.setAttribute('type', type);
           // toggle the eye slash icon
           this.classList.toggle('fa-eye-slash');
        });
     </script>
   </body>
</html>
  `;
}

function getEditProfFormConetent(profile_json){
  return `
  <!DOCTYPE html>
<html>
   <head>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.13.0/css/all.min.css">
      <script type = "text/javascript"
      src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js">
    </script>

  <script type = "text/javascript">
      const vscodeApi = acquireVsCodeApi();
	    var rowCount = 1;
	    const validGeneralConfigParams = ["Database","Hostname","Port","User","Password","Name","SECURITY","SSLSERVERCERTIFICATE"]
	  	const sampleProfiles = ${profile_json}
         window.onload = function addDropDownItems(dropDownInfo){
		 document.getElementById('optionalDiv').style.display = 'none';
			const objKeys = Object.keys(sampleProfiles)
				// @Ravuri: do ap-call to fetch profiles list here
			var selectTag = document.createElement("select");
				selectTag.className= "selectBox"
				selectTag.id = "selectBox";
				selectTag.onchange = function(){ selectOption(this);};
		 
		 var defaultOption = document.createElement("option");
			defaultOption.text = "Select Profile";
			defaultOption.value = "Select Profile";
			selectTag.add(defaultOption);

		for(var i=0; i<objKeys.length;i++){
			let option = document.createElement("option");
				option.text = objKeys[i]
				option.value = objKeys[i]
				selectTag.add(option);
		 }
		
		var div = document.getElementById("dropDownDiv");
			div.appendChild(selectTag);
		}
		
		function deleteProfile(){
			clearOptionalValues();
			var selectedValue = document.getElementById("selectBox");
			var delProfile = selectedValue.options[selectedValue.selectedIndex].value;
			if (delProfile == "Select Profile"){
        return;
      } else {
        selectedValue.removeChild(selectedValue.childNodes[selectedValue.selectedIndex]);
      }      
      vscodeApi.postMessage({
        profileDelete: delProfile
      })
      var updateAndCloseButton = document.getElementById("updateAndCancelButtons");
      updateAndCloseButton.className = "disableupdateAndCancelButtons";
      updateAndCloseButton.disabled = true;
      document.getElementById("selectBox").value = "Select Profile";
			// get the updated profiles and call this function
			document.getElementById("locationName").value = "";
			document.getElementById("host").value =  "";
			document.getElementById("port").value =  "";
			document.getElementById("userId").value =  "";
			document.getElementById("password").value =  "";
			document.getElementById("profile").value =  "";
      document.getElementById("sslfile").value = "";
      document.getElementById("sslbtn").checked = false;
      document.getElementById("sslfile").disabled = true;
		}
		
		function selectOption(optionInfo){
		// @Ravuri profileName:: optionInfo.value
		// fetch api with profileName(optionInfo.value) or check from initial array
		// Check all the existing child node under content table and delete those
		let clearAll = false;
		clearOptionalValues();
       var finishButton = document.getElementById("updateAndCancelButtons");
		   
		
		if(optionInfo.value == "Select Profile"){
			clearAll = true;
      finishButton.className = "disableupdateAndCancelButtons";	
			finishButton.disabled = true;

		} 
		else{ 
			finishButton.disabled = false;
      finishButton.className = "updateAndCancelButtons";	
			// get porfile Info from Array :: validate with validGeneralConfigParams
			var sampleProfile = sampleProfiles[optionInfo.value];
			var OptionalValues = Object.keys(sampleProfile).filter(p => validGeneralConfigParams.every(e => e !== p));
		}

		document.getElementById("locationName").value = clearAll ? "" : sampleProfile.Database;
        document.getElementById("host").value = clearAll ? "" : sampleProfile.Hostname;
        document.getElementById("port").value = clearAll ? "" : sampleProfile.Port;
        document.getElementById("userId").value = clearAll ? "" : sampleProfile.User;
        document.getElementById("password").value = clearAll ? "" : sampleProfile.Password;
		document.getElementById("profile").value = clearAll ? "" : sampleProfile.Name;
    var sslcheckbox = document.getElementById("sslbtn")
    var sslcheck = clearAll ? "" : sampleProfile.SECURITY
      if (sslcheck) {
          sslcheckbox.checked = true
          sslfile.disabled = false
      } else {
          sslcheckbox.checked = false
          sslfile.disabled = true
          sslfile.value = ""
      }
    var sslcertValue = clearAll ? "" : sampleProfile.SSLSERVERCERTIFICATE;
    if (sslcertValue) {
      document.getElementById("sslfile").value = sslcertValue
    }
		
		// add optional parms too
		if(!clearAll){for(let i=0;i<OptionalValues.length;i++){addElement(OptionalValues[i], sampleProfile[OptionalValues[i]]);}}
		}
         
         function openTabs(evt, cityName) {
           var i, tabcontent, tablinks;
           tabcontent = document.getElementsByClassName("tabcontent");
           for (i = 0; i < tabcontent.length; i++) {
             tabcontent[i].style.display = "none";
           }
           tablinks = document.getElementsByClassName("tablinks");
           for (i = 0; i < tablinks.length; i++) {
             tablinks[i].className = tablinks[i].className.replace(" active", "");
           }
           document.getElementById(cityName).style.display = "block";
           evt.currentTarget.className += " active";
        }
			
		function changeProfile(){
			var locationName = document.getElementById("locationName").value;
			var userId = document.getElementById("userId").value;
			document.getElementById("profile").value = locationName+userId;
			
			}
        
		function removeElement() {
         var table = document.getElementById('content');
         var checkboxes = document.getElementsByName('dynamicCheckBox');
         var removeButton = document.getElementById("removeBtn");
         var addButton = document.getElementById("addBtn");
         var selectAllCheckBox = document.getElementById('selectAllCheckBox');
		 document.getElementById('clearBtn').style.display = "none";
         var uncheckedCounter = 0;
         
		 // Iterate dynamically created checkBoxes
         for (var i = checkboxes.length - 1; i >= 0; i--){
			if(checkboxes[i].checked){
         		// find the parent of the checkbox
         		var rowElement = document.getElementById(checkboxes[i].id).parentNode.parentNode;
         		// delete entire row
         		rowElement.parentNode.removeChild(rowElement);
         	}
         	else{
         		uncheckedCounter++;
         	}
         }

         // get checkboxes after deleting the selected
         var checkboxes = document.getElementsByName('dynamicCheckBox');
		 
		 // render add or remove buttons based on conditions
         if(checkboxes.length == 0 || uncheckedCounter>0){
         	removeButton.style.display = "none";
         	addButton.style.display = "block";
         }
         
         if(checkboxes.length == 0){
         	selectAllCheckBox.style.display = "none";
         }
         if(uncheckedCounter>0){
         	// uncheck selectAll checkbox
         	selectAllCheckBox.style.display = "block";
         	selectAllCheckBox.checked = false;
         }
         }
         
         function clearElements(){
		 var checkboxes = document.getElementsByName('dynamicCheckBox');
         document.getElementById("removeBtn").style.display = "none";
         document.getElementById("addBtn").style.display = "block";
		 document.getElementById('selectAllCheckBox').checked = false;
		 document.getElementById('clearBtn').style.display = "none"
		 for(var i=0;i<checkboxes.length;i++) {
           if(checkboxes[i].checked){
				checkboxes[i].checked = false;
			 }}
		 }
		 
         function onCheckAll(checkBoxInfo) {
         // TODO: Code refactor
         var removeButton = document.getElementById("removeBtn");
         var addButton = document.getElementById("addBtn");
         var checkboxes = document.getElementsByName('dynamicCheckBox');
		 var clearButton = document.getElementById('clearBtn')
		 clearButton.style.display = "block";
         
         // get check boxes
         if(checkboxes.length == 0){
			checkBoxInfo.checked = false;
			return;
         }
		 
         // select all the check boxes
         for(var i=0; i<checkboxes.length;i++) {
			checkboxes[i].checked = checkBoxInfo.checked;
         }
         
         if(!checkBoxInfo.checked){
			// display add button
			removeButton.style.display = "none";
            addButton.style.display = "block";
			document.getElementById('clearBtn').style.display = "none"
         }
         else{
			// display remove button
			removeButton.style.display = "block";
			addButton.style.display = "none";
         }
         }
         
         function onCheckSingleItem(checkBoxInfo) {
         var checkboxes = document.getElementsByName('dynamicCheckBox');
         var removeButton = document.getElementById("removeBtn");
         var addButton = document.getElementById("addBtn");
		 var selectAllCheckBox = document.getElementById('selectAllCheckBox');
		 var clearButton = document.getElementById('clearBtn');
		 var selectedCheckBoxCounter = 0;

         // render add and remove buttons based on conditions 
         for(var i=0;i<checkboxes.length;i++) {
           if(checkboxes[i].checked){
				removeButton.style.display = "block";
				addButton.style.display = "none";
				selectAllCheckBox.checked = false;
				selectedCheckBoxCounter++;
			}
         }

			if(checkBoxInfo.checked){
			clearButton.style.display="block"
			} 
		 	
			if(selectedCheckBoxCounter == 0){
				removeButton.style.display = "none";
				addButton.style.display = "block";
				selectAllCheckBox.checked = false;
				clearButton.style.display="none"
			}
			
		 
			if(selectedCheckBoxCounter == checkboxes.length){
				selectAllCheckBox.checked = true;
				removeButton.style.display = "block";
				addButton.style.display = "none";
		 }
         }
		 
		 function addElement(prop, value) {
          rowCount++;
		 document.getElementById('clearBtn').style.display = "none";
		 var checkBoxCounter = 0;
		 var elementValue = value ? value: "";
		 var propValue = prop ? prop: "";
		  
		  // validate "selectAllCheckBox" checkBox conditions to render 
          var selectAllCheckBox = document.getElementById('selectAllCheckBox');
			  selectAllCheckBox.style.display = "block";
			
		  if(selectAllCheckBox.checked){
			 selectAllCheckBox.checked = false;
			}
			
          // create row
          var newRow = document.createElement('tr');
			  newRow.setAttribute('id', 'row'+rowCount);
			  
		  // add checkBox to row
          var checkBoxCell = document.createElement('td');
			  checkBoxCell.setAttribute('style','width:40px');
			  checkBoxCell.setAttribute('id', 'td_CheckBox'+rowCount);
			  checkBoxCell.innerHTML = '<input type="checkbox" id = "checkBox'+rowCount+'" onchange="onCheckSingleItem(this);" name="dynamicCheckBox" style="margin-top: 8px;width: 43px;height: 20px;border-radius: 1px;"></input>'
		      newRow.appendChild(checkBoxCell);
			  
		  // add inputputBox :: property to row
          var propertyCell = document.createElement('td');
			  propertyCell.setAttribute('style','width:200px');
			  propertyCell.setAttribute('id', 'td_propertyCell'+rowCount);
			  propertyCell.innerHTML = '<input id = "inputPropertyCell'+rowCount+'" type = "text" value="'+propValue+'" placeholder="Enter Property" style="margin-bottom: 5px;margin-left: 5px;background: #313131;padding: 10px;width: 200px;border-radius: 4px;height: 30px;border-right: none;border-bottom: none;color: white;"></input>'
			  newRow.appendChild(propertyCell);
			  
          // add inputputBox :: Value to row
          var valueCell = document.createElement('td');
			  valueCell.setAttribute('style','width:200px');
			  valueCell.setAttribute('id', 'td_valueCell'+rowCount);
			  valueCell.innerHTML = '<input id = "inputValueCell'+rowCount+'" type = "text" value="'+elementValue+'"  placeholder="Enter Value" style="margin-bottom: 5px;margin-left: 5px;background: #313131;padding: 10px;width: 200px;border-radius: 4px;height: 30px;border-right: none;border-bottom: none;color: white;"></input>'
			  newRow.appendChild(valueCell);
			  
		  // add row to the parentNode
          document.getElementById('content').appendChild(newRow);
         }

        function sslChange(){
          var sslfile = document.getElementById('sslfile');
          if (sslfile.disabled) {
             sslfile.disabled = false
          } else {
             sslfile.value = ""
             sslfile.disabled = true
          }
        }
		 
		 function updateAndClose(){
		    var profile = {};
        var optionCheck = true;
        // get General config values
        var locationName = document.getElementById("locationName").value;
        var host = document.getElementById("host").value;
        var port = document.getElementById("port").value;
        var userId = document.getElementById("userId").value;
        var password = document.getElementById("password").value;
		    var profile_name = document.getElementById("profile").value;
		    profile["Database"]=document.getElementById("locationName").value;
		    profile["Hostname"]=document.getElementById("host").value;
		    profile["Port"]=document.getElementById("port").value;
		    profile["User"]=document.getElementById("userId").value;
		    profile["Password"]=document.getElementById("password").value;
		    if(!profile_name){
			    document.getElementById("profile").value = locationName+userId;
		    }
         profile["Name"]=document.getElementById("profile").value;
         var sslcheckbox = document.getElementById("sslbtn")
         if (sslcheckbox.checked) {
          profile["SECURITY"] = "SSL"
          var sslcert = document.getElementById("sslfile").value;
          if (sslcert) {
              profile["SSLSERVERCERTIFICATE"] = sslcert
          }
         }
         // get optional config values
         var tableRows = document.getElementById('content');
         var totalRows = tableRows.rows.length;
         for (i = 1; i < totalRows; i++){
            var inputs = tableRows.rows.item(i).getElementsByTagName("input");
            if (inputs[1].value != ""  && inputs[2].value != ""){
              if (inputs[1].value != "Name") {
                if(profile["Others"]) {
                  profile["Others"] = profile["Others"] + ";" + inputs[1].value + "=" + inputs[2].value; 
                } else {
                  profile["Others"] = inputs[1].value + "=" + inputs[2].value; 
                }
              }
            } else {
              optionCheck = false
            }
         }
         if (locationName && host && port && userId && password){
            if (optionCheck) {
              vscodeApi.postMessage({
                profile: profile
              })
            } else {
              vscodeApi.postMessage({
                optionFill: "Please fill all the values in optional ODBC properties"
              })
            }
         }	
			   profile={}
		 }
         
		 function validateFields(inputBoxInfo){
		    var locationName = document.getElementById("locationName");
         var host = document.getElementById("host");
         var port = document.getElementById("port");
         var userId = document.getElementById("userId");
         var password = document.getElementById("password");
		    var updateAndCloseButton = document.getElementById("updateAndCancelButtons");
        var profile = document.getElementById("profile");
		
		 if(locationName.value && port.value && host.value && userId.value && password.value && profile.value){
			updateAndCloseButton.className = "updateAndCancelButtons";
			updateAndCloseButton.disabled = false;
     return;
    }
    updateAndCloseButton.className = "disableupdateAndCancelButtons";
    updateAndCloseButton.disabled = true;
		 
		 return;
		 }
		 
		 function clearOptionalValues(){
		 	var checkboxes = document.getElementsByName('dynamicCheckBox');
			for (var i = checkboxes.length - 1; i >= 0; i--){
				var checkboxes = document.getElementsByName('dynamicCheckBox');
				// find the parent of the checkbox
				var rowElement = document.getElementById(checkboxes[i].id).parentNode.parentNode;
				// delete entire row
				rowElement.parentNode.removeChild(rowElement);
			}
		}

    function cancel(){
      vscodeApi.postMessage(null)
    }
      </script>
      <meta name="viewport" content="width=device-width, initial-scale=1">
      <style>
         * {box-sizing: border-box}
         body {font-family: "Lato", sans-serif;}
         /* Style the tab */
         .tab {
         float: left;
         border: 1px solid #ccc;
         background-color: black;
         width: 20%;
         height: 410px;
         border: none;
         }
         ::-webkit-scrollbar {
         width: 0px;
         background: transparent; /* make scrollbar transparent */
         }
         /* Style the buttons inside the tab */
         .tab button {
         display: block;
         background-color: inherit;
         padding: 14px 8px;
         width: 100%;
         border: none;
         outline: none;
         text-align: left;
         cursor: pointer;
         transition: 0.3s;
         font-size: 17px;
         color: white;
         }
         /* Change background color of buttons on hover */
         .tab button:hover {
         background-color: #313131;
         }
         /* Create an active/current "tab button" class */
         .tab button.active {
         background-color: #313131;
         }
         /* Style the tab content */
         .tabcontent {
         float: left;
         padding: 0px 12px;
         border: 1px solid #ccc;
         width: 80%;
         border-left: none;
         height: 410px;
		     margin-bottom: 2%
         }
         .label {
         color: white;
         font-family: monospace;
         }
         .inputBox {
         width: 500px;
         height: 37px;
         background: #313131;
         border:0px;
         color: white;
         }
         .fontColor {
         color: white;
         }
         .sideNavButton {
         color: white;
         }
         .sideNavButton:hover {
         color: white;
         background: #313131;
         }
         .updateAndCancelButtons{
		    background: skyblue;
			border: none;
			border-radius: 5px;
			height: 30px;
			margin-right: 2%;
		 }
		 
		.updateAndCancelButtons:hover {
			background: #0caff1;
			border: none;
			border-radius: 5px;
			height: 30px;
			margin-right: 2%;
		}
		 
		.disableupdateAndCancelButtons{
      background: #948d8d6e;
		  color: #ffffff6b;
      border: none;
		  border-radius: 5px;
		  height: 30px;
		  margin-right: 2%;   
		}
		 
		 .profileDiv {
			display: flex;
		 }
		 
		 .dropDownDiv{
			margin-right:4% 
		 }
		 
		 .removeBtn{
		    background: #fc3030;
			border: none;
			border-radius: 5px;
			height: 27px;
			margin-right: 2%;
			color: black;
		 }
		 
		 .removeBtn:hover {
		    background: #f26060;
			border: none;
			border-radius: 5px;
			height: 27px;
			margin-right: 2%;
			color: black;
		 }
		 
		 .selectBox {
		  border-radius: 4px;
		  height: 25px;
		  width: 150px;
		 }
		 
		 .addButton {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #5555e6;
         font-weight: bold;
         color: white;
         font-family: monospace;
         margin-right: 5px;
         }
         .addButton:hover {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #a7a7ea;
         font-weight: bold;
         color: Black;
         font-family: monospace;
         margin-right: 5px;
         }
         .removeButton {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #3385ff;
         font-weight: bold;
         color: white;
         font-family: monospace;
         margin-right: 5px;
         display: none;
         }
         .removeButton:hover {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #80b3ff;
         font-weight: bold;
         color: Black;
         font-family: monospace;
         margin-right: 5px;
         }
		 .clearButton {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #3385ff;
         font-weight: bold;
         color: white;
         font-family: monospace;
         margin-right: 5px;
         display: none;
         }
         .clearButton:hover {
         width: 60px;
         height: 30px;
         border-radius: 11px;
         border: none;
         background: #80b3ff;
         font-weight: bold;
         color: black;
         font-family: monospace;
         margin-right: 5px;
         }
         .checkbox {
         margin-top: 8px;
         width: 43px;
         height: 20px;
         border-radius: 1px;
         display: none; }
		 
		 .inputError {
        border-color: #ec8383;
        width: 500px;
        height: 37px;
        background: #313131;
        color: white;
		 }
		 
		 .deleteProfileBtn{
		    background: skyblue;
        border: none;
        border-radius: 5px;
        height: 27px;
        margin-right: 2%;
        color: black;
		 }
		 
		 .deleteProfileBtn:hover {
		    background: #0caff1;
        border: none;
        border-radius: 5px;
        height: 27px;
        margin-right: 2%;
        color: black;
		 }
		 
      </style>
   </head>
   <body style="background: black; border: none; margin-top: 15px;">
      <div class="tab">
         <button class="tablinks" onclick="openTabs(event, 'generalDiv')" id="defaultOpen">General</button>
         <button class="tablinks" onclick="openTabs(event, 'optionalDiv')">Optional</button>
      </div>
      <div id="generalDiv" class="tabcontent" style="overflow:auto; border: none">
	  <div class="profileDiv">
		  <div class="dropDownDiv" id="dropDownDiv"> </div>
	    <button id="deleteProfileBtn" class="deleteProfileBtn" onclick="deleteProfile(this);">Delete Profile</button>
	  </div>
        <h4 class = "label" >
        Profile(optional)</h3>
        <input type="text" id="profile" name="profile" style="" class= "inputBox" onkeyup="validateFields(this);"  placeholder="Default: Database + UserName" readonly>
         <h4 class = "label" >
         Database Name</h3>
         <input type="text" id="locationName" name="locationName" style="" class= "inputBox" onkeyup="validateFields(this);" placeholder="Enter Database Name">
         <h4 class = "label" >
         Host</h3>
         <input type="text" id="host" name="Host" style="" class= "inputBox"  onkeyup="validateFields(this);"  placeholder="Enter Hostname or IP address">
         <h4 class = "label" >
         Port</h3>
		 <input type="text" id="port" name="port" style="" class= "inputBox" onkeyup="validateFields(this);"  placeholder="Enter Port Number">
         <h4 class = "label" >
         UserID</h3>
         <input type="text" id="userId" name="UserId" style="" class= "inputBox"  onkeyup="validateFields(this);"  placeholder="Enter UserID">
         <h4 class = "label" >
         Password</h3>
         <input type="password" id="password" name="Password" style="margin-bottom: 20px;" class= "inputBox"  onkeyup="validateFields(this);"  placeholder="Enter Password">
         <i class="far fa-eye" id="togglePassword" style="color: white;"></i>
         <br>
         <input type="checkbox" id="sslbtn" name="ssl" value="ssl" onclick="sslChange()" style="margin-left: 0px">
         <label for="ssl" class="label"> Enable SSL Security</label>
         <br>
         <input type="text" id="sslfile" name="sslfile" style="" class= "inputBox" disabled="true" placeholder="Enter Full Path Of SSL Server Certificate">
         <br>
      </div>
      <div id="optionalDiv" class="tabcontent" style="overflow:auto; border: none">
         <p style="color:white;">Optional ODBC properties</p>
         <div style="display: flex;flex-direction: row-reverse;align-items: center;background: #545252fa; height: 40px;">
            <button class="addButton" id="addBtn" onclick="addElement();">Add</button>
            <button class="removeButton" id="removeBtn" onclick="removeElement(this);">Remove</button>
			<button class="clearButton" id="clearBtn" onclick="clearElements(this);">Clear</button>
         </div>
         <div>
            <table style="width: 100%;background: gray;">
         </div>
         <tbody id="content">
         <tr>
         <td style="width:40px"> <input type="checkbox" id = "selectAllCheckBox" class="checkbox" name="selectAllCheckBox" onchange="onCheckAll(this);"></input> </td>
         <td style="width:200px;padding: 10px;"> <label style="color:white"> Property </label></td>
         <td style="width:200px;padding: 10px;"> <label style="color:white"> Value </label></td>
         </tr>
         </tbody>
         </table>
      </div>
      </div>
      <div style="margin-left: 21.5%">
            <button id = "updateAndCancelButtons" disabled="disabled" class="disableupdateAndCancelButtons" onclick="updateAndClose()">Update & Close</button>
		        <button class="updateAndCancelButtons" onclick="cancel()" >Cancel</button>
         <br>
         <br>
      </div>
      <script>
        //var togglePassword = document.querySelector('#togglePassword');
        var password = document.querySelector('#password');
        togglePassword.addEventListener('click', function (e) {
           // toggle the type attribute
           const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
           password.setAttribute('type', type);
           // toggle the eye slash icon
           this.classList.toggle('fa-eye-slash');
        });
     </script>
   </body>
</html>
  `
}

function getDeleteProfFormConetent(profile_json){
  return `
  <!DOCTYPE html>
  <html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>Document</title>
  </head>
  <body>
    <h2>Profile Details</h2>

    <div id="name" class="fld">
        <label>Profile Name</label>
        <select id="profsel">
          <option value="selectcard">---please select---</option>
        </select>
        <span class="err"></span>
    </div>
    
    <button onclick="delete_profile()">
      Delete
    </button>

    <button onclick="cancel()">
      Cancel
    </button>
    
  </body>
  <script type = "text/javascript"
      src = "https://ajax.googleapis.com/ajax/libs/jquery/2.1.3/jquery.min.js">
  </script>

  <script type = "text/javascript">
    const vscodeApi = acquireVsCodeApi();

    (function() {
      //All Inputs
      document.querySelectorAll('input').forEach(e => {
        e.style = 'border-radius: 0.25em;height:20px';
      });

      //All Selects
        document.querySelectorAll('select').forEach(e => {
          e.style = 'border-radius: 0.25em;height:20px';
        });

        //All Options
        document.querySelectorAll('option').forEach(e => {
          e.style = 'border-radius: 0.25em;height:20px';
        });

      //All error spans
      document.querySelectorAll('span.err').forEach(e => {
        e.style = 'color:red';
      });

      //All individual fields
      document.querySelectorAll('.fld').forEach(e => {
        e.style = 'padding-bottom:20px';
      });

      //All buttons
      document.querySelectorAll('button').forEach(e => {
        e.style =
          'border-radius: 0.25em;background-color: darkcyan;color:white;width: 140px;height: 35px;font-weight:bold;margin:10px;';
      });
    })();

    $(document).ready(function(){
      add_profile()
    });

    function add_profile(){
      Profile_Select = document.getElementById('profsel');
      var data = ${profile_json}
      dat = Object.keys(data)
      len = dat.length
      for (i=0;i<len;i++){
        Profile_Select.options[Profile_Select.options.length] = new Option(dat[i],dat[i]);
      }
    }

    function delete_profile(){
      let vale = true;
      document.querySelectorAll('select').forEach(e => {
        e.nextElementSibling.innerText = '';
        if (e.value == "selectcard") {
          vale = false;
          e.nextElementSibling.innerText = 'This is a required field';
        } 
      });
      var sel = document.getElementById("profsel");
      var val = sel.options[sel.selectedIndex].value;
      sel.removeChild(sel.options[sel.selectedIndex]);
      if (vale){
        vscodeApi.postMessage({
          msg:val
        });
      }
      window.addEventListener('message', event => {
        const message = event.data;
        vscodeApi.postMessage({
          msg1:message
        })
      })
    }

    function cancel(){
      vscodeApi.postMessage(null)
    }
  </script>
  </html>  
  `
}

module.exports = {
  getTableContent,
  getResultContent,
  getProfileFormContent,
  getConnectFormContent,
  getEditProfFormConetent,
  getDeleteProfFormConetent
};