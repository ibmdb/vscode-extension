function sampleProf() {
  return `{
    "profile_name_here": {
        "Database": "your_database_name_here",
        "Hostname": "hostname_here",
        "Name": "profile_name_here",
        "Password": "password_here",
        "Port": "port_here_numeric",
        "User": "userid_here"
    }
}`;
}

module.exports = { sampleProf };
