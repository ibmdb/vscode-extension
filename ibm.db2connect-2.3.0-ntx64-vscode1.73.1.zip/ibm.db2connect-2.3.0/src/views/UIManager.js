const vscode = require("vscode");
const htmlContent = require("./htmlContent");
const Constants = require("../constants");
const ConnectionManager = require("../models/ConnectionManager");
const resultView_1 = require("./ResultView");
const Utils = require('../utils');

class UIManager {
  constructor(context) {
    this._context = context;
    this._connectionManager = new ConnectionManager(null);
    this._results = [];
    this._activeResults = undefined;
  }

  // showResultPanel(query, result) {
  //   // Create and show the SQL Query Results panel
  //   //const pannel = vscode.window.registerWebviewPanelSerializer()
  //   let viewCol = UIManager.getViewColumn(); 
  //   const panel = vscode.window.createWebviewPanel(
  //     "Db2Connect",
  //     "RESULT",
  //     viewCol,
  //     {
  //       enableScripts: true,
  //       enableCommandUris: true
  //     }
  //   );
    
  //   // And set its HTML content
  //   panel.webview.html = htmlContent.getTableContent(query, result);

  //   panel.webview.onDidReceiveMessage(message => {
  //     if (message.msg){
  //       this.exportResult(message.msg);
  //     } else {
  //       vscode.window.showErrorMessage("Error while exporting");
  //     }
  //   })
  // }

  showResultPanel(query, result){
    let view = this.createNewResult(query);
    view.update(query, result);
  }

  showProfilePanel(cb) {
    // Create and show the Form for creating Profile
    const panel = vscode.window.createWebviewPanel(
      "Db2Connect",
      "Create Connection Profile",
      vscode.ViewColumn.Beside,
      {
        enableScripts: true
      }
    );

    // And set its HTML content
    panel.webview.html = htmlContent.getProfileFormContent();

    panel.webview.onDidReceiveMessage(message => {
      if (message.profile) {
        panel.dispose();
        cb(message.profile);
      } else if(message.optionFill) {
        vscode.window.showErrorMessage(message.optionFill)
      } else {
        this._connectionManager.test(message.test, (info, status) => {
          panel.webview.postMessage({ command: "test_done" });
          if (status) {
            vscode.window.showInformationMessage(Constants.infTestSuccess);
          } else {
            vscode.window.showErrorMessage(`${Constants.errTestFail}: ${info}`);
          }
        });
      }
    });
  }

  showEditProfPanel(profile, cb) {
    const panel = vscode.window.createWebviewPanel(
      "Db2Connect",
      "Edit Profile",
      vscode.ViewColumn.Beside,
      {
        enableScripts: true
      }
    );
     var profile_json = JSON.parse(profile)
     var keys = Object.keys(profile_json)
     for (var i =0;i<keys.length;i++){
       profile_json[keys[i]].Password = Utils.decrypt(profile_json[keys[i]].Password)
       if (profile_json[keys[i]].Others) {
          var others = profile_json[keys[i]].Others.split(";")
          for (var j=0;j<others.length;j++){
            var property = others[j].split("=")
            profile_json[keys[i]][property[0]] = property[1]
          }
          delete profile_json[keys[i]]["Others"]
       }
     }
    panel.webview.html = htmlContent.getEditProfFormConetent(JSON.stringify(profile_json));
    //panel.webview.html = htmlContent.getEditProfFormConetent(profile);

    panel.webview.onDidReceiveMessage(message => {
      if(message){
        if (message.profile) {
          panel.dispose();
          cb(message);
        } 
        if (message.profileDelete) {
          cb(message);
        }
        if(message.optionFill){
          vscode.window.showErrorMessage(message.optionFill)
        }
      } else {
          panel.dispose();
          vscode.window.showInformationMessage(Constants.pannel);
      }
    });
  }

  showDeleteProfPanel(profile, cb) {
    const panel = vscode.window.createWebviewPanel(
      "Db2Connect",
      "Delete Profile",
      vscode.ViewColumn.Beside,
      {
        enableScripts: true
      }
    );
    panel.webview.html = htmlContent.getDeleteProfFormConetent(profile);
    panel.webview.onDidReceiveMessage(message => {
      if(message){
        if (message.msg) {
          cb(message.msg);
          panel.webview.postMessage('Extension Knows React is ready');
        } else {
          vscode.window.showInformationMessage("Extension Knows React is ready");
        }
      } else {
        panel.dispose();
        vscode.window.showInformationMessage(Constants.pannel);
      }
  });
  }

  showConnectPanel(cb) {
    // Create and show the form for entering Connection Params
    const panel = vscode.window.createWebviewPanel(
      "Db2Connect",
      "Connection Parameters",
      vscode.ViewColumn.Beside,
      {
        enableScripts: true
      }
    );
    let connString = "";

    // And set its HTML content
    panel.webview.html = htmlContent.getConnectFormContent();

    panel.webview.onDidReceiveMessage(message => {
        if (message.connString) {
          cb(message.connString);
          panel.dispose();
        } else if(message.optionFill){
          vscode.window.showErrorMessage(message.optionFill)
        }
    });
  }

  // exportResult(result){
  //   let res = null;
  //   let csv = result.join("\n")
  //   let formats = ['json', 'xml', 'csv'];
  //   let cols = result[0];
  //   result.shift();
  //   vscode.window.showQuickPick(formats).then(selected => {
  //     if (selected == 'json'){
  //       let data = this.Output(cols, result);
  //       res = JSON.stringify(data, null, 2);
  //     } 
  //     else if(selected == 'xml'){
  //       var serializer = new EasyXml({
  //         singularize: true,
  //         rootElement: 'results',
  //         dateFormat: 'ISO',
  //         manifest: true
  //       });
  //       let data = this.Output(cols, result);
  //       res = serializer.render(data);
  //     }
  //     else {
  //       res = csv;
  //     }
  //     vscode.workspace.openTextDocument({ content: res, language: selected }).then(textDocument => {
  //       vscode.window.showTextDocument(textDocument);
  //     });
  //   });
  // }

  // Output(cols, rows) {
  //   let col = this.frameColNames.bind(null, cols);
  //   return rows.map(col);
  // }
  
  // frameColNames(fields, row) {
  //   let Row = {};
  //   let fieldCounts = {};
  //   fields.forEach((field, i) => {
  //       fieldCounts[field] = 0;
  //       Row[field] = row[i];
  //   });
  //   return Row;
  // }

  get activeWinResults() {
    if (!this._activeResults)
       return null;
    return this._activeResults.currentResults;
  }

  createNewResult(resource) {
    let view = resultView_1.ResultView.createResult(resource);
    this._activeResults = view;
    return this.registerView(view);
  }

  createNewView(resource) {
      let view = resultView_1.ResultView.create(resource);
      this._activeResults = view;
      return this.registerView(view);
  }

  registerView(view) {
    this._results.push(view);
    view.onDispose(() => {
        const existing = this._results.indexOf(view);
        if (existing === -1)
            return;
        this._results.splice(existing, 1);
        if (this._activeResults === view) {
            this._activeResults = undefined;
        }
    });
    view.onDidChangeViewState(({ webviewPanel }) => {
        //resultView_1.disposeAll(this._results.filter(otherView => view !== otherView && view.matches(otherView)));
        //vscode.commands.executeCommand('setContext', 'ResultsetConetxt', webviewPanel.visible && webviewPanel.active);
        this._activeResults = webviewPanel.active ? view : undefined;
        //this._activeResults = view;
    });
    return view;
  }
}

module.exports = UIManager;
