### 2.3.0 - (Sep 17, 2021)
* Intellisense support.
* Connection aware code completion (keywords, functions, tables...).
* Insert Row option added to table tree item.

### 2.2.0 - (July 2, 2021)

* Indexes list the column names of the table.
* Describe table will also list primary key, foreign key and indexes of a table.
* Execute stored procedure from tree view.
* Execute stored procedure using host parameter.
* Rebuild Native modules displays a proper message when new major electron version is not available.
* Ability to add ODBC properties for a connection using UI.
* Fix:- Disconnect from Command Palette now clears the tree view.

### 2.1.0 - (Mar 19, 2021)

* Three lanugage modes (Db2_i, Db2_LUW and Db2_z) are added to support 3 types of Db2 servers.
* Syntax highlighting for Db2 i Series, luw and z servers.
* Code snippet support for Db2 i Series, luw and z servers.
* Install Db2 for i and Db2 for z/OS license from Db2 Connect Explorer.
* Additional column information to identify the primary key and foreign key (using column icon).
* Additional column information to identify the indexes on the column.
* Fixed comment line execution issue.
* Removal of node.js prerequisite.

### 2.0.0 - (Nov 12, 2020)

* Multiple Connections.
* Added tree view to display the database objects(tables, view, alias, stored procedures, functions, triggers and indexes).
* Capability to save file as .sql, .spsql,.udfsql,.db2,.spdb2 and .udfdb2
* Added Support for file execution.
* Added keyboard shortcuts for single and multiple sql execution.
* Merged three platform specific extensions to single platform independent extension.
* Export the result set to 3 different formats.

### 1.1.0 - (Sep 6, 2019)

Fixed

   * Query Freez issue.

Added

	Db2: Report an Issue option to raise an issue.
	
	Db2: Rebuild Native Modules option to handle new electron version release in VS Code editor.
	
	Db2: View Command History option to see the history of command executed by the user.
	
Changed

	Db2: Manage Connection Profile from file view to GUI

### 1.0.0 - (May 16, 2019)

Initial release of Db2 Connect